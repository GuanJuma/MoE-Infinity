# KV 缓存命中率数据集

`cache_hit.hit_rate` 使用的冷热变体。每个档位三份 jsonl，文件名 `cache_{档}_{场景}.jsonl`。

| 场景 | 构造 | 期望 |
| --- | --- | --- |
| `hot` | 同一条共享前缀复制 N 份 | 高命中 |
| `cold` | 每条 user 头部注入 `[UUID:…]` | 应 miss prefix cache |
| `mix50` | 约 50% 共享前缀 + 50% UUID | 记录命中率，不卡门禁 |

正式剖面档位 `1k / 4k / 8k / 16k`，**每份 jsonl 全部发完**（`max_requests: 0`）。smoke 只跑 `1k` 且截成 `smoke_n` 条。jsonl 随仓库提供（约 125MB）。覆盖路径：profile 里的 `cache_hit.kit_dir`。缺文件时该档 SKIP，不回退成合成前缀。

跑测前清空 serving 侧 radix / prefix cache，见仓库根目录 README「缓存命中率」。
