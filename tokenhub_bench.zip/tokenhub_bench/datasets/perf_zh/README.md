# 性能压测中文长文

从 Tokenhub `perf-kit` 抽出的 jsonl，只保留压测用的 7 档主数据。`run.sh`、tokenizer、Excel 脚本、前缀缓存场景（`9k_cold/hot/mix50`）已丢弃。

| 文件 | 约输入长度 |
| --- | --- |
| `perf_zh_1k.jsonl` | 870–1,228 |
| `perf_zh_9k.jsonl` | 8,000–11,000 |
| `perf_zh_16k.jsonl` | 14,000–18,000 |
| `perf_zh_32k.jsonl` | 28,000–36,000 |
| `perf_zh_64k.jsonl` | 56,000–72,000 |
| `perf_zh_128k.jsonl` | 112,000–144,000 |
| `perf_zh_200k.jsonl` | 180,000–220,000 |

jsonl 约 2.5GB，已写入 `.gitignore`。覆盖路径：`TOKENHUB_PERF_KIT` 或 profile 里的 `performance.kit_dir`。
