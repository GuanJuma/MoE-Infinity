from __future__ import annotations

import unittest

from tokenhub_bench.modules.engineering.thinking import ThinkingModule
from tokenhub_bench.types import Status

from tests.fakes import FakeVendor, by_name, chat_ok, make_ctx


def _thinking_script(*, leak: bool = False, enable_reasoning: bool = True, disable_clean: bool = True):
    default = (
        chat_ok("323", reasoning=None)
        if not leak
        else chat_ok("<think>17*19=323</think>323")
    )
    enable = chat_ok("23", reasoning="check primes") if enable_reasoning else chat_ok("23")
    disable = chat_ok("hi") if disable_clean else chat_ok("hi", reasoning="still thinking")
    return [default, enable, disable]


class TestThinkingModule(unittest.TestCase):
    def test_hy3_default_off_and_reasoning_effort(self) -> None:
        ctx = make_ctx(vendor=FakeVendor(chat_results=_thinking_script()))
        r = ThinkingModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["default_thinking_off"], Status.PASS)
        self.assertEqual(names["enable_reasoning_effort"], Status.PASS)
        self.assertEqual(names["disable_reasoning_effort"], Status.PASS)
        self.assertEqual(r.status, Status.PASS)

    def test_think_tag_in_default_content_fails(self) -> None:
        ctx = make_ctx(vendor=FakeVendor(chat_results=_thinking_script(leak=True)))
        r = ThinkingModule(ctx).run()
        self.assertEqual(by_name(r)["default_thinking_off"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)
