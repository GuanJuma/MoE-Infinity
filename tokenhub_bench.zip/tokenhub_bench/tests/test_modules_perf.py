from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tokenhub_bench.config import Config
from tokenhub_bench.modules.accuracy.evalscope import EvalscopeAccuracyModule
from tokenhub_bench.modules.availability.sla import SLAModule
from tokenhub_bench.modules.base import RunContext
from tokenhub_bench.modules.cache_hit.hit_rate import CacheHitRateModule
from tokenhub_bench.modules.capacity.gradient import GradientCapacityModule, SoakModule
from tokenhub_bench.modules.performance.kit import (
    chat_extra,
    load_messages,
    prompt_factory_for,
    request_count,
)
from tokenhub_bench.modules.performance.loadgen import Sample, _to_sample, run_load
from tokenhub_bench.modules.performance.ttft_otps import OTPSModule, TTFTModule, WarmupModule, _sample_line
from tokenhub_bench.types import HttpResult, Status

from tests.common import JOB_ADMISSION
from tests.fakes import FakeVendor, by_name, chat_ok, load_stats, make_ctx


def add_1k_dataset(ctx, root: str) -> None:
    path = Path(root) / "perf_zh_1k.jsonl"
    path.write_text(
        json.dumps([{"role": "user", "content": "test prompt"}]) + "\n",
        encoding="utf-8",
    )
    ctx.cfg.data["performance"]["kit_dir"] = root


class TestWarmupTtftOtps(unittest.TestCase):
    def test_ttft_empty_buckets_skips(self) -> None:
        ctx = make_ctx()
        ctx.cfg.data["performance"]["ttft_buckets"] = []
        r = TTFTModule(ctx).run()
        self.assertEqual(r.status, Status.SKIP)

    def test_smoke_ttft_skips_without_dataset(self) -> None:
        ctx = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            ctx.cfg.data["performance"]["kit_dir"] = tmp
            result = TTFTModule(ctx).run()
        self.assertEqual(result.status, Status.SKIP)

    def test_missing_first_token_is_not_replaced_by_total_latency(self) -> None:
        sample = _to_sample(HttpResult(ok=True, status_code=200, elapsed_s=2.5))
        self.assertIsNone(sample.ttft_s)
        self.assertIsNone(sample.itl_s)

    def test_itl_from_completion_tokens(self) -> None:
        sample = _to_sample(
            HttpResult(
                ok=True,
                status_code=200,
                elapsed_s=1.1,
                ttft_s=0.1,
                usage={"prompt_tokens": 10, "completion_tokens": 6},
            )
        )
        self.assertAlmostEqual(sample.output_tps or 0, 5.0)
        self.assertAlmostEqual(sample.tpot_s or 0, 0.2)
        self.assertIsNone(sample.itl_s)

    def test_percentile_uses_linear_interpolation(self) -> None:
        stats = load_stats(n=2)
        stats.samples[0].ttft_s = 0.0
        stats.samples[1].ttft_s = 10.0
        self.assertAlmostEqual(stats.percentile("ttft_s", 90) or 0, 9.0)

    def test_warmup_and_otps_skip_without_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            warmup_ctx = make_ctx()
            warmup_ctx.cfg.data["performance"]["kit_dir"] = tmp
            otps_ctx = make_ctx()
            otps_ctx.cfg.data["performance"]["kit_dir"] = tmp
            self.assertEqual(WarmupModule(warmup_ctx).run().status, Status.SKIP)
            self.assertEqual(OTPSModule(otps_ctx).run().status, Status.SKIP)

    def test_warmup_success_rate_pass(self) -> None:
        ctx = make_ctx()
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx, tmp)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(),
            ):
                r = WarmupModule(ctx).run()
        self.assertEqual(by_name(r)["warmup_success_rate"], Status.PASS)

    def test_warmup_low_success_fails(self) -> None:
        ctx = make_ctx()
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx, tmp)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(ok=False),
            ):
                r = WarmupModule(ctx).run()
        self.assertEqual(by_name(r)["warmup_success_rate"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)

    def test_ttft_bucket_pass_and_fail(self) -> None:
        ctx = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx, tmp)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(ttft_s=0.1),
            ):
                r = TTFTModule(ctx).run()
        self.assertEqual(by_name(r)["ttft_lt_6k"], Status.PASS)

        ctx_bad = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx_bad, tmp)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(ttft_s=10.0),
            ):
                bad = TTFTModule(ctx_bad).run()
        self.assertEqual(by_name(bad)["ttft_lt_6k"], Status.FAIL)

    def test_smoke_skips_long_kit_buckets(self) -> None:
        ctx = make_ctx(quick=False)
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx, tmp)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(ttft_s=0.1),
            ):
                r = TTFTModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["ttft_lt_6k"], Status.PASS)
        self.assertEqual(names["ttft_6k_16k"], Status.SKIP)
        self.assertEqual(names["ttft_128k_256k"], Status.SKIP)

    def test_otps_l1_pass_and_fail(self) -> None:
        ctx = make_ctx()
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx, tmp)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(output_tps=50.0),
            ):
                r = OTPSModule(ctx).run()
        self.assertEqual(by_name(r)["otps_L1"], Status.PASS)

        ctx_bad = make_ctx()
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx_bad, tmp)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(output_tps=1.0),
            ):
                bad = OTPSModule(ctx_bad).run()
        self.assertEqual(by_name(bad)["otps_L1"], Status.FAIL)

    def test_otps_fails_clearly_without_usage_metric(self) -> None:
        ctx = make_ctx()
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx, tmp)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(output_tps=None),
            ):
                result = OTPSModule(ctx).run()
        self.assertEqual(by_name(result)["otps_L1"], Status.FAIL)
        self.assertEqual(result.vendor_summary, "otps unavailable")


class TestGradientAndSoak(unittest.TestCase):
    def test_capacity_modules_skip_without_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            gradient_ctx = make_ctx(quick=True)
            gradient_ctx.cfg.data["performance"]["kit_dir"] = tmp
            soak_ctx = make_ctx(quick=True)
            soak_ctx.cfg.data["performance"]["kit_dir"] = tmp
            self.assertEqual(GradientCapacityModule(gradient_ctx).run().status, Status.SKIP)
            self.assertEqual(SoakModule(soak_ctx).run().status, Status.SKIP)

    def test_gradient_ladder_pass(self) -> None:
        ctx = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "perf_zh_1k.jsonl").write_text(
                json.dumps([{"role": "user", "content": "x"}]) + "\n",
                encoding="utf-8",
            )
            ctx.cfg.data["performance"]["kit_dir"] = tmp
            with patch(
                "tokenhub_bench.modules.capacity.gradient.run_load",
                return_value=load_stats(n=20, output_tps=40.0),
            ):
                r = GradientCapacityModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["gradient_1k_c1"], Status.PASS)
        self.assertEqual(names["measured_tpm"], Status.PASS)
        self.assertEqual(names["measured_rpm"], Status.PASS)

    def test_gradient_low_success_fails(self) -> None:
        ctx = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "perf_zh_1k.jsonl").write_text(
                json.dumps([{"role": "user", "content": "x"}]) + "\n",
                encoding="utf-8",
            )
            ctx.cfg.data["performance"]["kit_dir"] = tmp
            with patch(
                "tokenhub_bench.modules.capacity.gradient.run_load",
                return_value=load_stats(ok=False),
            ):
                r = GradientCapacityModule(ctx).run()
        self.assertEqual(by_name(r)["gradient_1k_c1"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)

    def test_admission_gates_promised_tpm(self) -> None:
        cfg = Config.load(JOB_ADMISSION)
        cfg.data["performance"]["capacity_kits"] = ["1k"]
        cfg.data["performance"]["concurrencies"] = [1]
        cfg.data["performance"]["bucket_cooldown_s"] = 0
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "perf_zh_1k.jsonl").write_text(
                json.dumps([{"role": "user", "content": "x"}]) + "\n",
                encoding="utf-8",
            )
            cfg.data["performance"]["kit_dir"] = tmp
            ctx = RunContext(cfg=cfg, vendor=FakeVendor(), quick=False)
            with patch(
                "tokenhub_bench.modules.capacity.gradient.run_load",
                return_value=load_stats(duration_s=1.0),
            ):
                result = GradientCapacityModule(ctx).run()
        self.assertEqual(by_name(result)["measured_tpm"], Status.FAIL)

    def test_gradient_failure_stops_all_later_buckets(self) -> None:
        cfg = Config.load(JOB_ADMISSION)
        cfg.data["performance"]["capacity_kits"] = ["1k", "9k"]
        cfg.data["performance"]["concurrencies"] = [1, 8]
        cfg.data["performance"]["bucket_cooldown_s"] = 0
        with tempfile.TemporaryDirectory() as tmp:
            for filename in ("perf_zh_1k.jsonl", "perf_zh_9k.jsonl"):
                Path(tmp, filename).write_text(
                    json.dumps([{"role": "user", "content": "x"}]) + "\n",
                    encoding="utf-8",
                )
            cfg.data["performance"]["kit_dir"] = tmp
            ctx = RunContext(cfg=cfg, vendor=FakeVendor(), quick=False)
            with patch(
                "tokenhub_bench.modules.capacity.gradient.run_load",
                return_value=load_stats(ok=False),
            ) as run:
                GradientCapacityModule(ctx).run()
        self.assertEqual(run.call_count, 1)

    def test_soak_success_pass_and_fail(self) -> None:
        ctx = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx, tmp)
            with patch(
                "tokenhub_bench.modules.capacity.gradient.run_load",
                return_value=load_stats(),
            ) as run:
                r = SoakModule(ctx).run()
        self.assertEqual(by_name(r)["soak_success_rate"], Status.PASS)
        self.assertEqual(run.call_args.kwargs["concurrency"], 1)

        ctx_bad = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            add_1k_dataset(ctx_bad, tmp)
            with patch(
                "tokenhub_bench.modules.capacity.gradient.run_load",
                return_value=load_stats(ok=False),
            ):
                bad = SoakModule(ctx_bad).run()
        self.assertEqual(by_name(bad)["soak_success_rate"], Status.FAIL)


class TestCacheHitRate(unittest.TestCase):
    def _ctx_with_kit(
        self,
        tmp: str,
        *,
        scenarios=None,
        warmup: int = 0,
        n: int = 4,
        quick: bool = True,
        vendor=None,
        job=None,
    ):
        if job is None:
            ctx = make_ctx(vendor=vendor, quick=quick)
        else:
            cfg = Config.load(job)
            ctx = RunContext(cfg=cfg, vendor=vendor or FakeVendor(), quick=quick)
        hit = dict(ctx.cfg.data.get("cache_hit") or {})
        hit.update(
            {
                "kit_dir": tmp,
                "scenarios": scenarios or ["hot"],
                "buckets": ["1k"],
                "warmup": warmup,
                "max_requests": n,
                "quick_n": n if n else 4,
            }
        )
        ctx.cfg.data["cache_hit"] = hit
        return ctx

    def _write_kit(self, root: str, scenario: str, rows: int = 4) -> Path:
        path = Path(root) / f"cache_1k_{scenario}.jsonl"
        line = json.dumps([{"role": "user", "content": "shared prefix prompt"}]) + "\n"
        path.write_text(line * rows, encoding="utf-8")
        return path

    def test_summarize_hits_uses_token_weighted_rate(self) -> None:
        from tokenhub_bench.modules.cache_hit.hit_rate import summarize_hits

        summary = summarize_hits(
            [
                {"ok": True, "prompt_tokens": 100, "cached_tokens": 90},
                {"ok": True, "prompt_tokens": 10, "cached_tokens": 0},
                {"ok": False, "prompt_tokens": 0, "cached_tokens": 0},
            ]
        )
        self.assertEqual(summary["prompt_tokens"], 110)
        self.assertEqual(summary["cached_tokens"], 90)
        self.assertAlmostEqual(summary["global_hit_rate"], 90 / 110)
        self.assertAlmostEqual(summary["avg_hit_ratio"], (0.9 + 0.0) / 2)

    def test_quick_hot_high_cached_tokens(self) -> None:
        usage = {
            "prompt_tokens": 100,
            "completion_tokens": 2,
            "total_tokens": 102,
            "prompt_tokens_details": {"cached_tokens": 90},
        }
        with tempfile.TemporaryDirectory() as tmp:
            self._write_kit(tmp, "hot")
            ctx = self._ctx_with_kit(
                tmp,
                warmup=1,
                n=4,
                vendor=FakeVendor(chat_results=[chat_ok(str(i), usage=dict(usage)) for i in range(5)]),
            )
            r = CacheHitRateModule(ctx).run()
        self.assertEqual(by_name(r)["cache_hit_hot_1k"], Status.PASS)
        self.assertGreaterEqual(r.metrics["scenarios"]["hot_1k"]["global_hit_rate"], 0.79)

    def test_hot_zero_cache_fails(self) -> None:
        usage = {"prompt_tokens": 100, "completion_tokens": 2, "total_tokens": 102, "cached_tokens": 0}
        with tempfile.TemporaryDirectory() as tmp:
            self._write_kit(tmp, "hot")
            ctx = self._ctx_with_kit(
                tmp,
                warmup=0,
                n=4,
                vendor=FakeVendor(chat_results=[chat_ok("x", usage=dict(usage)) for _ in range(4)]),
            )
            r = CacheHitRateModule(ctx).run()
        self.assertEqual(by_name(r)["cache_hit_hot_1k"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)

    def test_cold_high_hit_fails(self) -> None:
        usage = {
            "prompt_tokens": 100,
            "completion_tokens": 2,
            "cached_tokens": 90,
        }
        with tempfile.TemporaryDirectory() as tmp:
            self._write_kit(tmp, "cold")
            ctx = self._ctx_with_kit(
                tmp,
                scenarios=["cold"],
                warmup=0,
                n=4,
                vendor=FakeVendor(chat_results=[chat_ok("x", usage=dict(usage)) for _ in range(4)]),
            )
            r = CacheHitRateModule(ctx).run()
        self.assertEqual(by_name(r)["cache_hit_cold_1k"], Status.FAIL)

    def test_thinking_off_extra_is_sent(self) -> None:
        usage = {"prompt_tokens": 100, "cached_tokens": 90}
        with tempfile.TemporaryDirectory() as tmp:
            self._write_kit(tmp, "hot")
            vendor = FakeVendor(chat_results=[chat_ok("x", usage=dict(usage)) for _ in range(4)])
            ctx = self._ctx_with_kit(tmp, warmup=0, n=4, vendor=vendor)
            CacheHitRateModule(ctx).run()
        self.assertEqual(
            vendor.last_extra,
            {"chat_template_kwargs": {"reasoning_effort": "no_think"}},
        )

    def test_missing_dataset_skips(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            ctx = self._ctx_with_kit(tmp, scenarios=["hot"], warmup=0, n=2)
            r = CacheHitRateModule(ctx).run()
        self.assertEqual(by_name(r)["cache_hit_hot_1k"], Status.SKIP)

    def test_admission_sends_entire_jsonl(self) -> None:
        usage = {"prompt_tokens": 100, "cached_tokens": 90}
        rows = 6
        with tempfile.TemporaryDirectory() as tmp:
            self._write_kit(tmp, "hot", rows=rows)
            ctx = self._ctx_with_kit(
                tmp,
                warmup=0,
                n=0,
                quick=False,
                job=JOB_ADMISSION,
                vendor=FakeVendor(
                    chat_results=[chat_ok("x", usage=dict(usage)) for _ in range(rows)]
                ),
            )
            r = CacheHitRateModule(ctx).run()
        self.assertEqual(r.metrics["scenarios"]["hot_1k"]["n"], rows)
        self.assertEqual(r.metrics["scenarios"]["hot_1k"]["success"], rows)

    def test_request_limit_none_when_max_requests_zero(self) -> None:
        from tokenhub_bench.modules.cache_hit.hit_rate import request_limit

        ctx = make_ctx(quick=False)
        self.assertEqual(request_limit(ctx, {"smoke_n": 5, "max_requests": 5}), 5)
        admission = Config.load(JOB_ADMISSION)
        ctx = RunContext(cfg=admission, vendor=FakeVendor(), quick=False)
        self.assertIsNone(request_limit(ctx, {"max_requests": 0}))
        self.assertEqual(request_limit(ctx, {"max_requests": 20}), 20)


class TestSLAModule(unittest.TestCase):
    def test_skip_without_soak_extras(self) -> None:
        r = SLAModule(make_ctx()).run()
        self.assertEqual(by_name(r)["soak_as_sla_proxy"], Status.SKIP)

    def test_soak_success_pass(self) -> None:
        ctx = make_ctx()
        ctx.extras["soak"] = {"success_rate": 0.9999, "n": 100}
        r = SLAModule(ctx).run()
        self.assertEqual(by_name(r)["soak_as_sla_proxy"], Status.PASS)

    def test_soak_low_success_warns(self) -> None:
        ctx = make_ctx()
        ctx.extras["soak"] = {"success_rate": 0.9, "n": 100}
        r = SLAModule(ctx).run()
        self.assertEqual(by_name(r)["soak_as_sla_proxy"], Status.WARN)


class TestEvalscopeModule(unittest.TestCase):
    def test_not_installed_skips(self) -> None:
        with patch("tokenhub_bench.modules.accuracy.evalscope.shutil.which", return_value=None):
            r = EvalscopeAccuracyModule(make_ctx()).run()
        self.assertEqual(by_name(r)["evalscope_not_installed"], Status.SKIP)
        self.assertEqual(r.status, Status.SKIP)

    def test_dataset_filter_limits_accuracy_checks(self) -> None:
        ctx = make_ctx()
        ctx.extras["accuracy_datasets"] = {"aime2026"}
        with patch("tokenhub_bench.modules.accuracy.evalscope.shutil.which", return_value=None):
            r = EvalscopeAccuracyModule(ctx).run()
        self.assertEqual(
            {check.name for check in r.checks},
            {"evalscope_not_installed", "aime2026"},
        )

    def test_finalize_cmd_limit(self) -> None:
        from tokenhub_bench.modules.accuracy.evalscope import _finalize_cmd

        cmd = "bash scripts/evalscope_run.sh aime26 --work-dir reports/evalscope/aime2026"
        self.assertIn("--limit 5", _finalize_cmd(cmd, {"limit": 5}, {}, False))
        self.assertIn("--limit 5", _finalize_cmd(cmd, {}, {}, True))
        self.assertEqual(_finalize_cmd(cmd + " --limit 3", {"limit": 5}, {}, True), cmd + " --limit 3")
        self.assertIsNone(_finalize_cmd(None, {}, {}, True))

    def test_dataset_generation_config(self) -> None:
        from tokenhub_bench.modules.accuracy.evalscope import _generation_config

        config = _generation_config(
            {"temperature": 0.9},
            {"max_output_tokens": 1024},
            {"EVALSCOPE_BATCH": "8"},
        )
        self.assertEqual(
            config,
            {
                "max_tokens": 1024,
                "temperature": 0.9,
                "timeout": 900.0,
                "batch_size": 8,
            },
        )

        from_ds = _generation_config({}, {"max_output_tokens": 1024, "batch_size": 8, "top_p": 1.0}, {})
        self.assertEqual(from_ds["batch_size"], 8)
        self.assertEqual(from_ds["top_p"], 1.0)

    def test_generation_config_environment_override(self) -> None:
        from tokenhub_bench.modules.accuracy.evalscope import _generation_config

        config = _generation_config(
            {},
            {"max_output_tokens": 1024},
            {"EVALSCOPE_GEN_CFG": '{"max_tokens":256,"top_p":0.95}'},
        )
        self.assertEqual(config["max_tokens"], 256)
        self.assertEqual(config["top_p"], 0.95)

    def test_parse_report_ignores_unchanged_previous_result(self) -> None:
        from tokenhub_bench.modules.accuracy.evalscope import _parse_report, _report_snapshot

        with tempfile.TemporaryDirectory() as tmp:
            report = Path(tmp) / "reports" / "model" / "aime26.json"
            report.parent.mkdir(parents=True)
            report.write_text(
                json.dumps({"dataset_name": "aime26", "score": 0.8}),
                encoding="utf-8",
            )
            previous = _report_snapshot(Path(tmp))
            self.assertIsNone(_parse_report(Path(tmp), "aime26", previous=previous))

            report.write_text(
                json.dumps({"dataset_name": "aime26", "score": 0.9}),
                encoding="utf-8",
            )
            self.assertEqual(_parse_report(Path(tmp), "aime26", previous=previous), 0.9)

    def test_score_scale_normalizes_ratio_and_percent(self) -> None:
        from tokenhub_bench.modules.accuracy.evalscope import _normalize_score_scale

        self.assertEqual(_normalize_score_scale(0.8, 80.0), (80.0, 80.0))
        self.assertEqual(_normalize_score_scale(80.0, 0.8), (0.8, 0.8))


class TestPerfKit(unittest.TestCase):
    def test_load_messages_array_and_wrapped(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "perf_zh_1k.jsonl"
            rows = [
                json.dumps([{"role": "user", "content": "问1"}]),
                json.dumps({"messages": [{"role": "system", "content": "s"}, {"role": "user", "content": "问2"}]}),
            ]
            path.write_text("\n".join(rows) + "\n", encoding="utf-8")
            msgs = load_messages(path, limit=2)
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0][0]["content"], "问1")
        self.assertEqual(msgs[1][1]["content"], "问2")

    def test_load_messages_skips_bad_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "perf_zh_1k.jsonl"
            path.write_text(
                "not-json\n" + json.dumps([{"role": "user", "content": "ok"}]) + "\n",
                encoding="utf-8",
            )
            msgs = load_messages(path, limit=2)
        self.assertEqual(len(msgs), 1)
        self.assertEqual(msgs[0][0]["content"], "ok")

    def test_prompt_factory_rejects_dataset_without_valid_messages(self) -> None:
        ctx = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "perf_zh_1k.jsonl"
            path.write_text("not-json\n", encoding="utf-8")
            ctx.cfg.data["performance"]["kit_dir"] = tmp
            with self.assertRaisesRegex(ValueError, "no valid messages"):
                prompt_factory_for(ctx, kit="1k", fallback_tokens=16, needed=1)

    def test_prompt_factory_uses_kit_dir(self) -> None:
        ctx = make_ctx(quick=True)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ds = root / "datasets"
            ds.mkdir()
            (ds / "perf_zh_1k.jsonl").write_text(
                json.dumps([{"role": "user", "content": "kit-prompt"}]) + "\n",
                encoding="utf-8",
            )
            ctx.cfg.data["performance"]["kit_dir"] = str(root)
            factory, meta = prompt_factory_for(ctx, kit="1k", fallback_tokens=16, needed=1)
        self.assertEqual(meta["source"], "perf-kit")
        self.assertEqual(factory()[0]["content"], "kit-prompt")

    def test_request_count_caps_quick_and_smoke(self) -> None:
        quick = make_ctx(quick=True)
        self.assertEqual(request_count(quick, 1), 2)
        smoke = make_ctx(quick=False)
        self.assertEqual(request_count(smoke, 8), 8)

    def test_chat_extra_forces_thinking_off(self) -> None:
        ctx = make_ctx(quick=True)
        self.assertEqual(chat_extra(ctx), {"chat_template_kwargs": {"reasoning_effort": "no_think"}})
        ctx.cfg.data["performance"]["thinking"] = "default"
        self.assertIsNone(chat_extra(ctx))
        ctx.cfg.data["performance"]["thinking"] = "typo"
        with self.assertRaisesRegex(ValueError, "unsupported"):
            chat_extra(ctx)

    def test_run_load_number_mode(self) -> None:
        usage = {"prompt_tokens": 12, "completion_tokens": 6, "total_tokens": 18}
        vendor = FakeVendor(
            repeat_chat=True,
            chat_results=[
                chat_ok("ok", usage=usage, chunks=[{"choices": [{"delta": {"content": "ok"}}]}])
            ],
        )
        stats = run_load(vendor, number=3, concurrency=2, max_tokens=16, stream=True)
        self.assertEqual(len(stats.samples), 3)
        self.assertEqual(stats.success_rate(), 1.0)
        d = stats.to_dict()
        self.assertIn("itl_avg", d)
        self.assertIn("tpot_avg", d)
        self.assertIn("ttlt_p90", d)
        self.assertEqual((vendor.last_extra or {}).get("stream_options"), {"include_usage": True})

    def test_run_load_can_omit_stream_usage_option(self) -> None:
        vendor = FakeVendor(
            repeat_chat=True,
            chat_results=[chat_ok("ok")],
        )
        run_load(
            vendor,
            number=1,
            concurrency=1,
            stream=True,
            include_stream_usage=False,
        )
        self.assertIsNone(vendor.last_extra)

    def test_run_load_on_sample_callback(self) -> None:
        vendor = FakeVendor(
            repeat_chat=True,
            chat_results=[chat_ok("ok")],
        )
        seen: list[tuple[int, int | None, bool]] = []

        def on_sample(done, total, sample):
            seen.append((done, total, sample.ok))

        stats = run_load(
            vendor,
            number=3,
            concurrency=1,
            stream=True,
            include_stream_usage=False,
            on_sample=on_sample,
        )
        self.assertEqual(len(stats.samples), 3)
        self.assertEqual(seen, [(1, 3, True), (2, 3, True), (3, 3, True)])

    def test_ttft_sample_line_includes_error(self) -> None:
        line = _sample_line(
            2,
            20,
            Sample(
                ok=False,
                status=400,
                elapsed_s=1.25,
                ttft_s=None,
                prompt_tokens=0,
                completion_tokens=0,
                output_tps=None,
                error="schema rejected reasoning_effort",
            ),
        )
        self.assertIn("2/20", line)
        self.assertIn("fail status=400", line)
        self.assertIn("ttft=n/a", line)
        self.assertIn("schema rejected reasoning_effort", line)

    def test_admission_skips_missing_kit_datasets(self) -> None:
        cfg = Config.load(JOB_ADMISSION)
        with tempfile.TemporaryDirectory() as tmp:
            cfg.data["performance"]["kit_dir"] = tmp
            ctx = RunContext(cfg=cfg, vendor=FakeVendor(), quick=False)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(ttft_s=0.1),
            ):
                r = TTFTModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["ttft_lt_6k"], Status.SKIP)
        self.assertEqual(names["ttft_200k"], Status.SKIP)
        self.assertEqual(r.status, Status.SKIP)

    def test_admission_runs_present_kit_and_skips_missing(self) -> None:
        cfg = Config.load(JOB_ADMISSION)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "perf_zh_1k.jsonl").write_text(
                json.dumps([{"role": "user", "content": "only-1k"}]) + "\n",
                encoding="utf-8",
            )
            cfg.data["performance"]["kit_dir"] = str(root)
            ctx = RunContext(cfg=cfg, vendor=FakeVendor(), quick=False)
            with patch(
                "tokenhub_bench.modules.performance.ttft_otps.run_load",
                return_value=load_stats(ttft_s=0.1),
            ) as mocked:
                r = TTFTModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["ttft_lt_6k"], Status.PASS)
        self.assertEqual(names["ttft_6k_16k"], Status.SKIP)
        self.assertEqual(names["ttft_200k"], Status.SKIP)
        self.assertEqual(mocked.call_count, 1)
