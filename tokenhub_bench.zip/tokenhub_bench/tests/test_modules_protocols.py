from __future__ import annotations

import unittest

from tokenhub_bench.modules.engineering.protocols import ProtocolsModule
from tokenhub_bench.types import Status

from tests.fakes import FakeVendor, by_name, chat_ok, http_err, make_ctx


class TestProtocolsModule(unittest.TestCase):
    def test_chat_responses_anthropic_2xx(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[chat_ok("pong")],
                responses_results=[chat_ok("pong")],
                anthropic_results=[chat_ok("pong")],
            )
        )
        r = ProtocolsModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["openai_chat_completions"], Status.PASS)
        self.assertEqual(names["openai_responses"], Status.PASS)
        self.assertEqual(names["anthropic_messages"], Status.PASS)
        self.assertEqual(r.status, Status.PASS)

    def test_chat_404_fails(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[http_err(404, "not found")],
                responses_results=[chat_ok("pong")],
                anthropic_results=[chat_ok("pong")],
            )
        )
        r = ProtocolsModule(ctx).run()
        self.assertEqual(by_name(r)["openai_chat_completions"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)

    def test_server_error_is_inconclusive_for_optional_protocol(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[chat_ok("pong")],
                responses_results=[http_err(503, "unavailable")],
                anthropic_results=[chat_ok("pong")],
            )
        )
        ctx.cfg.golden["protocols"]["responses"] = False
        r = ProtocolsModule(ctx).run()
        self.assertEqual(by_name(r)["openai_responses"], Status.WARN)
