from __future__ import annotations

import unittest

from tokenhub_bench.config import Config
from tokenhub_bench.pipeline import _import_builtin_modules
from tokenhub_bench.registry import all_ids

from tests.common import EXPECTED_MODULE_IDS, JOB


class TestRegistry(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        _import_builtin_modules()
        cls.ids = set(all_ids())

    def test_expected_count_and_ids(self) -> None:
        self.assertEqual(sorted(self.ids), EXPECTED_MODULE_IDS)
        self.assertEqual(len(self.ids), 26)

    def test_suites_have_no_unknown_ids(self) -> None:
        cfg = Config.load(JOB)
        for suite in ("smoke", "engineering", "accuracy", "performance", "capacity", "availability", "cache_hit", "full"):
            for mid in cfg.resolve_suite(suite):
                self.assertIn(mid, self.ids, f"{suite} references unregistered {mid}")


if __name__ == "__main__":
    unittest.main()
