from __future__ import annotations

import unittest
from copy import deepcopy
from pathlib import Path

from tokenhub_bench.config import Config, _envelope_warnings

from tests.common import JOB, JOB_ADMISSION, REPO_ROOT, SMOKE_SUITE


class TestJobCompose(unittest.TestCase):
    def setUp(self) -> None:
        self.cfg = Config.load(JOB)

    def test_identity(self) -> None:
        ident = self.cfg.identity
        self.assertEqual(ident["job"], "haiguang-hy3-smoke")
        self.assertEqual(ident["model_id"], "hy3-channel-int8-w8a8")
        self.assertEqual(ident["hardware_id"], "hygon-sglang")
        self.assertEqual(ident["device_class"], "hygon")
        self.assertEqual(ident["profile_id"], "smoke")

    def test_vendor_projection(self) -> None:
        v = self.cfg.vendor
        self.assertEqual(v.get("name"), "haiguang-hy3")
        self.assertIn("8000", str(v.get("base_url")))
        self.assertEqual(v.get("model"), "/model")
        self.assertTrue(v.get("engine"))
        self.assertEqual(v.get("device_class"), "hygon")

    def test_golden_hardware_overlay(self) -> None:
        self.assertEqual(self.cfg.golden_get("thinking", "control"), "reasoning_effort")
        self.assertIs(self.cfg.golden_get("web_search", "supported"), False)
        self.assertEqual(self.cfg.golden_get("cache", "mode"), "automatic")
        self.assertEqual(self.cfg.golden_get("cache", "unknown_cache_param"), "ignore")
        self.assertEqual(self.cfg.golden_get("overflow_behavior"), "truncate")
        self.assertEqual(self.cfg.golden_get("error_info", "unknown_model"), "ignore")
        self.assertEqual(self.cfg.golden_get("multimodal", "unsupported"), "ignore")
        self.assertEqual(
            self.cfg.golden_get("cache", "cached_tokens_paths"),
            ["usage.prompt_tokens_details.cached_tokens", "usage.cached_tokens"],
        )
        self.assertEqual(self.cfg.golden_get("error_body_must_not_contain")[0], "hygon")
        self.assertTrue(self.cfg.golden.get("protocols", {}).get("chat_completions"))

    def test_cache_hit_min_from_profile(self) -> None:
        self.assertEqual(self.cfg.golden_get("cache_hit", "min_required"), 0.79)
        self.assertEqual(self.cfg.golden_get("cache_hit", "official_baseline"), 0.90)
        self.assertEqual(self.cfg.get("cache_hit", "scenarios"), ["hot", "cold", "mix50"])
        self.assertEqual(self.cfg.get("cache_hit", "buckets"), ["1k"])

    def test_resolve_suite_smoke_and_full(self) -> None:
        self.assertEqual(self.cfg.resolve_suite("smoke"), SMOKE_SUITE)
        full = self.cfg.resolve_suite("full")
        self.assertIn("engineering.thinking", full)
        self.assertIn("accuracy.evalscope", full)
        self.assertIn("capacity.soak", full)
        self.assertEqual(len(full), len(set(full)))

    def test_module_key_supports_overrides(self) -> None:
        cfg = Config(
            {
                "suites": {
                    "custom": [
                        {
                            "module": "engineering.thinking",
                            "params": {"probe": "custom"},
                        }
                    ]
                }
            },
            REPO_ROOT,
        )
        self.assertEqual(cfg.resolve_suite("custom"), ["engineering.thinking"])
        self.assertEqual(cfg.module_override("engineering.thinking")["params"]["probe"], "custom")

    def test_repo_root(self) -> None:
        self.assertTrue((self.cfg.root / "configs").is_dir())
        self.assertEqual(self.cfg.root.resolve(), REPO_ROOT.resolve())

    def test_profile_is_smoke(self) -> None:
        self.assertTrue(self.cfg.profile_is_smoke())
        self.assertEqual(self.cfg.get("performance", "concurrencies"), [1, 8])
        self.assertEqual(self.cfg.get("performance", "ttft_buckets")[0]["kit"], "1k")
        self.assertEqual(self.cfg.envelope_warnings(), [])

    def test_accuracy_commands_filled(self) -> None:
        datasets = self.cfg.get("accuracy", "datasets") or []
        self.assertEqual(self.cfg.get("accuracy", "limit"), 5)
        self.assertGreaterEqual(len(datasets), 10)
        for ds in datasets:
            self.assertTrue(ds.get("command"), ds.get("id"))
            self.assertIn("evalscope_run.sh", ds["command"])
            self.assertGreater(ds.get("max_output_tokens", 0), 0, ds.get("id"))
            if ds.get("id") == "longbench_v2":
                self.assertIn("--ignore-errors", ds["command"])
            if ds.get("id") == "aime2026":
                self.assertEqual(ds.get("batch_size"), 8)
                self.assertEqual(ds.get("top_p"), 1.0)


class TestAdmissionAndFlatYaml(unittest.TestCase):
    def test_admission_durations(self) -> None:
        cfg = Config.load(JOB_ADMISSION)
        self.assertEqual(cfg.identity["profile_id"], "tokenhub-v4-admission")
        self.assertEqual(cfg.get("performance", "concurrencies"), [1, 8, 32, 64, 128])
        self.assertEqual(cfg.get("performance", "soak_concurrency"), 128)
        self.assertEqual(cfg.get("performance", "thinking"), "off")
        self.assertEqual(cfg.get("performance", "ttft_buckets")[-1]["kit"], "200k")
        self.assertFalse(cfg.profile_is_smoke())
        self.assertEqual(cfg.get("cache_hit", "buckets"), ["1k", "4k", "8k", "16k"])
        self.assertEqual(cfg.get("cache_hit", "max_requests"), 0)
        self.assertEqual(cfg.golden_get("thinking", "control"), "reasoning_effort")
        commands = {ds.get("id"): ds.get("command", "") for ds in cfg.get("accuracy", "datasets") or []}
        self.assertIn("--ignore-errors", commands["longbench_v2"])
        for ds in cfg.get("accuracy", "datasets") or []:
            self.assertGreater(ds.get("max_output_tokens", 0), 0, ds.get("id"))
            if ds.get("id") == "aime2026":
                self.assertEqual(ds.get("batch_size"), 8)
                self.assertEqual(ds.get("top_p"), 1.0)

    def test_flat_vendor_yaml_still_loads(self) -> None:
        """Config.load still accepts vendor+golden (no model/hardware/profile keys)."""
        from tempfile import TemporaryDirectory

        golden = (REPO_ROOT / "configs" / "models" / "hy3-channel.yaml").resolve()
        text = (
            "vendor:\n"
            "  name: flat-test\n"
            "  base_url: http://127.0.0.1:8000/v1\n"
            "  model: /model\n"
            "  engine: sglang\n"
            f"golden: {golden}\n"
            "suites:\n"
            "  smoke:\n"
            "    - engineering.thinking\n"
        )
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / "flat.yaml"
            path.write_text(text, encoding="utf-8")
            cfg = Config.load(path)
        self.assertEqual(cfg.golden_get("model_id"), "hy3-channel-int8-w8a8")
        self.assertEqual(cfg.resolve_suite("smoke"), ["engineering.thinking"])
        self.assertEqual(cfg.vendor.get("engine"), "sglang")

    def test_overlay_endpoint(self) -> None:
        job = Config.load(JOB)
        data = deepcopy(job.job)
        data["overlay"] = {"endpoint": {"base_url": "http://example.test:9/v1"}}
        cfg = Config._load_job(data, Path(REPO_ROOT).resolve())
        self.assertEqual(cfg.vendor["base_url"], "http://example.test:9/v1")

    def test_envelope_warnings(self) -> None:
        job = Config.load(JOB)
        hw = dict(job.hardware)
        hw["envelope"] = {"tpm": 100, "rpm": 1, "otps": 1}
        warnings = _envelope_warnings(hw, job.profile, job.model)
        self.assertTrue(any("promised_tpm" in w for w in warnings))
        self.assertTrue(any("promised_rpm" in w for w in warnings))
        self.assertTrue(any("otps" in w for w in warnings))


if __name__ == "__main__":
    unittest.main()
