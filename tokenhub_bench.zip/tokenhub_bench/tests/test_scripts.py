from __future__ import annotations

import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

from tests.common import REPO_ROOT


class TestEvalscopeWrapper(unittest.TestCase):
    def test_tau2_arguments_are_json_encoded_without_shell_interpolation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fake = Path(tmp) / "evalscope"
            fake.write_text(
                "#!/usr/bin/env python3\n"
                "import json, sys\n"
                "print(json.dumps(sys.argv[1:]))\n",
                encoding="utf-8",
            )
            fake.chmod(0o755)
            env = {
                **os.environ,
                "PATH": f"{tmp}:{os.environ['PATH']}",
                "OPENAI_MODEL": "/model",
                "OPENAI_BASE_URL": "http://127.0.0.1:8000/v1",
                "OPENAI_API_KEY": "key-with-'quotes\"",
                "TAU2_SUBSET": "retail",
                "TAU2_LOCAL_PATH": "/tmp/tau2 data",
            }
            proc = subprocess.run(
                ["bash", "scripts/evalscope_run.sh", "tau2_bench", "--work-dir", "reports/test"],
                cwd=REPO_ROOT,
                env=env,
                check=True,
                capture_output=True,
                text=True,
            )

        args = json.loads(proc.stdout)
        payload = json.loads(args[args.index("--dataset-args") + 1])
        config = payload["tau2_bench"]
        self.assertEqual(config["subset_list"], ["retail"])
        self.assertEqual(config["local_path"], "/tmp/tau2 data")
        self.assertEqual(config["extra_params"]["api_key"], "key-with-'quotes\"")
        json.loads(args[args.index("--generation-config") + 1])


if __name__ == "__main__":
    unittest.main()
