from __future__ import annotations

import unittest

from tokenhub_bench.modules.engineering.cache import CacheModule
from tokenhub_bench.modules.engineering.context_window import ContextWindowModule
from tokenhub_bench.modules.engineering.eos_suppress import EosSuppressModule
from tokenhub_bench.modules.engineering.error_info import ErrorInfoModule
from tokenhub_bench.modules.engineering.moderation import ModerationModule
from tokenhub_bench.modules.engineering.multimodal import MultimodalModule
from tokenhub_bench.modules.engineering.multiturn import MultiturnModule
from tokenhub_bench.modules.engineering.output_length import OutputLengthModule
from tokenhub_bench.modules.engineering.structured_output import StructuredOutputModule
from tokenhub_bench.modules.engineering.tool_calling import ToolCallingModule
from tokenhub_bench.types import HttpResult, Status

from tests.fakes import FakeVendor, by_name, chat_ok, http_err, make_ctx, stream_chunks, tool_call


def _usage(cached: int | None = None, completion: int = 6, prompt: int = 40) -> dict:
    u = {"prompt_tokens": prompt, "completion_tokens": completion, "total_tokens": prompt + completion}
    if cached is not None:
        u["cached_tokens"] = cached
        u["prompt_tokens_details"] = {"cached_tokens": cached}
    return u


class TestCacheModule(unittest.TestCase):
    def test_second_call_cached_tokens(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("one", usage=_usage(cached=0)),
                    chat_ok("two", usage=_usage(cached=128)),
                    http_err(400, "unknown cache_control"),
                ]
            )
        )
        r = CacheModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["cached_tokens_field"], Status.PASS)
        self.assertEqual(names["cache_hit_on_repeat"], Status.PASS)
        self.assertEqual(names["explicit_cache_param"], Status.PASS)
        self.assertEqual(r.status, Status.PASS)

    def test_hy3_unknown_cache_param_ignored_when_accepted(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("one", usage=_usage(cached=0)),
                    chat_ok("two", usage=_usage(cached=128)),
                    chat_ok("three", usage=_usage(cached=128)),
                ]
            )
        )
        self.assertEqual(ctx.golden("cache", "unknown_cache_param"), "ignore")
        r = CacheModule(ctx).run()
        self.assertEqual(by_name(r)["explicit_cache_param"], Status.PASS)
        self.assertEqual(r.status, Status.PASS)

    def test_kimi_unknown_cache_param_warns_when_accepted(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("one", usage=_usage(cached=0)),
                    chat_ok("two", usage=_usage(cached=128)),
                    chat_ok("three", usage=_usage(cached=128)),
                ]
            )
        )
        ctx.cfg.golden["cache"]["unknown_cache_param"] = "warn_if_accepted"
        r = CacheModule(ctx).run()
        self.assertEqual(by_name(r)["explicit_cache_param"], Status.WARN)
        self.assertEqual(r.status, Status.WARN)

    def test_unknown_cache_param_server_error_is_inconclusive(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("one", usage=_usage(cached=0)),
                    chat_ok("two", usage=_usage(cached=128)),
                    http_err(503, "temporarily unavailable"),
                ]
            )
        )
        r = CacheModule(ctx).run()
        self.assertEqual(by_name(r)["explicit_cache_param"], Status.WARN)
        self.assertEqual(r.status, Status.WARN)

    def test_configured_cached_tokens_path_is_used(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("one", usage={"vendor_cache": {"hit": 0}}),
                    chat_ok("two", usage={"vendor_cache": {"hit": 128}}),
                    http_err(400, "unknown cache_control"),
                ]
            )
        )
        ctx.cfg.golden["cache"]["cached_tokens_paths"] = ["usage.vendor_cache.hit"]
        r = CacheModule(ctx).run()
        self.assertEqual(by_name(r)["cached_tokens_field"], Status.PASS)
        self.assertEqual(by_name(r)["cache_hit_on_repeat"], Status.PASS)

    def test_missing_cached_tokens_field_fails(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("one"),
                    chat_ok("two"),
                    chat_ok("three"),
                ]
            )
        )
        r = CacheModule(ctx).run()
        self.assertEqual(by_name(r)["cached_tokens_field"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)


class TestMultiturnModule(unittest.TestCase):
    def test_second_turn_recalls_name(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("Acknowledged, TokenHubProbe."),
                    chat_ok("TokenHubProbe"),
                ]
            )
        )
        r = MultiturnModule(ctx).run()
        self.assertEqual(by_name(r)["turn1_content"], Status.PASS)
        self.assertEqual(by_name(r)["context_carried"], Status.PASS)
        self.assertEqual(by_name(r)["no_garbled_or_empty"], Status.PASS)

    def test_empty_turn1_fails(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok(""),
                    chat_ok("TokenHubProbe"),
                ]
            )
        )
        r = MultiturnModule(ctx).run()
        self.assertEqual(by_name(r)["turn1_content"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)


class TestErrorInfoModule(unittest.TestCase):
    def test_4xx_without_haiguang_leak(self) -> None:
        err = http_err(400, "invalid request")
        ctx = make_ctx(
            vendor=FakeVendor(
                request_results=[err, err],
                chat_results=[err],
            )
        )
        r = ErrorInfoModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["bad_model_no_vendor_leak"], Status.PASS)
        self.assertEqual(names["malformed_json_field_no_vendor_leak"], Status.PASS)
        self.assertEqual(names["empty_messages_no_vendor_leak"], Status.PASS)

    def test_hy3_unknown_model_accepted_is_pass(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                request_results=[chat_ok("hi"), http_err(400, "empty")],
                chat_results=[http_err(400, "bad max_tokens")],
            )
        )
        self.assertEqual(ctx.golden("error_info", "unknown_model"), "ignore")
        r = ErrorInfoModule(ctx).run()
        self.assertEqual(by_name(r)["bad_model_no_vendor_leak"], Status.PASS)

    def test_hy3_unknown_model_server_error_is_inconclusive(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                request_results=[http_err(503, "temporarily unavailable"), http_err(400, "empty")],
                chat_results=[http_err(400, "bad max_tokens")],
            )
        )
        r = ErrorInfoModule(ctx).run()
        self.assertEqual(by_name(r)["bad_model_no_vendor_leak"], Status.WARN)
        self.assertEqual(r.status, Status.WARN)

    def test_reject_unknown_model_warns_on_2xx(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                request_results=[chat_ok("hi"), http_err(400, "empty")],
                chat_results=[http_err(400, "bad max_tokens")],
            )
        )
        ctx.cfg.golden["error_info"] = {"unknown_model": "reject"}
        r = ErrorInfoModule(ctx).run()
        self.assertEqual(by_name(r)["bad_model"], Status.WARN)
        self.assertEqual(r.status, Status.WARN)

    def test_leak_haiguang_fails(self) -> None:
        leak = http_err(400, "海光 backend timeout")
        ctx = make_ctx(
            vendor=FakeVendor(
                request_results=[leak, leak],
                chat_results=[leak],
            )
        )
        r = ErrorInfoModule(ctx).run()
        self.assertEqual(by_name(r)["bad_model_no_vendor_leak"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)


class TestMultimodalModule(unittest.TestCase):
    def test_unsupported_4xx(self) -> None:
        err = http_err(400, "multimodal not supported")
        ctx = make_ctx(vendor=FakeVendor(chat_results=[err, err, err]))
        r = MultimodalModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["image_input"], Status.PASS)
        self.assertEqual(names["audio_input"], Status.PASS)
        self.assertEqual(names["video_input"], Status.PASS)

    def test_server_errors_are_inconclusive(self) -> None:
        err = http_err(503, "temporarily unavailable")
        ctx = make_ctx(vendor=FakeVendor(chat_results=[err, err, err]))
        r = MultimodalModule(ctx).run()
        self.assertEqual(by_name(r)["image_input"], Status.WARN)
        self.assertEqual(r.status, Status.WARN)

    def test_hy3_ignores_unsupported_modalities(self) -> None:
        ctx = make_ctx(vendor=FakeVendor(chat_results=[chat_ok("a cat"), chat_ok("audio"), chat_ok("video")]))
        self.assertEqual(ctx.golden("multimodal", "unsupported"), "ignore")
        r = MultimodalModule(ctx).run()
        self.assertEqual(by_name(r)["image_input"], Status.PASS)
        self.assertEqual(r.status, Status.PASS)

    def test_reject_policy_warns_on_accept(self) -> None:
        ctx = make_ctx(vendor=FakeVendor(chat_results=[chat_ok("a cat"), chat_ok("audio"), chat_ok("video")]))
        ctx.cfg.golden["multimodal"]["unsupported"] = "reject"
        r = MultimodalModule(ctx).run()
        self.assertEqual(by_name(r)["image_input"], Status.WARN)
        self.assertEqual(r.status, Status.WARN)


class TestModerationModule(unittest.TestCase):
    def test_served_without_content_filter(self) -> None:
        ctx = make_ctx(vendor=FakeVendor(chat_results=[chat_ok("def hash(): pass"), chat_ok("SQLi is ...")]))
        r = ModerationModule(ctx).run()
        self.assertEqual(by_name(r)["green_net_closed"], Status.PASS)

    def test_content_filter_fails(self) -> None:
        blocked = http_err(403, "content_filter: high risk")
        ctx = make_ctx(vendor=FakeVendor(chat_results=[blocked, blocked]))
        r = ModerationModule(ctx).run()
        self.assertEqual(by_name(r)["green_net_closed"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)


class TestOutputLengthModule(unittest.TestCase):
    def test_max_tokens_truncates(self) -> None:
        short = chat_ok("ab", usage=_usage(completion=8), finish_reason="length")
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[short, short, http_err(400, "unknown max_output_tokens")],
                responses_results=[http_err(404, "no responses")],
            )
        )
        r = OutputLengthModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["max_tokens"], Status.PASS)
        self.assertEqual(names["max_completion_tokens"], Status.PASS)
        self.assertEqual(names["max_output_tokens"], Status.SKIP)

    def test_max_tokens_rejected_fails(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    http_err(400, "bad max_tokens"),
                    chat_ok("x", usage=_usage(completion=8), finish_reason="length"),
                    http_err(400, "unknown"),
                ],
                responses_results=[http_err(404, "no")],
            )
        )
        r = OutputLengthModule(ctx).run()
        self.assertEqual(by_name(r)["max_tokens"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)

    def test_responses_success_without_limit_evidence_warns(self) -> None:
        short = chat_ok("ab", usage=_usage(completion=8), finish_reason="length")
        responses = HttpResult(
            ok=True,
            status_code=200,
            elapsed_s=0.01,
            json={"object": "response", "status": "completed", "output": []},
        )
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[short, short, http_err(400, "unknown max_output_tokens")],
                responses_results=[responses],
            )
        )
        r = OutputLengthModule(ctx).run()
        self.assertEqual(by_name(r)["max_output_tokens"], Status.WARN)

    def test_responses_max_output_tokens_limit_passes(self) -> None:
        short = chat_ok("ab", usage=_usage(completion=8), finish_reason="length")
        responses = HttpResult(
            ok=True,
            status_code=200,
            elapsed_s=0.01,
            json={
                "object": "response",
                "status": "incomplete",
                "incomplete_details": {"reason": "max_output_tokens"},
                "usage": {"input_tokens": 12, "output_tokens": 8, "total_tokens": 20},
            },
            usage={"input_tokens": 12, "output_tokens": 8, "total_tokens": 20},
        )
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[short, short, http_err(400, "unknown max_output_tokens")],
                responses_results=[responses],
            )
        )
        r = OutputLengthModule(ctx).run()
        self.assertEqual(by_name(r)["max_output_tokens"], Status.PASS)


class TestContextWindowModule(unittest.TestCase):
    @staticmethod
    def _as_admission(ctx):
        ctx.quick = False
        ctx.cfg.data["performance"]["profile"] = "admission"
        return ctx

    def test_in_window_ok_overflow_rejected(self) -> None:
        ctx = self._as_admission(make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("ok"),
                    http_err(400, "maximum context length exceeded"),
                ]
            )
        ))
        r = ContextWindowModule(ctx).run()
        self.assertEqual(by_name(r)["in_window_request"], Status.PASS)
        self.assertEqual(by_name(r)["overflow_behavior"], Status.PASS)

    def test_hy3_truncate_accepts_overflow_2xx(self) -> None:
        ctx = self._as_admission(make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("ok"),
                    chat_ok("ok"),
                ]
            )
        ))
        self.assertEqual(ctx.golden("overflow_behavior"), "truncate")
        r = ContextWindowModule(ctx).run()
        self.assertEqual(by_name(r)["overflow_behavior"], Status.PASS)

    def test_reject_policy_warns_on_overflow_2xx(self) -> None:
        ctx = self._as_admission(make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("ok"),
                    chat_ok("ok"),
                ]
            )
        ))
        ctx.cfg.golden["overflow_behavior"] = "reject"
        r = ContextWindowModule(ctx).run()
        self.assertEqual(by_name(r)["overflow_behavior"], Status.WARN)
        self.assertEqual(r.status, Status.WARN)

    def test_smoke_warns_when_overflow_is_not_probed(self) -> None:
        ctx = make_ctx(vendor=FakeVendor(chat_results=[chat_ok("ok")]))
        r = ContextWindowModule(ctx).run()
        self.assertEqual(by_name(r)["overflow_behavior"], Status.WARN)
        self.assertEqual(r.status, Status.WARN)

    def test_in_window_error_fails(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    http_err(500, "boom"),
                    http_err(400, "too long"),
                ]
            )
        )
        r = ContextWindowModule(ctx).run()
        self.assertEqual(by_name(r)["in_window_request"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)


class TestStructuredOutputModule(unittest.TestCase):
    def test_text_and_json_object(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("Hello there."),
                    chat_ok('{"city": "Beijing", "temp": 20}'),
                    chat_ok('{"name": "Lin", "age": 28}'),
                ]
            )
        )
        r = StructuredOutputModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["response_format_text"], Status.PASS)
        self.assertEqual(names["response_format_json_object"], Status.PASS)
        self.assertEqual(names["response_format_json_schema"], Status.SKIP)

    def test_invalid_json_object_fails(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("Hello there."),
                    chat_ok("not json"),
                    chat_ok('{"name": "Lin", "age": 28}'),
                ]
            )
        )
        r = StructuredOutputModule(ctx).run()
        self.assertEqual(by_name(r)["response_format_json_object"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)

    def test_json_schema_runs_when_contract_enables_it(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("Hello there."),
                    chat_ok('{"city": "Beijing", "temp": 20}'),
                    chat_ok('{"name": "Lin", "age": 28}'),
                ]
            )
        )
        ctx.cfg.golden["structured_output"]["json_schema"] = True
        r = StructuredOutputModule(ctx).run()
        self.assertEqual(by_name(r)["response_format_json_schema"], Status.PASS)


class TestToolCallingModule(unittest.TestCase):
    def _script(self, unknown_invents: bool = False) -> list:
        weather = chat_ok("", finish_reason="tool_calls", tool_calls=[tool_call()])
        plain = chat_ok("It is sunny.")
        streamed = chat_ok(
            "",
            chunks=stream_chunks("call"),
            finish_reason="tool_calls",
            tool_calls=[tool_call(arguments='{"city":"Shanghai"}')],
        )
        follow = chat_ok("Sunny, 25C")
        add = chat_ok("", finish_reason="tool_calls", tool_calls=[tool_call("add", '{"a":3,"b":4}')])
        chitchat = chat_ok("I am fine.")
        unknown = (
            chat_ok("", finish_reason="tool_calls", tool_calls=[tool_call("launch_missile")])
            if unknown_invents
            else chat_ok("I cannot call that.")
        )
        recover = chat_ok("The weather API timed out, sorry.")
        empty = chat_ok("Hello")
        unicode_r = chat_ok("", finish_reason="tool_calls", tool_calls=[tool_call()])
        long_sys = chat_ok("", finish_reason="tool_calls", tool_calls=[tool_call(arguments='{"city":"Paris"}')])
        return [weather, plain, streamed, follow, add, chitchat, unknown, recover, empty, unicode_r, long_sys]

    def test_auto_tool_and_no_hallucinated_name(self) -> None:
        r = ToolCallingModule(make_ctx(vendor=FakeVendor(chat_results=self._script()))).run()
        names = by_name(r)
        self.assertEqual(names["tool_choice_auto"], Status.PASS)
        self.assertEqual(names["tool_choice_none"], Status.PASS)
        self.assertEqual(names["no_undefined_function"], Status.PASS)
        self.assertEqual(names["unicode_emoji_codeblock"], Status.PASS)

    def test_invented_tool_fails(self) -> None:
        r = ToolCallingModule(make_ctx(vendor=FakeVendor(chat_results=self._script(unknown_invents=True)))).run()
        self.assertEqual(by_name(r)["no_undefined_function"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)


class TestEosSuppressModule(unittest.TestCase):
    def test_quick_repeats_without_asserting_ratio(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(chat_results=[chat_ok("9", finish_reason="stop")], repeat_chat=True),
            quick=True,
        )
        r = EosSuppressModule(ctx).run()
        self.assertIn("eos_empty_content_ratio", by_name(r))
        self.assertNotEqual(by_name(r)["eos_empty_content_ratio"], Status.FAIL)

    def test_http_failures_fail_request_success(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(chat_results=[http_err(500, "down")], repeat_chat=True),
            quick=True,
        )
        r = EosSuppressModule(ctx).run()
        self.assertEqual(by_name(r)["request_success"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)
