from __future__ import annotations

from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
JOB = REPO_ROOT / "configs" / "jobs" / "haiguang-hy3.yaml"
JOB_ADMISSION = REPO_ROOT / "configs" / "jobs" / "haiguang-hy3-admission.yaml"

EXPECTED_MODULE_IDS = [
    "accuracy.evalscope",
    "availability.sla",
    "cache_hit.hit_rate",
    "capacity.gradient",
    "capacity.soak",
    "engineering.auth",
    "engineering.ban_policy",
    "engineering.cache",
    "engineering.context_window",
    "engineering.eos_suppress",
    "engineering.error_info",
    "engineering.moderation",
    "engineering.multimodal",
    "engineering.multiturn",
    "engineering.output_length",
    "engineering.protocols",
    "engineering.rate_limit_policy",
    "engineering.response_correctness",
    "engineering.streaming",
    "engineering.structured_output",
    "engineering.thinking",
    "engineering.tool_calling",
    "engineering.web_search",
    "performance.otps",
    "performance.ttft",
    "performance.warmup",
]

SMOKE_SUITE = [
    "engineering.thinking",
    "engineering.streaming",
    "engineering.protocols",
    "engineering.auth",
    "engineering.response_correctness",
]
