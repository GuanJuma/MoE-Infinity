# Offline unittest package for the admission pipeline (no live model required).
