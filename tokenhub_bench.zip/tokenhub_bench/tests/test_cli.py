from __future__ import annotations

import io
import os
import unittest
from contextlib import redirect_stdout, redirect_stderr
from unittest.mock import patch

from tokenhub_bench.cli import main

from tests.common import REPO_ROOT, SMOKE_SUITE


class TestCli(unittest.TestCase):
    def setUp(self) -> None:
        self._cwd = os.getcwd()
        os.chdir(REPO_ROOT)

    def tearDown(self) -> None:
        os.chdir(self._cwd)

    def test_run_list_smoke(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = main(["run", "-s", "smoke", "--list"])
        self.assertEqual(rc, 0)
        out = buf.getvalue()
        self.assertIn("suite modules:", out)
        for mid in SMOKE_SUITE:
            self.assertIn(mid, out)

    def test_missing_config_exit_2(self) -> None:
        err = io.StringIO()
        with redirect_stderr(err):
            rc = main(["run", "-c", "configs/jobs/does-not-exist.yaml", "-s", "smoke", "--list"])
        self.assertEqual(rc, 2)
        self.assertIn("config not found", err.getvalue())

    def test_modules_lists_thinking(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = main(["modules"])
        self.assertEqual(rc, 0)
        self.assertIn("engineering.thinking", buf.getvalue())
        self.assertIn("registered modules:", buf.getvalue())

    def test_dataset_filter_is_passed_to_pipeline(self) -> None:
        with patch("tokenhub_bench.cli.Pipeline") as pipeline:
            pipeline.return_value.run.return_value = {"summary": {"pass": 1}}
            rc = main(["run", "-s", "accuracy", "--dataset", "aime2026"])
        self.assertEqual(rc, 0)
        self.assertEqual(pipeline.call_args.kwargs["datasets"], ["aime2026"])

    def test_list_shows_selected_dataset(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = main(["run", "-s", "accuracy", "--dataset", "aime2026", "--list"])
        self.assertEqual(rc, 0)
        self.assertIn("accuracy datasets:\n  aime2026", buf.getvalue())

    def test_unknown_dataset_exit_2(self) -> None:
        err = io.StringIO()
        with redirect_stderr(err):
            rc = main(["run", "-s", "accuracy", "--dataset", "not-a-dataset"])
        self.assertEqual(rc, 2)
        self.assertIn("unknown accuracy dataset", err.getvalue())

    def test_dataset_requires_accuracy_module(self) -> None:
        err = io.StringIO()
        with redirect_stderr(err):
            rc = main(["run", "-s", "smoke", "--dataset", "aime2026"])
        self.assertEqual(rc, 2)
        self.assertIn("requires a suite containing accuracy.evalscope", err.getvalue())


if __name__ == "__main__":
    unittest.main()
