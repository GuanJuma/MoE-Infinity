from __future__ import annotations

import unittest

from tokenhub_bench.modules.engineering.ban_policy import BanPolicyModule
from tokenhub_bench.modules.engineering.rate_limit_policy import RateLimitPolicyModule
from tokenhub_bench.modules.engineering.web_search import WebSearchModule
from tokenhub_bench.types import Status

from tests.fakes import by_name, make_ctx


class TestSkipContracts(unittest.TestCase):
    def test_web_search_unsupported(self) -> None:
        r = WebSearchModule(make_ctx()).run()
        self.assertEqual(by_name(r)["web_search"], Status.SKIP)
        self.assertEqual(r.status, Status.SKIP)

    def test_rate_limit_and_ban_unset_skip(self) -> None:
        ctx = make_ctx()
        self.assertIsNone(ctx.cfg.get("vendor", "rate_limit_policy", default=None))
        self.assertIsNone(ctx.cfg.get("vendor", "ban_policy", default=None))
        rate = RateLimitPolicyModule(ctx).run()
        ban = BanPolicyModule(ctx).run()
        self.assertEqual(by_name(rate)["declared_policy"], Status.SKIP)
        self.assertEqual(by_name(ban)["declared_policy"], Status.SKIP)

    def test_declared_policies_warn(self) -> None:
        ctx = make_ctx()
        ctx.cfg.data.setdefault("vendor", {})["rate_limit_policy"] = "ramp 10 qps"
        ctx.cfg.data["vendor"]["ban_policy"] = "ip ban 24h"
        rate = RateLimitPolicyModule(ctx).run()
        ban = BanPolicyModule(ctx).run()
        self.assertEqual(by_name(rate)["declared_policy"], Status.WARN)
        self.assertEqual(by_name(ban)["declared_policy"], Status.WARN)
