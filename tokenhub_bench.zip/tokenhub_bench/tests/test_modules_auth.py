from __future__ import annotations

import unittest

from tokenhub_bench.clients.http import EndpointClient
from tokenhub_bench.modules.engineering.auth import AuthModule
from tokenhub_bench.types import Status

from tests.fakes import FakeVendor, by_name, chat_ok, http_err, make_ctx


def _auth_vendor(*, missing=None, invalid=None, good=None) -> FakeVendor:
    return FakeVendor(
        api_key="sk-test",
        missing_auth=missing if missing is not None else http_err(401, "missing auth"),
        invalid_key=invalid if invalid is not None else http_err(401, "bad key"),
        chat_results=[good if good is not None else chat_ok("hi")],
    )


class TestAuthModule(unittest.TestCase):
    def test_empty_key_does_not_send_authorization_header(self) -> None:
        client = EndpointClient("http://127.0.0.1:8000/v1", "EMPTY", "/model")
        self.addCleanup(client.close)
        self.assertNotIn("Authorization", client.headers())

    def test_missing_and_invalid_401_valid_2xx(self) -> None:
        ctx = make_ctx(vendor=_auth_vendor())
        r = AuthModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["missing_authorization"], Status.PASS)
        self.assertEqual(names["invalid_api_key"], Status.PASS)
        self.assertEqual(names["valid_key_control"], Status.PASS)
        self.assertEqual(names["revoked_or_expired_token"], Status.WARN)
        self.assertIn(r.status, (Status.PASS, Status.WARN))

    def test_missing_auth_200_fails(self) -> None:
        ctx = make_ctx(vendor=_auth_vendor(missing=chat_ok("open cluster")))
        r = AuthModule(ctx).run()
        self.assertEqual(by_name(r)["missing_authorization"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)

    def test_auth_matchers_ignore_call_order(self) -> None:
        vendor = _auth_vendor()
        # Consume chat first; request(auth=False) must still hit missing_auth, not the chat queue.
        vendor.chat([{"role": "user", "content": "hi"}], max_tokens=8)
        missing = vendor.request("POST", "/chat/completions", json_body={}, auth=False)
        bad = vendor.request(
            "POST",
            "/chat/completions",
            json_body={},
            headers={"Authorization": "Bearer sk-invalid-tokenhub-probe"},
        )
        self.assertEqual(missing.status_code, 401)
        self.assertEqual(bad.status_code, 401)
