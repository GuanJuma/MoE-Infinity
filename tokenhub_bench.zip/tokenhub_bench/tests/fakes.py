from __future__ import annotations

import json
import threading
from typing import Any, Optional

from tokenhub_bench.config import Config
from tokenhub_bench.modules.base import RunContext
from tokenhub_bench.modules.performance.loadgen import LoadStats, Sample
from tokenhub_bench.types import HttpResult, ModuleResult, Status

from tests.common import JOB

_DEFAULT_USAGE = {"prompt_tokens": 12, "completion_tokens": 6, "total_tokens": 18}


def chat_ok(
    content: str = "pong",
    reasoning: Optional[str] = None,
    usage: Optional[dict[str, Any]] = None,
    chunks: Optional[list[dict[str, Any]]] = None,
    *,
    finish_reason: str = "stop",
    tool_calls: Optional[list[dict[str, Any]]] = None,
    extra_message: Optional[dict[str, Any]] = None,
) -> HttpResult:
    """OpenAI chat.completion shape aligned with assistant_fields / message_from."""
    usage = dict(usage or _DEFAULT_USAGE)
    message: dict[str, Any] = {"role": "assistant", "content": content}
    if reasoning is not None:
        message["reasoning_content"] = reasoning
    if tool_calls is not None:
        message["tool_calls"] = tool_calls
    if extra_message:
        message.update(extra_message)
    payload = {
        "id": "chatcmpl-fake",
        "object": "chat.completion",
        "choices": [
            {
                "index": 0,
                "message": message,
                "finish_reason": finish_reason,
            }
        ],
        "usage": usage,
    }
    text = json.dumps(payload, ensure_ascii=False)
    return HttpResult(
        ok=True,
        status_code=200,
        elapsed_s=0.02,
        json=payload,
        text=text,
        headers={"content-type": "application/json"},
        chunks=list(chunks or []),
        usage=usage,
        ttft_s=0.01 if chunks else None,
    )


def http_err(code: int, text: str = "error") -> HttpResult:
    payload = {"error": {"message": text, "type": "invalid_request_error"}}
    body = json.dumps(payload, ensure_ascii=False)
    return HttpResult(
        ok=False,
        status_code=code,
        elapsed_s=0.01,
        json=payload,
        text=text if text.strip().startswith("{") else body,
        headers={"content-type": "application/json"},
    )


def stream_chunks(content: str = "1, 2, 3, 4, 5", usage: Optional[dict[str, Any]] = None) -> list[dict[str, Any]]:
    usage = dict(usage or _DEFAULT_USAGE)
    mid = max(1, len(content) // 2)
    return [
        {"choices": [{"index": 0, "delta": {"content": content[:mid]}}]},
        {"choices": [{"index": 0, "delta": {"content": content[mid:]}}]},
        {"choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}], "usage": usage},
    ]


def tool_call(name: str = "get_weather", arguments: str = '{"city": "Beijing"}', call_id: str = "call_1") -> dict[str, Any]:
    return {
        "id": call_id,
        "type": "function",
        "function": {"name": name, "arguments": arguments},
    }


def load_stats(
    *,
    n: int = 8,
    ttft_s: float = 0.1,
    output_tps: Optional[float] = 50.0,
    prompt_tokens: int = 256,
    completion_tokens: int = 32,
    ok: bool = True,
    duration_s: float = 1.0,
) -> LoadStats:
    stats = LoadStats()
    stats.started = 0.0
    stats.ended = float(duration_s)
    for _ in range(n):
        stats.samples.append(
            Sample(
                ok=ok,
                status=200 if ok else 500,
                elapsed_s=0.4,
                ttft_s=ttft_s if ok else None,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                output_tps=output_tps if ok else None,
                error="" if ok else "fail",
            )
        )
    return stats


def by_name(result: ModuleResult) -> dict[str, Status]:
    return {c.name: c.status for c in result.checks}


class FakeVendor:
    """Scripted EndpointClient stand-in. Auth probes match on parameters; other calls pop queues."""

    def __init__(
        self,
        *,
        model: str = "/model",
        api_key: str = "sk-test",
        chat_results: Optional[list[HttpResult]] = None,
        request_results: Optional[list[HttpResult]] = None,
        responses_results: Optional[list[HttpResult]] = None,
        anthropic_results: Optional[list[HttpResult]] = None,
        missing_auth: Optional[HttpResult] = None,
        invalid_key: Optional[HttpResult] = None,
        repeat_chat: bool = False,
    ):
        self.model = model
        self.api_key = api_key
        self.base_url = "http://fake.local/v1"
        self._chat = list(chat_results or [])
        self._request = list(request_results or [])
        self._responses = list(responses_results or [])
        self._anthropic = list(anthropic_results or [])
        self.missing_auth = missing_auth
        self.invalid_key = invalid_key
        self.repeat_chat = repeat_chat
        self._last_chat: Optional[HttpResult] = None
        self.last_extra: Optional[dict[str, Any]] = None
        self._lock = threading.Lock()

    def close(self) -> None:
        return None

    def _pop(self, queue: list[HttpResult], kind: str) -> HttpResult:
        if not queue:
            if kind == "chat" and self.repeat_chat and self._last_chat is not None:
                return self._last_chat
            raise AssertionError(f"FakeVendor: no more scripted {kind} responses")
        return queue.pop(0)

    def chat(
        self,
        messages: list[dict[str, Any]],
        *,
        extra: Optional[dict[str, Any]] = None,
        stream: bool = False,
        path: str = "/chat/completions",
        **kwargs: Any,
    ) -> HttpResult:
        with self._lock:
            self.last_extra = extra
            res = self._pop(self._chat, "chat")
            self._last_chat = res
            return res

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        headers: Optional[dict[str, str]] = None,
        auth: bool = True,
        timeout_s: Optional[float] = None,
    ) -> HttpResult:
        headers = headers or {}
        authz = headers.get("Authorization") or headers.get("authorization") or ""
        if not auth:
            if self.missing_auth is not None:
                return self.missing_auth
            raise AssertionError("FakeVendor: unmatched request(auth=False); set missing_auth")
        if "sk-invalid" in authz:
            if self.invalid_key is not None:
                return self.invalid_key
            raise AssertionError("FakeVendor: unmatched invalid Bearer; set invalid_key")
        with self._lock:
            return self._pop(self._request, "request")

    def responses(self, payload: dict[str, Any], path: str = "/responses") -> HttpResult:
        with self._lock:
            return self._pop(self._responses, "responses")

    def messages_anthropic(self, payload: dict[str, Any], path: str = "/messages") -> HttpResult:
        with self._lock:
            return self._pop(self._anthropic, "anthropic")


def make_ctx(vendor: Optional[FakeVendor] = None, quick: bool = True, **fake_kw: Any) -> RunContext:
    """Real Hy3×海光 job Config with only ctx.vendor replaced."""
    cfg = Config.load(JOB)
    if vendor is None:
        vcfg = cfg.vendor
        fake_kw.setdefault("model", str(vcfg.get("model") or "/model"))
        fake_kw.setdefault("api_key", "sk-test")
        vendor = FakeVendor(**fake_kw)
    return RunContext(cfg=cfg, vendor=vendor, quick=quick)
