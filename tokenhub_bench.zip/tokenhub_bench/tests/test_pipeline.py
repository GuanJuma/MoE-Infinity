from __future__ import annotations

import json
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from openpyxl import load_workbook

from tokenhub_bench.config import Config
from tokenhub_bench.modules.base import BaseModule
from tokenhub_bench.pipeline import Pipeline
from tokenhub_bench.registry import _REGISTRY, register
from tokenhub_bench.types import Status

from tests.common import JOB


class _DummyClient:
    def __init__(self) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True


class OkModule(BaseModule):
    title = "ok"
    template_rows = [1]

    def run(self):
        return self.result([], summary="ok")


class EngineeringOkModule(OkModule):
    pass


class BoomModule(BaseModule):
    title = "boom"
    template_rows = [2]

    def run(self):
        raise RuntimeError("intentional boom")


class LaterModule(BaseModule):
    title = "later"
    template_rows = [3]

    def run(self):
        return self.result([], summary="later")


class TestPipelineIsolation(unittest.TestCase):
    def setUp(self) -> None:
        self._saved = dict(_REGISTRY)
        register("test.ok")(OkModule)
        register("test.boom")(BoomModule)
        register("test.later")(LaterModule)
        register("engineering.test_ok")(EngineeringOkModule)
        self.cfg = Config.load(JOB)
        self.tmp = TemporaryDirectory()
        out = Path(self.tmp.name)
        self.cfg.data.setdefault("report", {})
        self.cfg.data["report"]["out_dir"] = str(out)
        self.cfg.data["report"]["json"] = True
        self.cfg.data["report"]["excel"] = False

    def tearDown(self) -> None:
        _REGISTRY.clear()
        _REGISTRY.update(self._saved)
        self.tmp.cleanup()

    def test_error_does_not_stop_later_modules_and_writes_json(self) -> None:
        dummy = _DummyClient()
        with patch("tokenhub_bench.pipeline._make_client", return_value=dummy):
            payload = Pipeline(self.cfg, only=["test.ok", "test.boom", "test.later"]).run("smoke")
        self.assertTrue(dummy.closed)
        mods = payload["modules"]
        self.assertEqual([m["module_id"] for m in mods], ["test.ok", "test.boom", "test.later"])
        self.assertEqual(mods[0]["status"], Status.PASS.value)
        self.assertEqual(mods[1]["status"], Status.ERROR.value)
        self.assertIn("intentional boom", mods[1]["vendor_summary"])
        self.assertEqual(mods[2]["status"], Status.PASS.value)
        self.assertEqual(payload["identity"]["hardware_id"], "hygon-sglang")
        self.assertEqual(payload["vendor"]["hardware_id"], "hygon-sglang")
        self.assertEqual(payload["summary"]["error"], 1)
        self.assertEqual(payload["summary"]["pass"], 2)
        reports = list(Path(self.tmp.name).glob("tokenhub_smoke_*.json"))
        self.assertEqual(len(reports), 1)
        disk = json.loads(reports[0].read_text(encoding="utf-8"))
        self.assertEqual(disk["身份"]["hardware_id"], "hygon-sglang")
        self.assertEqual(disk["身份"]["profile_id"], "smoke")

    def test_engineering_official_run_is_reported_but_not_gating(self) -> None:
        vendor = _DummyClient()
        official = _DummyClient()
        self.cfg.data["official"]["enabled"] = True
        self.cfg.data["official"]["api_key"] = "test-only"
        self.cfg.data["report"]["excel"] = True
        with patch("tokenhub_bench.pipeline._make_client", side_effect=[vendor, official]):
            payload = Pipeline(self.cfg, only=["engineering.test_ok"]).run("engineering")

        self.assertTrue(vendor.closed)
        self.assertTrue(official.closed)
        self.assertTrue(payload["official_endpoint_enabled"])
        self.assertTrue(payload["official_compare"])
        self.assertEqual(payload["summary"]["pass"], 1)
        self.assertEqual(len(payload["official_modules"]), 1)
        self.assertEqual(payload["official_modules"][0]["status"], Status.PASS.value)
        self.assertEqual(payload["official_differences"], [])
        reports = list(Path(self.tmp.name).glob("tokenhub_engineering_*.xlsx"))
        self.assertEqual(len(reports), 1)
        self.assertIn("原厂对比", load_workbook(reports[0], read_only=True).sheetnames)


if __name__ == "__main__":
    unittest.main()
