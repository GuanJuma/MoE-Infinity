from __future__ import annotations

import unittest

from tokenhub_bench.modules.engineering.response_correctness import ResponseCorrectnessModule
from tokenhub_bench.types import HttpResult, Status

from tests.fakes import FakeVendor, by_name, chat_ok, make_ctx


class TestResponseCorrectnessModule(unittest.TestCase):
    def test_content_and_usage_present(self) -> None:
        ctx = make_ctx(vendor=FakeVendor(chat_results=[chat_ok("pong")]))
        r = ResponseCorrectnessModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["no_duplicate_fields"], Status.PASS)
        self.assertEqual(names["required_fields_present"], Status.PASS)
        self.assertEqual(names["no_garbled_or_train_leak"], Status.PASS)
        self.assertEqual(r.status, Status.PASS)

    def test_missing_content_fails(self) -> None:
        ctx = make_ctx(vendor=FakeVendor(chat_results=[chat_ok("")]))
        r = ResponseCorrectnessModule(ctx).run()
        self.assertEqual(by_name(r)["required_fields_present"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)

    def test_duplicate_usage_key_fails(self) -> None:
        ok = chat_ok("pong")
        raw = ok.text.replace('"usage"', '"usage"', 1)
        # Inject a second top-level usage key the scanner can count.
        raw = raw[:-1] + ', "usage": {"prompt_tokens": 1}}'
        dup = HttpResult(
            ok=True,
            status_code=200,
            elapsed_s=0.01,
            json=ok.json,
            text=raw,
            usage=ok.usage,
        )
        ctx = make_ctx(vendor=FakeVendor(chat_results=[dup]))
        r = ResponseCorrectnessModule(ctx).run()
        self.assertEqual(by_name(r)["no_duplicate_fields"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)
