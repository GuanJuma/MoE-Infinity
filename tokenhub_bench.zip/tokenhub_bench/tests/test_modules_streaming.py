from __future__ import annotations

import unittest

from tokenhub_bench.clients.http import content_text
from tokenhub_bench.modules.engineering.streaming import StreamingModule
from tokenhub_bench.types import Status

from tests.fakes import FakeVendor, by_name, chat_ok, http_err, make_ctx, stream_chunks


class TestStreamingModule(unittest.TestCase):
    def test_typed_content_parts_are_flattened(self) -> None:
        self.assertEqual(
            content_text([{"type": "text", "text": "hello"}, {"type": "text", "text": " world"}]),
            "hello world",
        )

    def test_nonstream_default_and_sse_with_trailing_usage(self) -> None:
        usage = {"prompt_tokens": 8, "completion_tokens": 5, "total_tokens": 13}
        chunks = stream_chunks("1, 2, 3, 4, 5", usage=usage)
        streamed = chat_ok("1, 2, 3, 4, 5", usage=usage, chunks=chunks)
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("pong"),
                    streamed,
                    chat_ok("pong"),
                ]
            )
        )
        r = StreamingModule(ctx).run()
        names = by_name(r)
        self.assertEqual(names["default_streaming"], Status.PASS)
        self.assertEqual(names["enable_stream"], Status.PASS)
        self.assertEqual(names["disable_stream"], Status.PASS)
        self.assertEqual(names["usage_last_chunk"], Status.PASS)
        self.assertEqual(r.status, Status.PASS)

    def test_stream_true_http_error_fails(self) -> None:
        ctx = make_ctx(
            vendor=FakeVendor(
                chat_results=[
                    chat_ok("pong"),
                    http_err(500, "stream broken"),
                ]
            )
        )
        r = StreamingModule(ctx).run()
        self.assertEqual(by_name(r)["enable_stream"], Status.FAIL)
        self.assertEqual(r.status, Status.FAIL)
