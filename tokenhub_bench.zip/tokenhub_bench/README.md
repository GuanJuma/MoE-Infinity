# Tokenhub 准入测试流水线

按腾讯 Tokenhub《第三方供应商引入测试模板 V4.0》拆成可插拔模块。配置由三轴和一份实验绑定组成：

| 轴 | 目录 | 何时改 |
| --- | --- | --- |
| 模型契约 | `configs/models/` | 换模型协议/能力 |
| 硬件/集群 | `configs/hardware/` | 换卡、引擎、机房地址 |
| 准入剖面 | `configs/profiles/` | 换联调 smoke 或正式 V4 口径 |
| 实验绑定 | `configs/jobs/` | 三轴怎么拼、原厂对比、endpoint 覆盖 |

当前默认实验：海光 sglang × Hy3-Channel × smoke，见 `configs/jobs/haiguang-hy3.yaml`（默认打 `http://22.142.37.103:8000/v1`）。正式口径换 `configs/jobs/haiguang-hy3-admission.yaml`：性能压测对齐 Tokenhub `perf-kit`（中文长文档位 + 并发梯度），KV 缓存命中率用 `datasets/cache_variants` 的 hot/cold/mix50 jsonl，效果评测跑全集。模型和硬件不变。

## 覆盖范围

| 套件 | 模板章节 | 命令 |
| --- | --- | --- |
| `engineering` | 一、工程验收 | `--suite engineering` |
| `accuracy` | 二、效果验收 | `--suite accuracy` |
| `performance` | 三、TTFT / OTPS | `--suite performance` |
| `capacity` | 四/五、TPM RPM 稳定性 | `--suite capacity` |
| `availability` | 六、SLA / RTO | `--suite availability` |
| `cache_hit` | 七、缓存命中率 | `--suite cache_hit` |
| `smoke` | 工程子集，快速连通 | `--suite smoke` |
| `full` | 以上全部 | `--suite full` |

默认 job 使用 `profiles/smoke`（短预热/压测）。正式准入：

```bash
python3 -m tokenhub_bench run -c configs/jobs/haiguang-hy3-admission.yaml -s performance
python3 -m tokenhub_bench run -c configs/jobs/haiguang-hy3-admission.yaml -s cache_hit
```

## 测试

退出码 **0** 允许 warn/skip；**1** 有 fail 或 error；**2** 配置文件不存在。Hy3 × 海光 sglang 上这些是预期 **SKIP**，不算失败：`engineering.web_search`（内部 serving 无内置搜索）、`engineering.rate_limit_policy` / `engineering.ban_policy`（硬件 YAML 未填书面策略）、`availability.sla` 的 RTO 项（只记口径、不真演）。`accuracy.evalscope` 在 PATH 上没有 `evalscope` 时也会 SKIP。

无外网机先 `bash scripts/install_offline.sh` 生成 `.venv`（系统 Python 通常没有 httpx）。evalscope **不在** `vendor/wheels` 里，离线机默认跑不了 `--suite accuracy`。

```bash
# 离线：编排 + 条款功能单测（假 HTTP，不连模型）
bash scripts/test_offline.sh
# 改单个条款：PYTHONPATH=. python3 -m unittest tests.test_modules_thinking -v

# 实机 L0+L1：curl 探活 + smoke --quick（默认 103；本机 127.0.0.1 需改环境变量）
bash scripts/test_live.sh

# 实机 L2：再加上 engineering --quick
bash scripts/test_live.sh l2
```

| 级 | 命令 | 目的 | 时长 |
| --- | --- | --- | --- |
| L0 | `bash scripts/test_live.sh l0` | `curl` models + 一条 chat | 秒 |
| L1 | `bash scripts/test_live.sh` | probe + `run -s smoke --quick` | 分钟 |
| L2 | `bash scripts/test_live.sh l2` | 再跑 `engineering --quick` | 十余分钟 |
| L3 | 见下，不进默认脚本 | 正式口径 TTFT / 容量 / KV cache / 效果 | 数十分钟到数小时 |

L1 通过：退出码 0；`reports/tokenhub_smoke_*.json` 中 `身份.hardware_id=hygon-sglang`、`profile_id=smoke`；thinking / streaming / protocols / auth / response_correctness 无 error。L2 额外：`engineering.web_search` 为 skip；文本模型 multimodal 按契约拒绝则为 pass。出现 fail 再查服务，不是先改流水线。

L3（可选；门槛失败多半是硬件能力，不是编排坏了）。Job 默认 `configs/jobs/haiguang-hy3.yaml`（剖面 `smoke`）。正式时长用 `configs/jobs/haiguang-hy3-admission.yaml`：

```bash
python3 -m tokenhub_bench run -c configs/jobs/haiguang-hy3-admission.yaml -s performance
python3 -m tokenhub_bench run -c configs/jobs/haiguang-hy3-admission.yaml -s capacity
# KV cache 前先 flush serving 侧 radix，见下文「缓存命中率」
python3 -m tokenhub_bench run -c configs/jobs/haiguang-hy3-admission.yaml -s cache_hit
python3 -m tokenhub_bench run -c configs/jobs/haiguang-hy3-admission.yaml -s accuracy
```

正式 accuracy 跑全集；若只做每集 5 条的效果冒烟，改用默认 `haiguang-hy3.yaml`。SWE-bench 要 Docker + `swebench`；tau2 要另装提供 `tau2` Python 包的 tau2-bench 项目及其数据。缺依赖时该数据集会 warn，不要改流水线去「修过」。

换轴时：只改地址用 `TOKENHUB_BASE_URL` / `TOKENHUB_API_KEY`；换卡改 job 的 `hardware:` 后对 endpoint 重跑 L0–L1；换 admission 剖面时离线断言 perf-kit 并发梯度（smoke `[1, 8]`、admission `[1, 8, 32, 64, 128]`）。改条款判定先跑对应 `tests/test_modules_*.py`，再 `test_offline.sh`。不测 PCIe / 驱动、无 endpoint 的卡型骨架，也不做 Excel 单元格级排版。

## 远端离线（服务器无外网）

离线包面向 Linux x86_64、Python 3.10–3.13。服务器不需要访问公网，但必须能通过内网访问待测模型 endpoint。复制项目时需要保留 `vendor/wheels/` 和 `configs/`；不需要复制 `.venv`、`reports/`、`__pycache__` 和实验产物。V4 Excel 模板不在 Git 中；需要按模板行号回填时，将 `第三方供应商引入测试模板-V4.0.xlsx` 放到仓库根目录。

在联网机器上打包，再通过 U 盘或内网传到服务器：

```bash
tar czf ../tokenhub_bench_offline.tar.gz \
  --exclude .venv --exclude reports --exclude __pycache__ \
  --exclude '*.xlsx' --exclude .git \
  --exclude ai_evaluagtion --exclude tokenhub_perf_client.py .
```

将生成的压缩包复制到远端用户主目录后：

```bash
mkdir -p ~/tokenhub_bench
tar xzf ~/tokenhub_bench_offline.tar.gz -C ~/tokenhub_bench
cd ~/tokenhub_bench
```

离线安装全程使用本地 wheels，不访问 PyPI：

```bash
chmod +x scripts/*.sh
bash scripts/install_offline.sh
source .venv/bin/activate
bash scripts/test_offline.sh
```

地址和密钥可以用环境变量覆盖，不必复制 job。默认使用 `http://22.142.37.103:8000/v1` 和 `tokenhub-test`；本机无鉴权的 sglang 可这样运行：

```bash
export TOKENHUB_BASE_URL=http://127.0.0.1:8000/v1
export TOKENHUB_API_KEY=EMPTY

bash scripts/run_on_remote.sh smoke --quick
bash scripts/run_on_remote.sh engineering

# 正式性能 / KV cache 口径
export TOKENHUB_JOB="$PWD/configs/jobs/haiguang-hy3-admission.yaml"
bash scripts/run_on_remote.sh performance
bash scripts/run_on_remote.sh cache_hit
```

访问默认 IDC 地址前，需要先确保已通过 igate 开通到 `22.142.37.103:8000`。可先手动探活：

```bash
curl -sS http://22.142.37.103:8000/v1/models \
  -H "Authorization: Bearer tokenhub-test"
curl -sS http://22.142.37.103:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer tokenhub-test" \
  -d '{"model":"/model","messages":[{"role":"user","content":"ping"}],"max_tokens":16}'
```

报告写入 `reports/`。JSON 始终生成；没有 V4 xlsx 模板时仍能生成 Excel，但不会按 V4 模板行号排版。

### Offline 与 Online 可运行范围

这里的 **offline** 指服务器不能访问公网，但仍能通过内网访问待测模型 endpoint；**online** 指服务器可以访问 PyPI、HuggingFace、ModelScope 和 Docker Registry。

- **offline（使用项目自带 `vendor/wheels/` 创建的 `.venv`）**：可运行 `smoke`、`engineering`、`performance`、`capacity`、`availability` 和 `cache_hit`。这些套件只依赖项目本体、HTTP 客户端和基础报表库，所需依赖已包含在离线 wheels 中。具体条目仍可能因模型或硬件配置未声明对应能力而 SKIP。
- **online**：可运行上述全部套件；安装 `evalscope` 及数据集额外依赖后，还可运行 `accuracy`。效果评测会按需下载数据集，SWE-bench 还需要 Docker、评测镜像和 `swebench`，tau2 还需要 `tau2` 包及其数据。
- **`full` 的区别**：offline 环境中仍可启动 `full`，但当前离线包没有 `evalscope`，因此 `accuracy.evalscope` 会 SKIP；online 且效果评测依赖齐全时，`full` 才会实际执行 accuracy。

原因是 `vendor/wheels/` 目前只打包流水线本体所需的 httpx、PyYAML、openpyxl、rich 等基础依赖，没有打包 `evalscope`、`swebench`、`tau2`、评测数据集或 Docker 镜像。若要完全离线运行 accuracy，需要预先补齐这些 Python wheels、数据集缓存和 Docker 镜像，并将数据路径改为本地路径。

## 准备

有外网：

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

无外网：`bash scripts/install_offline.sh`（只读 `vendor/wheels/`）。

环境变量可覆盖 hardware endpoint（也可用 YAML 默认值）：

```bash
export TOKENHUB_BASE_URL="http://22.142.37.103:8000/v1"
export TOKENHUB_API_KEY="tokenhub-test"  # 本机无鉴权可改为 EMPTY，地址改 127.0.0.1
export TOKENHUB_MODEL="/model"
export TOKENHUB_ENGINE="sglang"          # vllm | sglang | custom
```

Hy3 job 已配置 Venus `hy3-external`（`http://v2.open.venus.oa.com/llmproxy/v1`）作为原厂端点。仓库 `.env` 保存了共享凭据，运行前执行 `set -a; source .env; set +a`。地址和模型可用 `OFFICIAL_BASE_URL` / `OFFICIAL_MODEL` 覆盖。

## 运行

```bash
# 列出当前 job 展开后的模块
python3 -m tokenhub_bench run -s smoke --list

# 列出全部已注册模块
python3 -m tokenhub_bench modules

# 冒烟
python3 -m tokenhub_bench run -s smoke --quick

# 完整工程验收
python3 -m tokenhub_bench run -s engineering

# 只跑一个 accuracy 数据集；可重复传入 --dataset
python3 -m tokenhub_bench run -s accuracy --dataset aime2026
python3 -m tokenhub_bench run -s accuracy --dataset tau2_bench_retail

# 只跑某几个模块
python3 -m tokenhub_bench run --only engineering.thinking engineering.auth

# 换地址：TOKENHUB_BASE_URL / TOKENHUB_API_KEY
# 换口径：-c configs/jobs/haiguang-hy3-admission.yaml
# 换卡：复制 job，改 hardware: 指向 configs/hardware/ 下另一份
```

报告写到 `reports/`：JSON + 回填后的 Excel。页眉含 model_id / hardware_id / profile_id。
退出码 `0` 允许 pass、warn 和 skip；`1` 表示存在 fail/error；`2` 表示配置文件不存在或启动参数无效。

## 模块化约定

1. **注册**：`@register("engineering.thinking")` 挂到全局 registry。
2. **编排**：准入剖面 `configs/profiles/*.yaml` 的 `suites` 决定跑哪些、按什么顺序。`$engineering` 会展开子套件。
3. **替换**：在 suite 项上写 `class: package.mod:ClassName`。见 `examples/custom_thinking.py`。
4. **模型契约**：`configs/models/`。Serving 事实（缓存、鉴权、挂载协议）在 `configs/hardware/`，装配时覆盖到 golden 投影。
5. **客户端**：所有 HTTP 走 `EndpointClient`。

## 效果评测

`accuracy.evalscope` 编排 `scripts/evalscope_run.sh`（PATH 上要有 `evalscope` 命令；当前 `aime26` 配置已用 EvalScope 1.11.0 验证）。冒烟剖面 `accuracy.limit: 5`；正式剖面跑全集。每个 `accuracy.datasets[]` 通过 `max_output_tokens` 单独限制生成长度，运行时会转换成 EvalScope 的 `max_tokens`。官方分数需补 `official` 字段。HLE 关闭多模态；LongBench-v2 冒烟只跑 `short`，正式剖面跑 `short` 和 `medium`，并加 `--ignore-errors`，避免单条超上下文把全集停掉。evalscope 不在 `vendor/wheels` 里，SWE-bench 还要 Docker，tau2 要额外安装并准备数据；已有本地 tau2 数据时可通过 `TAU2_LOCAL_PATH` 指定。未装 CLI 时该模块 SKIP，不算门禁失败。

单独运行 `availability` 时，因为当前进程中没有 capacity soak 指标，`soak_as_sla_proxy` 会 SKIP；使用 `full` 时 capacity 先运行，可复用其结果。smoke 为避免构造超大请求，不验证 262k 超窗策略，因此 `engineering.context_window` 会 WARN；须用 admission job 验证。Hy3 job 已配置 Venus `hy3-external` 原厂端点；只有环境中存在 `OFFICIAL_API_KEY` 时才会创建原厂客户端。`engineering.*` 探针会在供应商和原厂各跑一次，原厂明细及 check 级状态差异写入 JSON 和 Excel；原厂结果只作旁路对照，不改变供应商门禁结论。

## 性能压测

`performance` / `capacity` 对齐 Tokenhub `perf-kit`：用真实中文长文 jsonl，而不是 ASCII 垫料。正式档位为 `1k / 9k / 16k / 32k / 64k / 128k / 200k`，并发梯度 `1 → 8 → 32 → 64 → 128`，请求数与 kit 相同（20/100/250/400/500）。TTFT 仍按 V4 秒级门槛、并发 1、短生成测首 token；OTPS 和容量用 `max_tokens=4096`。正式容量梯度按 kit `bench-all` 跑全档 × 全并发，峰值 TPM 必须达到 `capacity.promised_tpm`；smoke 只跑 `1k`，单并发模块发 5 条，容量的并发 8 档发 8 条，且只验证能测得 TPM。正式 soak 并发 128。请求会带上模型契约的关 thinking 参数（当前 Hy3 走 `chat_template_kwargs.reasoning_effort=no_think`）。引擎仍是本仓库的 HTTP 压测，不调用 `evalscope perf`。

数据集在 `datasets/perf_zh/`（约 2.5GB jsonl，不进 Git）。缺少某档时该 TTFT 档位 SKIP，不回退成长 ASCII 垫料。

```bash
python3 -m tokenhub_bench run -c configs/jobs/haiguang-hy3-admission.yaml -s performance
```

## 缓存命中率

`cache_hit.hit_rate` 读 `datasets/cache_variants/cache_{档}_{场景}.jsonl`，不再用合成 ASCII 前缀。命中率 = 实测请求 `sum(cached_tokens) / sum(prompt_tokens)`（warmup 不计入）。请求会带上模型契约的关 thinking 参数。缺文件则该档 SKIP。

| 场景 | 数据 | 门槛 |
| --- | --- | --- |
| `hot` | 同一条共享前缀重复 | ≥ `cache_hit.min_required`（0.79）；低于模型 `official_baseline`（Hy3 为 0.90）记 warn |
| `cold` | 每条 user 头注入 UUID，打断前缀 | ≤ `cache_hit.cold_max`（0.20） |
| `mix50` | 约一半共享前缀、一半 UUID | 只要求请求成功，不卡命中率门槛 |

`cached_tokens` 优先走硬件契约里的路径，否则依次读 `usage.cached_tokens`、`usage.prompt_tokens_details.cached_tokens`、`usage.prompt_cache_hit_tokens`。hot / mix50 先 warmup（正式 3 次、smoke 1 次）；cold 不做 warmup。测量阶段 **一条 jsonl 一行一次请求**，不循环复用。

| 剖面 | 档位 | warmup | 每组请求数 | `max_tokens` |
| --- | --- | --- | --- | --- |
| smoke | `1k` | 1 | 5（`smoke_n`） | 32 |
| `--quick` | 首档 | 1 | 4（`quick_n`） | 32 |
| admission / full | `1k / 4k / 8k / 16k` | 3 | **整份 jsonl**（1k 约 200 条，4k/8k/16k 多为 500） | 32 |

jsonl 随仓库提供，见 `datasets/cache_variants/README.md`。默认 smoke job **不会**跑 `cache_hit`，要显式 `-s cache_hit`。

**跑前必须清空 serving 侧 prefix / radix cache。** 否则上一轮 hot 的前缀会留在树上，cold 会假阳性命中（例如 1k/4k 打到 90%+ 而 FAIL）。SGLang 原生 flush 不在 `/v1` 下，且要求当前没有 in-flight 请求：

```bash
curl -sS -X POST "http://22.142.37.103:8000/flush_cache?timeout=30" \
  -H "Authorization: Bearer tokenhub-test"
# 空闲后再跑；建议等几十秒
PYTHONPATH=. python3 -m tokenhub_bench run \
  -c configs/jobs/haiguang-hy3-admission.yaml -s cache_hit
```

## 目录

```
configs/jobs/haiguang-hy3.yaml
configs/jobs/haiguang-hy3-admission.yaml
configs/models/hy3-channel.yaml
configs/hardware/hygon-sglang.yaml
configs/profiles/smoke.yaml
configs/profiles/tokenhub-v4-admission.yaml
scripts/evalscope_run.sh
datasets/perf_zh/
datasets/cache_variants/
tokenhub_bench/modules/engineering/
tokenhub_bench/modules/performance/
tokenhub_bench/modules/cache_hit/
tokenhub_bench/clients/http.py
tokenhub_bench/reporters/
```
