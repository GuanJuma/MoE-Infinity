"""Example of replacing a built-in module without editing the package.

In configs/profiles/*.yaml (suites) or a job overlay:

  suites:
    engineering:
      - id: engineering.thinking
        class: examples.custom_thinking:CustomThinkingModule
        params:
          prompt: "1+1=?"
"""

from tokenhub_bench.modules.engineering.thinking import ThinkingModule


class CustomThinkingModule(ThinkingModule):
    title = "思考模式（自定义）"

    def run(self):
        # Delegate to the built-in implementation, or rewrite entirely.
        return super().run()
