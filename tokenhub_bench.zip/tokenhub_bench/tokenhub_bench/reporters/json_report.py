from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from tokenhub_bench.i18n import localize_payload
from tokenhub_bench.types import ModuleResult


def write_json(path: Path, payload: dict[str, Any], results: list[ModuleResult] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    body = localize_payload(payload, results or []) if results is not None else payload
    with path.open("w", encoding="utf-8") as f:
        json.dump(body, f, ensure_ascii=False, indent=2, default=str)
