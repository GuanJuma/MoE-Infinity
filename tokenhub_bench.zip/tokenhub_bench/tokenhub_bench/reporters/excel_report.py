from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell

from tokenhub_bench.i18n import localize_payload, zh_check_name, zh_status, zh_text
from tokenhub_bench.types import ModuleResult

VENDOR_COL = "E"
NOTES_COL = "G"

ROW_VENDOR_COL = {
    **{r: "D" for r in range(46, 56)},
    **{r: "D" for r in range(59, 65)},
    **{r: "D" for r in range(67, 70)},
    72: "C",
    73: "C",
    76: "C",
    77: "C",
    78: "C",
    85: "D",
    86: "D",
    **{r: "D" for r in range(89, 101)},
}


def _set(ws, coord: str, value: str) -> None:
    cell = ws[coord]
    if isinstance(cell, MergedCell):
        for rng in ws.merged_cells.ranges:
            if coord in rng:
                cell = ws.cell(rng.min_row, rng.min_col)
                break
    prev = cell.value
    if prev in (None, ""):
        cell.value = value
    else:
        cell.value = (str(prev) + "\n" + value)[:32000]


def write_excel(template: Path, dest: Path, payload: dict[str, Any], results: list[ModuleResult]) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if template.exists():
        shutil.copyfile(template, dest)
        wb = load_workbook(dest)
    else:
        from openpyxl import Workbook

        wb = Workbook()
    ws = wb.active
    zh = localize_payload(payload, results)
    vendor = zh.get("供应商") or {}
    header = (
        f"【自动流水线】供应商={vendor.get('名称')} "
        f"模型={vendor.get('模型')} "
        f"契约={vendor.get('模型契约')} "
        f"硬件={vendor.get('硬件')} "
        f"设备={vendor.get('设备类型')} "
        f"剖面={vendor.get('准入剖面')} "
        f"引擎={vendor.get('推理引擎')} "
        f"套件={zh.get('套件')} "
        f"汇总={zh.get('汇总')}"
    )
    _set(ws, "A2", header)

    by_row: dict[int, list[ModuleResult]] = {}
    for r in results:
        for row in r.template_rows or []:
            by_row.setdefault(int(row), []).append(r)

    for row, mods in by_row.items():
        texts = []
        notes = []
        for m in mods:
            texts.append(f"【{zh_status(m.status)}】{m.title}：{zh_text(m.vendor_summary) or m.title}")
            if m.notes:
                notes.append(zh_text(m.notes))
            for c in m.checks:
                extra = zh_text(c.detail) or ""
                if extra:
                    line = f"  - {zh_status(c.status)}：{zh_check_name(c.name)}：{extra}"
                else:
                    line = f"  - {zh_status(c.status)}：{zh_check_name(c.name)}"
                texts.append(line)
        col = ROW_VENDOR_COL.get(row, VENDOR_COL)
        _set(ws, f"{col}{row}", "\n".join(texts)[:32000])
        if notes:
            _set(ws, f"{NOTES_COL}{row}", "\n".join(str(n) for n in notes if n)[:8000])

    dump = wb.create_sheet("流水线明细")
    dump["A1"] = "模块编号"
    dump["B1"] = "标题"
    dump["C1"] = "结论"
    dump["D1"] = "供应商实测摘要"
    dump["E1"] = "指标"
    dump["F1"] = "耗时秒"
    for i, r in enumerate(results, start=2):
        dump[f"A{i}"] = r.module_id
        dump[f"B{i}"] = r.title
        dump[f"C{i}"] = zh_status(r.status)
        dump[f"D{i}"] = zh_text(r.vendor_summary)
        dump[f"E{i}"] = str(r.metrics)[:32000]
        dump[f"F{i}"] = round(r.duration_s, 3)

    official_modules = payload.get("official_modules") or []
    if official_modules:
        ref = wb.create_sheet("原厂对比")
        headers = ["模块编号", "标题", "模块结论", "原厂摘要", "检查项", "检查结论", "实际值", "说明"]
        for col, value in enumerate(headers, start=1):
            ref.cell(1, col, value)
        row = 2
        for module in official_modules:
            checks = module.get("checks") or [{}]
            for check in checks:
                ref.cell(row, 1, module.get("module_id"))
                ref.cell(row, 2, module.get("title"))
                ref.cell(row, 3, zh_status(module.get("status")))
                ref.cell(row, 4, zh_text(module.get("vendor_summary") or ""))
                ref.cell(row, 5, zh_check_name(check.get("name") or ""))
                ref.cell(row, 6, zh_status(check.get("status")))
                ref.cell(row, 7, str(check.get("actual"))[:32000])
                ref.cell(row, 8, zh_text(check.get("detail") or ""))
                row += 1

        differences = payload.get("official_differences") or []
        if differences:
            diff_ws = wb.create_sheet("原厂差异")
            diff_headers = ["层级", "模块编号", "检查项", "供应商结论", "原厂结论"]
            for col, value in enumerate(diff_headers, start=1):
                diff_ws.cell(1, col, value)
            for row, difference in enumerate(differences, start=2):
                diff_ws.cell(row, 1, difference.get("level"))
                diff_ws.cell(row, 2, difference.get("module_id"))
                diff_ws.cell(row, 3, zh_check_name(difference.get("check") or ""))
                diff_ws.cell(row, 4, zh_status(difference.get("vendor_status")))
                diff_ws.cell(row, 5, zh_status(difference.get("official_status")))

    wb.save(dest)
