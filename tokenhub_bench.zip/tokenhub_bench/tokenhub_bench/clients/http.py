from __future__ import annotations

import json
import time
from typing import Any, Iterator, Optional
from urllib.parse import urljoin

import httpx

from tokenhub_bench.types import HttpResult


def _join(base: str, path: str) -> str:
    if path.startswith("http"):
        return path
    if not base.endswith("/"):
        base += "/"
    return urljoin(base, path.lstrip("/"))


def extract_usage(payload: Optional[dict[str, Any]]) -> dict[str, Any]:
    if not payload:
        return {}
    usage = payload.get("usage") or {}
    if not usage:
        choices = payload.get("choices") or []
        if choices and isinstance(choices[0], dict):
            usage = choices[0].get("usage") or {}
    return dict(usage) if isinstance(usage, dict) else {}


def message_from(payload: Optional[dict[str, Any]]) -> dict[str, Any]:
    if not payload:
        return {}
    choices = payload.get("choices") or []
    if not choices:
        # Anthropic / Responses shapes
        if "content" in payload and "role" in payload:
            return payload
        output = payload.get("output") or payload.get("message") or {}
        if isinstance(output, dict):
            return output
        return {}
    ch = choices[0] if isinstance(choices[0], dict) else {}
    return ch.get("message") or ch.get("delta") or {}


def finish_reason(payload: Optional[dict[str, Any]]) -> Optional[str]:
    if not payload:
        return None
    choices = payload.get("choices") or []
    if choices and isinstance(choices[0], dict):
        return choices[0].get("finish_reason") or choices[0].get("native_finish_reason")
    return payload.get("stop_reason") or payload.get("status")


def cached_tokens(usage: dict[str, Any], paths: Optional[list[str]] = None) -> Optional[int]:
    if not usage:
        return None
    if paths:
        for raw_path in paths:
            parts = str(raw_path).split(".")
            if parts and parts[0] == "usage":
                parts = parts[1:]
            value: Any = usage
            for part in parts:
                if not isinstance(value, dict) or part not in value:
                    value = None
                    break
                value = value[part]
            if value is not None:
                return int(value)
    if "cached_tokens" in usage and usage["cached_tokens"] is not None:
        return int(usage["cached_tokens"])
    details = usage.get("prompt_tokens_details") or usage.get("input_tokens_details") or {}
    if isinstance(details, dict) and details.get("cached_tokens") is not None:
        return int(details["cached_tokens"])
    if usage.get("prompt_cache_hit_tokens") is not None:
        return int(usage["prompt_cache_hit_tokens"])
    return None


def content_text(value: Any) -> str:
    """Flatten text from string or typed content-part payloads."""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "".join(content_text(part) for part in value)
    if isinstance(value, dict):
        for key in ("text", "content", "value"):
            text = content_text(value.get(key))
            if text:
                return text
    return ""


class EndpointClient:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        timeout_s: float = 900,
        name: str = "vendor",
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout_s = timeout_s
        self.name = name
        self._client = httpx.Client(timeout=httpx.Timeout(timeout_s, connect=30.0))

    def close(self) -> None:
        self._client.close()

    def headers(self, extra: Optional[dict[str, str]] = None, auth: bool = True) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if auth and self.api_key and self.api_key != "EMPTY":
            h["Authorization"] = f"Bearer {self.api_key}"
        if extra:
            h.update(extra)
        return h

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        headers: Optional[dict[str, str]] = None,
        auth: bool = True,
        timeout_s: Optional[float] = None,
    ) -> HttpResult:
        url = _join(self.base_url, path)
        t0 = time.perf_counter()
        try:
            resp = self._client.request(
                method,
                url,
                json=json_body,
                headers=self.headers(headers, auth=auth),
                timeout=timeout_s or self.timeout_s,
            )
            elapsed = time.perf_counter() - t0
            text = resp.text
            parsed = None
            try:
                parsed = resp.json()
            except Exception:
                parsed = None
            return HttpResult(
                ok=resp.is_success,
                status_code=resp.status_code,
                elapsed_s=elapsed,
                json=parsed if isinstance(parsed, dict) else None,
                text=text,
                headers={k.lower(): v for k, v in resp.headers.items()},
                usage=extract_usage(parsed if isinstance(parsed, dict) else None),
            )
        except Exception as e:
            return HttpResult(
                ok=False,
                status_code=0,
                elapsed_s=time.perf_counter() - t0,
                error=str(e),
            )

    def chat(
        self,
        messages: list[dict[str, Any]],
        *,
        extra: Optional[dict[str, Any]] = None,
        stream: bool = False,
        path: str = "/chat/completions",
        **kwargs: Any,
    ) -> HttpResult:
        body: dict[str, Any] = {"model": self.model, "messages": messages, "stream": stream}
        body.update(kwargs)
        if extra:
            body.update(extra)
        if stream:
            return self.chat_stream(body, path=path)
        result = self.request("POST", path, json_body=body)
        if result.json:
            result.usage = extract_usage(result.json)
        return result

    def chat_stream(self, body: dict[str, Any], path: str = "/chat/completions") -> HttpResult:
        url = _join(self.base_url, path)
        body = dict(body)
        body["stream"] = True
        t0 = time.perf_counter()
        ttft: Optional[float] = None
        chunks: list[dict[str, Any]] = []
        raw: list[str] = []
        usage: dict[str, Any] = {}
        last_json: Optional[dict[str, Any]] = None
        text_acc = []
        try:
            with self._client.stream(
                "POST",
                url,
                json=body,
                headers=self.headers(),
                timeout=self.timeout_s,
            ) as resp:
                status = resp.status_code
                headers = {k.lower(): v for k, v in resp.headers.items()}
                if status >= 400:
                    err_text = resp.read().decode("utf-8", errors="replace")
                    parsed = None
                    try:
                        parsed = json.loads(err_text)
                    except Exception:
                        parsed = None
                    return HttpResult(
                        ok=False,
                        status_code=status,
                        elapsed_s=time.perf_counter() - t0,
                        json=parsed if isinstance(parsed, dict) else None,
                        text=err_text,
                        headers=headers,
                    )
                for line in resp.iter_lines():
                    if not line:
                        continue
                    raw.append(line)
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        obj = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    chunks.append(obj)
                    last_json = obj
                    u = extract_usage(obj)
                    if u:
                        usage = u
                    delta = message_from(obj)
                    piece = ""
                    if isinstance(delta, dict):
                        piece = content_text(delta.get("content")) + content_text(delta.get("reasoning_content"))
                    if piece and ttft is None:
                        ttft = time.perf_counter() - t0
                    if piece:
                        text_acc.append(piece)
                return HttpResult(
                    ok=True,
                    status_code=status,
                    elapsed_s=time.perf_counter() - t0,
                    json=last_json,
                    text="".join(text_acc),
                    headers=headers,
                    ttft_s=ttft,
                    chunks=chunks,
                    usage=usage,
                    raw_sse=raw,
                )
        except Exception as e:
            return HttpResult(
                ok=False,
                status_code=0,
                elapsed_s=time.perf_counter() - t0,
                error=str(e),
                ttft_s=ttft,
                chunks=chunks,
                usage=usage,
                raw_sse=raw,
            )

    def responses(self, payload: dict[str, Any], path: str = "/responses") -> HttpResult:
        body = {"model": self.model, **payload}
        return self.request("POST", path, json_body=body)

    def messages_anthropic(self, payload: dict[str, Any], path: str = "/messages") -> HttpResult:
        body = {"model": self.model, **payload}
        headers = {"anthropic-version": "2023-06-01"}
        if self.api_key and self.api_key != "EMPTY":
            headers["x-api-key"] = self.api_key
        # Anthropic 官方鉴权头是 x-api-key；sglang/vLLM 的鉴权中间件只认 Authorization: Bearer。
        # 两个头都带：协议探测不会因鉴权头约定差异被 401 挡住。
        return self.request("POST", path, json_body=body, headers=headers, auth=True)

    def probe_path(self, path: str) -> HttpResult:
        return self.request(
            "POST",
            path,
            json_body={"model": self.model, "messages": [{"role": "user", "content": "ping"}]},
        )


def iter_stream_contents(chunks: list[dict[str, Any]]) -> Iterator[tuple[str, str]]:
    """Yield (field, text) for reasoning_content / content / tool_calls pieces."""
    for obj in chunks:
        choices = obj.get("choices") or []
        if not choices:
            continue
        delta = choices[0].get("delta") or {}
        rc = delta.get("reasoning_content")
        if rc:
            yield "reasoning_content", rc
        c = delta.get("content")
        if c:
            yield "content", c
        for tc in delta.get("tool_calls") or []:
            yield "tool_calls", json.dumps(tc, ensure_ascii=False)
