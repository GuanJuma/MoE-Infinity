from __future__ import annotations

import argparse
import sys
from pathlib import Path

from tokenhub_bench.config import Config
from tokenhub_bench.pipeline import Pipeline


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="tokenhub-bench",
        description="Modular Tokenhub vendor-admission pipeline (model × hardware × profile)",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    run = sub.add_parser("run", help="run a suite")
    run.add_argument("-c", "--config", default="configs/jobs/haiguang-hy3.yaml")
    run.add_argument("-s", "--suite", default="smoke", help="smoke|engineering|accuracy|performance|capacity|availability|cache_hit|full")
    run.add_argument("--only", nargs="*", help="run specific module ids, ignore suite expansion")
    run.add_argument(
        "--dataset",
        dest="datasets",
        action="append",
        help="run only this accuracy dataset id; repeat to select multiple datasets",
    )
    run.add_argument("--quick", action="store_true", help="shrink repeats/duration for a dry run")
    run.add_argument("--list", action="store_true", help="list modules in the suite and exit")

    ls = sub.add_parser("modules", help="list registered modules")
    ls.add_argument("-c", "--config", default="configs/jobs/haiguang-hy3.yaml")

    args = p.parse_args(argv)
    cfg_path = Path(args.config)
    if not cfg_path.exists():
        print(f"config not found: {cfg_path}", file=sys.stderr)
        return 2
    cfg = Config.load(cfg_path)

    if args.cmd == "run" and args.datasets:
        module_ids = args.only or cfg.resolve_suite(args.suite)
        if "accuracy.evalscope" not in module_ids:
            print("--dataset requires a suite containing accuracy.evalscope", file=sys.stderr)
            return 2
        available = {
            str(ds.get("id"))
            for ds in (cfg.get("accuracy", "datasets", default=[]) or [])
            if ds.get("id")
        }
        unknown = [dataset for dataset in args.datasets if dataset not in available]
        if unknown:
            print(
                f"unknown accuracy dataset(s): {', '.join(unknown)}. "
                f"available: {', '.join(sorted(available))}",
                file=sys.stderr,
            )
            return 2

    if args.cmd == "modules" or (args.cmd == "run" and args.list):
        from tokenhub_bench.pipeline import _import_builtin_modules
        from tokenhub_bench.registry import all_ids

        _import_builtin_modules()
        if args.cmd == "run":
            ids = args.only or cfg.resolve_suite(args.suite)
            print("suite modules:")
            for i in ids:
                print(f"  {i}")
            if args.datasets:
                print("accuracy datasets:")
                for dataset in args.datasets:
                    print(f"  {dataset}")
        else:
            print("registered modules:")
            for i in all_ids():
                print(f"  {i}")
        return 0

    pipe = Pipeline(cfg, quick=args.quick, only=args.only, datasets=args.datasets)
    payload = pipe.run(args.suite)
    summary = payload.get("summary") or {}
    if summary.get("fail") or summary.get("error"):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
