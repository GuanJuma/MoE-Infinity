from __future__ import annotations

import os
import re
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml

_ENV_PATTERN = re.compile(r"\$\{([A-Z0-9_]+)(?::-([^}]*))?\}")

# Serving facts live on hardware and overlay the model contract.
_HARDWARE_GOLDEN_KEYS = (
    "protocols",
    "cache",
    "auth",
    "web_search",
    "error_body_must_not_contain",
    "tool_choice_values",
)
# Nested serving overlays keep model-layer policy keys (e.g. unknown_cache_param).
_HARDWARE_DEEP_MERGE_KEYS = frozenset({"cache", "protocols"})

def _expand_env(value: Any) -> Any:
    if isinstance(value, str):
        def repl(m: re.Match[str]) -> str:
            name, default = m.group(1), m.group(2)
            return os.environ.get(name, default if default is not None else "")

        return _ENV_PATTERN.sub(repl, value)
    if isinstance(value, list):
        return [_expand_env(v) for v in value]
    if isinstance(value, dict):
        return {k: _expand_env(v) for k, v in value.items()}
    return value


def load_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return _expand_env(data)


def _repo_root(path: Path) -> Path:
    for p in [path.parent, *path.parents]:
        if p.name == "configs":
            return p.parent
    return path.parent


def _is_job_config(data: dict[str, Any]) -> bool:
    return bool(data.get("model") and data.get("hardware") and data.get("profile"))


def _axis_path(root: Path, kind: str, ref: str) -> Path:
    raw = str(ref).strip()
    candidate = Path(raw)
    if candidate.suffix in {".yaml", ".yml"}:
        return candidate if candidate.is_absolute() else (root / candidate)
    return root / "configs" / kind / f"{raw}.yaml"


def _project_golden(
    model: dict[str, Any],
    hardware: dict[str, Any],
    profile: dict[str, Any],
) -> dict[str, Any]:
    """Model contract with hardware serving facts and profile cache_hit.min_required."""
    golden = deepcopy(model)
    for key in _HARDWARE_GOLDEN_KEYS:
        if key not in hardware or hardware[key] is None:
            continue
        if (
            key in _HARDWARE_DEEP_MERGE_KEYS
            and isinstance(golden.get(key), dict)
            and isinstance(hardware[key], dict)
        ):
            golden[key] = {**deepcopy(golden[key]), **deepcopy(hardware[key])}
        else:
            golden[key] = deepcopy(hardware[key])
    if hardware.get("context_window") is not None:
        golden["context_window"] = hardware["context_window"]
    cache_hit = dict(golden.get("cache_hit") or {})
    prof_hit = profile.get("cache_hit") or {}
    if isinstance(prof_hit, dict) and "min_required" in prof_hit:
        cache_hit["min_required"] = prof_hit["min_required"]
    if cache_hit:
        golden["cache_hit"] = cache_hit
    return golden


def _project_vendor(job: dict[str, Any], hardware: dict[str, Any]) -> dict[str, Any]:
    endpoint = deepcopy(hardware.get("endpoint") or {})
    overlay = (job.get("overlay") or {}).get("endpoint") or {}
    if overlay:
        endpoint.update(deepcopy(overlay))
    vendor = {
        "name": endpoint.pop("name", None) or hardware.get("id"),
        "engine": hardware.get("engine"),
        "device_class": hardware.get("device_class"),
        **endpoint,
    }
    for key in ("rate_limit_policy", "ban_policy", "rto", "revoked_api_key"):
        if hardware.get(key) is not None:
            vendor[key] = deepcopy(hardware[key])
        elif endpoint.get(key) is not None:
            vendor[key] = endpoint[key]
    return vendor


def _project_data(
    job: dict[str, Any],
    hardware: dict[str, Any],
    profile: dict[str, Any],
) -> dict[str, Any]:
    data = deepcopy(profile)
    data["vendor"] = _project_vendor(job, hardware)
    data["official"] = deepcopy(job.get("official") or {})
    return data


def _envelope_warnings(hardware: dict[str, Any], profile: dict[str, Any], model: dict[str, Any]) -> list[str]:
    env = hardware.get("envelope") or {}
    if not env:
        return []
    warnings: list[str] = []
    cap = profile.get("capacity") or {}
    perf = profile.get("performance") or {}
    promised_tpm = cap.get("promised_tpm")
    if env.get("tpm") is not None and promised_tpm is not None and float(promised_tpm) > float(env["tpm"]):
        warnings.append(f"profile promised_tpm={promised_tpm} exceeds hardware envelope tpm={env['tpm']}")
    promised_rpm = cap.get("promised_rpm")
    if env.get("rpm") is not None and promised_rpm is not None and float(promised_rpm) > float(env["rpm"]):
        warnings.append(f"profile promised_rpm={promised_rpm} exceeds hardware envelope rpm={env['rpm']}")
    otps_need = perf.get("otps_min_tokens_per_s") or model.get("otps_min_tokens_per_s")
    if env.get("otps") is not None and otps_need is not None and float(otps_need) > float(env["otps"]):
        warnings.append(f"profile/model otps>={otps_need} exceeds hardware envelope otps={env['otps']}")
    return warnings


class Config:
    def __init__(
        self,
        data: dict[str, Any],
        root: Path,
        *,
        job: dict[str, Any] | None = None,
        model: dict[str, Any] | None = None,
        hardware: dict[str, Any] | None = None,
        profile: dict[str, Any] | None = None,
        golden: dict[str, Any] | None = None,
        composed: bool = False,
    ):
        self.root = root
        self.job = job or {}
        self.model = model or {}
        self.hardware = hardware or {}
        self.profile = profile or {}
        self._composed = composed
        if composed:
            self.golden = golden if golden is not None else _project_golden(
                self.model, self.hardware, self.profile
            )
            self.data = data
        else:
            self.data = data
            if golden is not None:
                self.golden = golden
            elif data.get("golden"):
                self.golden = load_yaml(root / data["golden"])
            else:
                self.golden = {}
            self.model = self.model or deepcopy(self.golden)
            self.hardware = self.hardware or {}
            self.profile = self.profile or deepcopy(data)

    @classmethod
    def load(cls, path: str | Path) -> "Config":
        path = Path(path).resolve()
        root = _repo_root(path)
        data = load_yaml(path)
        if _is_job_config(data):
            return cls._load_job(data, root)
        return cls(data, root, composed=False)

    @classmethod
    def _load_job(cls, job: dict[str, Any], root: Path) -> "Config":
        model_path = _axis_path(root, "models", str(job["model"]))
        hw_path = _axis_path(root, "hardware", str(job["hardware"]))
        prof_path = _axis_path(root, "profiles", str(job["profile"]))
        for p, label in ((model_path, "model"), (hw_path, "hardware"), (prof_path, "profile")):
            if not p.exists():
                raise FileNotFoundError(f"{label} config not found: {p}")
        model = load_yaml(model_path)
        hardware = load_yaml(hw_path)
        profile = load_yaml(prof_path)
        golden = _project_golden(model, hardware, profile)
        projected = _project_data(job, hardware, profile)
        return cls(
            projected,
            root,
            job=job,
            model=model,
            hardware=hardware,
            profile=profile,
            golden=golden,
            composed=True,
        )

    def get(self, *keys: str, default: Any = None) -> Any:
        cur: Any = self.data
        for k in keys:
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur

    def golden_get(self, *keys: str, default: Any = None) -> Any:
        cur: Any = self.golden
        for k in keys:
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur

    @property
    def vendor(self) -> dict[str, Any]:
        return self.data.get("vendor", {})

    @property
    def official(self) -> dict[str, Any]:
        return self.data.get("official", {})

    @property
    def identity(self) -> dict[str, Any]:
        if self._composed:
            return {
                "job": self.job.get("name"),
                "model_id": self.model.get("model_id"),
                "hardware_id": self.hardware.get("id"),
                "device_class": self.hardware.get("device_class"),
                "profile_id": self.profile.get("id"),
            }
        return {
            "job": None,
            "model_id": self.golden.get("model_id"),
            "hardware_id": self.vendor.get("name"),
            "device_class": self.vendor.get("device_class"),
            "profile_id": self.get("performance", "profile"),
        }

    def envelope_warnings(self) -> list[str]:
        if not self._composed:
            return []
        return _envelope_warnings(self.hardware, self.profile, self.model)

    def resolve_suite(self, name: str) -> list[str]:
        suites: dict[str, list] = self.data.get("suites", {})
        if name not in suites:
            raise KeyError(f"unknown suite: {name}. available: {list(suites)}")
        out: list[str] = []
        for item in suites[name]:
            if isinstance(item, str) and item.startswith("$"):
                out.extend(self.resolve_suite(item[1:]))
            elif isinstance(item, dict):
                mid = item.get("id") or item.get("module")
                if item.get("enabled", True) and mid:
                    out.append(str(mid))
            else:
                out.append(str(item))
        seen: set[str] = set()
        uniq: list[str] = []
        for m in out:
            if m not in seen:
                seen.add(m)
                uniq.append(m)
        return uniq

    def module_override(self, module_id: str) -> dict[str, Any]:
        for suite in self.data.get("suites", {}).values():
            for item in suite:
                if isinstance(item, dict) and (item.get("id") or item.get("module")) == module_id:
                    return deepcopy(item)
        return {}

    def profile_is_smoke(self) -> bool:
        return str(self.get("performance", "profile", default="smoke")).lower() == "smoke"
