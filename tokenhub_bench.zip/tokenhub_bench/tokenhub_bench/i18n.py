from __future__ import annotations

from typing import Any

from tokenhub_bench.types import Check, ModuleResult, Status

STATUS_ZH = {
    "pass": "通过",
    "fail": "未通过",
    "skip": "跳过",
    "warn": "警告",
    "error": "错误",
}

SUITE_ZH = {
    "smoke": "冒烟测试",
    "engineering": "工程验收",
    "accuracy": "效果验收",
    "performance": "性能验收",
    "capacity": "容量及稳定性验收",
    "availability": "可用性验收",
    "cache_hit": "缓存命中率验收",
    "full": "完整准入测试",
}

CHECK_NAME_ZH = {
    "default_call": "默认请求",
    "default_thinking_on": "默认开启思考模式",
    "default_thinking_off": "默认关闭思考模式",
    "thinking_location": "思考内容存放位置",
    "disable_thinking": "关闭思考模式",
    "disable_thinking_rejected": "关闭思考应被拒绝",
    "enable_keep_all": "显式开启思考并保留历史",
    "default_streaming": "默认是否流式",
    "enable_stream": "开启流式输出",
    "disable_stream": "关闭流式输出",
    "usage_every_chunk": "每个 chunk 都带 usage",
    "usage_not_every_chunk": "usage 不出现在每个 chunk",
    "usage_last_chunk": "末尾 chunk 返回 usage",
    "stream_delta_fields": "流式 delta 字段",
    "openai_chat_completions": "OpenAI Chat Completions 协议",
    "openai_responses": "OpenAI Responses 协议",
    "anthropic_messages": "Anthropic Messages 协议",
    "max_tokens": "max_tokens 控制输出长度",
    "max_completion_tokens": "max_completion_tokens 控制输出长度",
    "max_output_tokens": "max_output_tokens 控制输出长度",
    "in_window_request": "上下文窗口内请求",
    "overflow_behavior": "超出上下文窗口表现",
    "supported": "能力支持",
    "unsupported_like_official": "与模型契约一致不支持",
    "unsupported_inconclusive": "不支持模态探针无明确结论",
    "unexpected_accept": "模型不支持但供应商接受",
    "image_input": "图片输入",
    "audio_input": "音频输入",
    "video_input": "视频输入",
    "image_understood": "图片理解",
    "cache_probe_calls": "缓存探测请求",
    "cached_tokens_field": "已缓存 token 字段",
    "cache_mode": "缓存模式",
    "explicit_cache_param": "显式缓存参数",
    "cache_ttl": "缓存 TTL",
    "cache_hit_on_repeat": "重复请求命中缓存",
    "web_search": "联网搜索",
    "enable_via_builtin_tool": "通过内置工具开启联网搜索",
    "web_search_triggered": "触发联网搜索",
    "turn1": "第一轮对话",
    "turn1_content": "第一轮回复内容",
    "turn2": "第二轮对话",
    "context_carried": "多轮上下文保持",
    "no_garbled_or_empty": "无乱码/空回复",
    "finish_reason": "finish_reason",
    "eos_empty_content_ratio": "思考过程 EOS 导致空 content 比例",
    "request_success": "请求成功率",
    "empty_ratio_high": "空 content 比例偏高",
    "moderation_probe_error": "审核探测请求异常",
    "served_without_filter": "未触发内容审核",
    "green_net_closed": "绿网/内容审核已关闭",
    "bad_model": "错误模型名",
    "malformed_json_field": "非法字段类型",
    "empty_messages": "空 messages",
    "bad_model_no_vendor_leak": "错误模型名时错误信息无供应商泄漏",
    "malformed_json_field_no_vendor_leak": "非法字段时错误信息无供应商泄漏",
    "empty_messages_no_vendor_leak": "空 messages 时错误信息无供应商泄漏",
    "missing_authorization": "未传 Authorization",
    "invalid_api_key": "无效 API Key",
    "revoked_or_expired_token": "过期/吊销 Token",
    "valid_key_control": "合法 Key 对照",
    "response_json": "响应为 JSON",
    "no_duplicate_fields": "无重复字段",
    "required_fields_present": "必填字段非空",
    "no_garbled_or_train_leak": "无乱码或训练数据泄漏",
    "response_format_text": "response_format=text",
    "response_format_json_object": "response_format=json_object",
    "response_format_json_schema": "response_format=json_schema",
    "tool_choice_auto": "tool_choice=auto",
    "tool_choice_none": "tool_choice=none",
    "streaming_function_call": "流式工具调用",
    "tool_result_roundtrip": "工具结果回传",
    "serial_or_parallel_tools": "串行/并行工具调用",
    "no_spurious_tool_on_chitchat": "闲聊不误触发工具",
    "no_undefined_function": "不调用未定义函数",
    "tool_error_recovery": "工具错误后恢复",
    "empty_tools_boundary": "空 tools 边界",
    "unicode_emoji_codeblock": "emoji/unicode/代码块输入",
    "long_system_prompt": "超长 system prompt",
    "declared_policy": "供应商书面说明",
    "evalscope_not_installed": "未安装 evalscope",
    "warmup_success_rate": "预热请求成功率",
    "soak_success_rate": "持续压测成功率",
    "measured_tpm": "实测 TPM",
    "measured_rpm": "实测 RPM",
    "soak_as_sla_proxy": "用 soak 近似 SLA",
    "rto_peak": "高峰期 RTO",
    "rto_offpeak": "低峰期 RTO",
    "cache_hit_rate": "缓存 Token 比例",
    "cache_hit_hot_1k": "热缓存命中率 1k",
    "cache_hit_hot_4k": "热缓存命中率 4k",
    "cache_hit_hot_8k": "热缓存命中率 8k",
    "cache_hit_hot_16k": "热缓存命中率 16k",
    "cache_hit_cold_1k": "冷缓存未命中 1k",
    "cache_hit_cold_4k": "冷缓存未命中 4k",
    "cache_hit_cold_8k": "冷缓存未命中 8k",
    "cache_hit_cold_16k": "冷缓存未命中 16k",
    "cache_hit_mix50_1k": "混合前缀命中率 1k",
    "cache_hit_mix50_4k": "混合前缀命中率 4k",
    "cache_hit_mix50_8k": "混合前缀命中率 8k",
    "cache_hit_mix50_16k": "混合前缀命中率 16k",
    "below_official_baseline": "低于原厂缓存命中率基线",
}

DETAIL_ZH = (
    ("default request did not return thinking content", "默认请求未返回思考内容"),
    ("thinking leaked into content via <think>; model contract uses ", "思考内容写在 content 的 <think> 中，应按契约放在 "),
    ("model contract rejects thinking.disabled; vendor accepted it", "模型契约拒绝关闭思考，供应商却接受了"),
    ("model contract default stream=false", "模型契约默认非流式（stream=false）"),
    ("golden says streaming is on by default", "基线要求默认开启流式"),
    ("stream=true failed", "开启流式失败"),
    ("Responses endpoint not implemented", "未实现 Responses 接口"),
    ("vendor returned 404; model contract marks this protocol unknown", "供应商返回 404；模型契约将该协议标为未知"),
    ("protocol reachable", "协议可访问"),
    ("set vendor.revoked_api_key in config to test revoked tokens", "请在配置中填写 vendor.revoked_api_key 以测试吊销 Token"),
    ("TOKENHUB_API_KEY is empty — cluster may be open; confirm this is intended", "未配置 API Key，集群当前可能是开放访问，请确认是否符合准入要求"),
    ("raw JSON must not repeat content/usage keys at the same object level", "原始 JSON 同一层级不得重复 content/usage 等字段"),
    ("usage appeared in ", "usage 出现在 "),
    ("last_chunk_usage=", "末尾chunk含usage="),
    ("2xx, model contract supports this protocol", "模型契约支持该协议，应返回 2xx"),
    ("unsupported like model contract", "与模型契约一致不支持"),
    ("prompt/completion/total/cached tokens", "应包含 prompt/completion/total/cached tokens"),
    ("delta.reasoning_content then delta.content", "先输出 reasoning_content，再输出 content"),
    ("content + usage tokens", "必须返回 content 与 usage token 字段"),
    ("content_filter disabled / whitelist", "必须关闭内容审核或提供白名单"),
    ("probes were not rejected by content moderation", "探测请求未被内容审核拦截"),
    ("template requires 原厂对比; attach this ratio to the Excel 备注", "模板要求与原厂对比，请将此比例填入 Excel 备注"),
    ("model contract does not support web search", "模型契约不支持联网搜索"),
    ("model contract ignores unknown model id", "模型契约忽略未知模型名"),
    ("model contract does not require rejecting unsupported media", "模型契约不要求拒绝不支持的模态"),
)


def zh_status(value: Any) -> str:
    if isinstance(value, Status):
        value = value.value
    return STATUS_ZH.get(str(value), str(value))


def zh_check_name(name: str) -> str:
    if name in CHECK_NAME_ZH:
        return CHECK_NAME_ZH[name]
    if name.endswith("_no_vendor_leak"):
        return zh_check_name(name[: -len("_no_vendor_leak")]) + "（错误信息无供应商泄漏）"
    if name.startswith("ttft_"):
        return f"TTFT（{name[5:]}）"
    if name.startswith("otps_"):
        return f"OTPS（{name[5:]}）"
    if name.startswith("gradient_"):
        return f"梯度压测（{name[len('gradient_'):]}）"
    if name.endswith("_input"):
        kind = {"image": "图片", "audio": "音频", "video": "视频"}.get(name[:-6], name[:-6])
        return f"{kind}输入"
    return name


def zh_text(text: Any) -> Any:
    if not isinstance(text, str) or not text:
        return text
    out = text
    for en, zh in DETAIL_ZH:
        out = out.replace(en, zh)
    replacements = {
        "received ": "收到 ",
        " chunks": " 个 chunk",
        "non-stream JSON": "非流式 JSON",
        "SSE 2xx": "流式 2xx",
        "2xx chat completion": "Chat Completions 返回 2xx",
        "reasoning_content present": "返回 reasoning_content",
        "JSON object": "JSON 对象",
        "human confirmation": "需人工确认",
        "truncated": "输出被截断",
        "error scene": "错误场景",
    }
    for en, zh in replacements.items():
        out = out.replace(en, zh)
    return out


def localize_check(check: Check) -> dict[str, Any]:
    return {
        "名称": zh_check_name(check.name),
        "结论": zh_status(check.status),
        "期望": zh_text(check.expected) if isinstance(check.expected, str) else check.expected,
        "实际": check.actual,
        "说明": zh_text(check.detail),
    }


def localize_module(result: ModuleResult) -> dict[str, Any]:
    return {
        "模块编号": result.module_id,
        "标题": result.title,
        "模板行": result.template_rows,
        "结论": zh_status(result.status),
        "供应商实测摘要": zh_text(result.vendor_summary),
        "备注": zh_text(result.notes),
        "指标": result.metrics,
        "耗时秒": round(result.duration_s, 3),
        "检查项": [localize_check(c) for c in result.checks],
    }


def localize_payload(payload: dict[str, Any], results: list[ModuleResult]) -> dict[str, Any]:
    summary = payload.get("summary") or {}
    zh_summary = {}
    for k, v in summary.items():
        if k == "total":
            zh_summary["合计"] = v
        else:
            zh_summary[zh_status(k)] = v
    vendor = payload.get("vendor") or {}
    return {
        "套件": SUITE_ZH.get(str(payload.get("suite")), payload.get("suite")),
        "开始时间": payload.get("started_at"),
        "结束时间": payload.get("finished_at"),
        "耗时秒": payload.get("duration_s"),
        "供应商": {
            "名称": vendor.get("name"),
            "地址": vendor.get("base_url"),
            "模型": vendor.get("model"),
            "推理引擎": vendor.get("engine"),
            "模型契约": vendor.get("model_id"),
            "硬件": vendor.get("hardware_id"),
            "设备类型": vendor.get("device_class"),
            "准入剖面": vendor.get("profile_id"),
            "实验": vendor.get("job"),
        },
        "身份": payload.get("identity") or {},
        "包络警告": payload.get("envelope_warnings") or [],
        "是否对比原厂": "是" if payload.get("official_compare") else "否",
        "原厂端点": payload.get("official"),
        "原厂模块": payload.get("official_modules") or [],
        "原厂差异": payload.get("official_differences") or [],
        "汇总": zh_summary,
        "模块": [localize_module(r) for r in results],
    }
