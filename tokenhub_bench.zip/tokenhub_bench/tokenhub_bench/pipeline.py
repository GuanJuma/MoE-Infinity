from __future__ import annotations

import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from rich.console import Console
from rich.table import Table

from tokenhub_bench.clients.http import EndpointClient
from tokenhub_bench.config import Config
from tokenhub_bench.modules.base import RunContext
from tokenhub_bench.registry import resolve
from tokenhub_bench.reporters.excel_report import write_excel
from tokenhub_bench.reporters.json_report import write_json
from tokenhub_bench.types import ModuleResult, Status

console = Console()


def _make_client(block: dict[str, Any], name: str) -> EndpointClient:
    return EndpointClient(
        base_url=str(block.get("base_url") or ""),
        api_key=str(block.get("api_key") or ""),
        model=str(block.get("model") or ""),
        timeout_s=float(block.get("timeout_s") or 900),
        name=name,
    )


def _import_builtin_modules() -> None:
    # Side-effect imports populate the registry.
    from tokenhub_bench.modules import accuracy as _a  # noqa: F401
    from tokenhub_bench.modules import availability as _av  # noqa: F401
    from tokenhub_bench.modules import cache_hit as _ch  # noqa: F401
    from tokenhub_bench.modules import capacity as _c  # noqa: F401
    from tokenhub_bench.modules import engineering as _e  # noqa: F401
    from tokenhub_bench.modules import performance as _p  # noqa: F401


class Pipeline:
    def __init__(
        self,
        cfg: Config,
        quick: bool = False,
        only: Optional[list[str]] = None,
        datasets: Optional[list[str]] = None,
    ):
        self.cfg = cfg
        self.quick = quick
        self.only = only
        self.datasets = datasets

    def run(self, suite: str) -> dict[str, Any]:
        _import_builtin_modules()
        module_ids = self.only or self.cfg.resolve_suite(suite)
        vendor = _make_client(self.cfg.vendor, "vendor")
        official = None
        if self.cfg.official.get("enabled") and self.cfg.official.get("api_key"):
            official = _make_client(self.cfg.official, "official")
        ctx = RunContext(cfg=self.cfg, vendor=vendor, official=official, quick=self.quick)
        official_ctx = RunContext(cfg=self.cfg, vendor=official, quick=self.quick) if official else None
        if self.datasets:
            ctx.extras["accuracy_datasets"] = set(self.datasets)
        ident = self.cfg.identity
        envelope_warnings = self.cfg.envelope_warnings()
        for w in envelope_warnings:
            console.print(f"[yellow]WARN[/yellow] envelope: {w}")
        results: list[ModuleResult] = []
        official_results: list[ModuleResult] = []
        started = datetime.now(timezone.utc).isoformat()
        t0 = time.perf_counter()
        try:
            for mid in module_ids:
                override = self.cfg.module_override(mid)
                cls = resolve(mid, override.get("class"))
                params = override.get("params") or {}
                console.rule(f"[bold]{mid}")
                mod = cls(ctx, params)
                st = time.perf_counter()
                try:
                    result = mod.run()
                except Exception as e:
                    from tokenhub_bench.types import Check, ModuleResult as MR

                    result = MR(
                        module_id=mid,
                        title=getattr(cls, "title", mid),
                        template_rows=getattr(cls, "template_rows", []),
                        status=Status.ERROR,
                        checks=[Check(name="uncaught", status=Status.ERROR, detail=str(e))],
                        notes=traceback.format_exc(),
                        vendor_summary=f"uncaught: {e}",
                    )
                result.duration_s = time.perf_counter() - st
                results.append(result)
                color = {
                    Status.PASS: "green",
                    Status.FAIL: "red",
                    Status.SKIP: "yellow",
                    Status.WARN: "yellow",
                    Status.ERROR: "red",
                }[result.status]
                console.print(f"[{color}]{result.status.value}[/{color}] {result.title} ({result.duration_s:.1f}s)")
                for c in result.checks:
                    console.print(f"  - {c.status.value}: {c.name} {c.detail}")

                # Engineering comparison is observational: run the same probe against
                # the reference endpoint, but never let its status change vendor admission.
                if official_ctx and mid.startswith("engineering."):
                    official_mod = cls(official_ctx, params)
                    official_started = time.perf_counter()
                    try:
                        official_result = official_mod.run()
                    except Exception as e:
                        from tokenhub_bench.types import Check

                        official_result = ModuleResult(
                            module_id=mid,
                            title=official_mod.title,
                            template_rows=official_mod.template_rows,
                            status=Status.ERROR,
                            checks=[Check(name="uncaught", status=Status.ERROR, detail=str(e))],
                            notes=traceback.format_exc(),
                            vendor_summary=f"uncaught: {e}",
                        )
                    official_result.duration_s = time.perf_counter() - official_started
                    official_results.append(official_result)
                    console.print(
                        f"  [cyan]official[/cyan]: {official_result.status.value} "
                        f"({official_result.duration_s:.1f}s)"
                    )
        finally:
            vendor.close()
            if official:
                official.close()

        payload = {
            "suite": suite,
            "started_at": started,
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "duration_s": time.perf_counter() - t0,
            "vendor": {
                "name": self.cfg.vendor.get("name"),
                "base_url": self.cfg.vendor.get("base_url"),
                "model": self.cfg.vendor.get("model"),
                "engine": self.cfg.vendor.get("engine"),
                "model_id": ident.get("model_id"),
                "hardware_id": ident.get("hardware_id"),
                "device_class": ident.get("device_class"),
                "profile_id": ident.get("profile_id"),
                "job": ident.get("job"),
            },
            "identity": ident,
            "envelope_warnings": envelope_warnings,
            "official_endpoint_enabled": bool(official),
            "official_compare": bool(official_results),
            "official": {
                "base_url": self.cfg.official.get("base_url"),
                "model": self.cfg.official.get("model"),
            }
            if official
            else None,
            "official_modules": [r.to_dict() for r in official_results],
            "official_differences": _official_differences(results, official_results),
            "summary": _summarize(results),
            "modules": [r.to_dict() for r in results],
        }
        out_dir = Path(self.cfg.get("report", "out_dir", default="reports"))
        if not out_dir.is_absolute():
            out_dir = self.cfg.root / out_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        json_path = out_dir / f"tokenhub_{suite}_{stamp}.json"
        if self.cfg.get("report", "json", default=True):
            write_json(json_path, payload, results)
            console.print(f"JSON report: {json_path}")
        if self.cfg.get("report", "excel", default=True):
            tpl = self.cfg.get("report", "excel_template")
            tpl_path = Path(tpl) if Path(str(tpl)).is_absolute() else self.cfg.root / str(tpl)
            xlsx_path = out_dir / f"tokenhub_{suite}_{stamp}.xlsx"
            write_excel(tpl_path, xlsx_path, payload, results)
            console.print(f"Excel report: {xlsx_path}")
        _print_summary(payload)
        return payload


def _summarize(results: list[ModuleResult]) -> dict[str, int]:
    counts = {s.value: 0 for s in Status}
    for r in results:
        counts[r.status.value] = counts.get(r.status.value, 0) + 1
    counts["total"] = len(results)
    return counts


def _official_differences(
    vendor_results: list[ModuleResult],
    official_results: list[ModuleResult],
) -> list[dict[str, str]]:
    official_by_id = {r.module_id: r for r in official_results}
    differences: list[dict[str, str]] = []
    for vendor in vendor_results:
        official = official_by_id.get(vendor.module_id)
        if not official:
            continue
        if official.status != vendor.status:
            differences.append(
                {
                    "level": "module",
                    "module_id": vendor.module_id,
                    "vendor_status": vendor.status.value,
                    "official_status": official.status.value,
                }
            )
        vendor_checks = {c.name: c for c in vendor.checks}
        official_checks = {c.name: c for c in official.checks}
        for check_name in sorted(vendor_checks.keys() | official_checks.keys()):
            vendor_check = vendor_checks.get(check_name)
            official_check = official_checks.get(check_name)
            vendor_status = vendor_check.status.value if vendor_check else "missing"
            official_status = official_check.status.value if official_check else "missing"
            if vendor_status != official_status:
                differences.append(
                    {
                        "level": "check",
                        "module_id": vendor.module_id,
                        "check": check_name,
                        "vendor_status": vendor_status,
                        "official_status": official_status,
                    }
                )
    return differences


def _print_summary(payload: dict[str, Any]) -> None:
    table = Table(title="Tokenhub admission summary")
    table.add_column("status")
    table.add_column("count")
    for k, v in payload["summary"].items():
        table.add_row(k, str(v))
    console.print(table)
