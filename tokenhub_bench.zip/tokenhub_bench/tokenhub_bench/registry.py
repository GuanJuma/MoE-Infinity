from __future__ import annotations

from typing import TYPE_CHECKING, Callable, Optional, Type

if TYPE_CHECKING:
    from tokenhub_bench.modules.base import BaseModule

_REGISTRY: dict[str, Type["BaseModule"]] = {}


def register(module_id: str) -> Callable[[Type["BaseModule"]], Type["BaseModule"]]:
    def deco(cls: Type["BaseModule"]) -> Type["BaseModule"]:
        cls.module_id = module_id
        _REGISTRY[module_id] = cls
        return cls

    return deco


def get_module(module_id: str) -> Type["BaseModule"]:
    if module_id not in _REGISTRY:
        raise KeyError(
            f"module '{module_id}' is not registered. "
            f"known: {sorted(_REGISTRY)}"
        )
    return _REGISTRY[module_id]


def load_class(path: str) -> Type["BaseModule"]:
    """Load 'package.mod:ClassName' so a module can be swapped without code edits."""
    mod_name, _, cls_name = path.partition(":")
    if not mod_name or not cls_name:
        raise ValueError(f"invalid class path '{path}', expected package.mod:Class")
    import importlib

    mod = importlib.import_module(mod_name)
    return getattr(mod, cls_name)


def all_ids() -> list[str]:
    return sorted(_REGISTRY)


def resolve(module_id: str, class_path: Optional[str] = None) -> Type["BaseModule"]:
    if class_path:
        return load_class(class_path)
    return get_module(module_id)
