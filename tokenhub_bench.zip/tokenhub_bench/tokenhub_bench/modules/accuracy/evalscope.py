from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check

ROW_MAP = {
    "aime2026": 46,
    "hle": 47,
    "mmlu_pro": 48,
    "swe_bench_verified": 49,
    "gpqa_diamond": 50,
    "longbench_v2": 51,
    "livecodebench": 52,
    "tau2_bench_retail": 53,
    "tau2_bench_telecom": 54,
    "tau2_bench_airline": 55,
}


@register("accuracy.evalscope")
class EvalscopeAccuracyModule(BaseModule):
    title = "模型效果验收"
    template_rows = list(range(46, 56))

    def run(self):
        ctx = self.ctx
        spec = ctx.cfg.get("accuracy", default={}) or {}
        runner = spec.get("runner", "evalscope")
        datasets = spec.get("datasets") or []
        selected = ctx.extras.get("accuracy_datasets")
        if selected:
            datasets = [ds for ds in datasets if ds.get("id") in selected]
        tol = float(spec.get("float_tolerance", 0.04))
        if runner == "skip":
            return self.skip("accuracy.runner=skip")

        if shutil.which("evalscope") is None and runner == "evalscope":
            checks = [
                skip_check(
                    "evalscope_not_installed",
                    "pip install evalscope 后重跑 --suite accuracy。本模块只编排，不内置数据集下载。",
                )
            ]
            for ds in datasets:
                did = ds.get("id")
                checks.append(
                    skip_check(
                        did,
                        f"pending evalscope; hf={ds.get('hf')} official={ds.get('official')} note={ds.get('note')}",
                    )
                )
            return self.result(
                checks,
                summary="evalscope not installed",
                notes="template: huggingface datasets / evalscope, ±2%~±4% vs official",
            )

        out_dir = Path(ctx.cfg.get("report", "out_dir", default="reports"))
        if not out_dir.is_absolute():
            out_dir = ctx.cfg.root / out_dir
        (out_dir / "evalscope").mkdir(parents=True, exist_ok=True)
        checks: list[Check] = []
        metrics = {}
        for ds in datasets:
            did = ds.get("id")
            if ds.get("enabled") is False:
                checks.append(skip_check(did, "disabled in config"))
                continue
            cmd = _finalize_cmd(ds.get("command"), spec, ds, ctx.quick)
            if not cmd:
                checks.append(
                    skip_check(
                        did,
                        f"fill accuracy.datasets[].command or official score; hf={ds.get('hf')}",
                    )
                )
                continue
            env = os.environ.copy()
            env["OPENAI_BASE_URL"] = ctx.vendor.base_url
            env["OPENAI_API_KEY"] = ctx.vendor.api_key or "EMPTY"
            env["OPENAI_MODEL"] = ctx.vendor.model
            try:
                generation_config = _generation_config(spec, ds, env)
            except (TypeError, ValueError, json.JSONDecodeError) as e:
                checks.append(fail_check(did, str(e), expected="valid generation config"))
                continue
            if generation_config is not None:
                env["EVALSCOPE_GEN_CFG"] = json.dumps(generation_config, separators=(",", ":"))
                env["EVALSCOPE_BATCH"] = str(generation_config.get("batch_size", 1))
            timeout_s = int(ds.get("timeout_s", 86400))
            work_dir = _work_dir_from_cmd(cmd, ctx.cfg.root)
            previous_reports = _report_snapshot(work_dir)
            print(f"[accuracy.evalscope] {did}: {cmd}", flush=True)
            try:
                proc = subprocess.run(
                    cmd,
                    shell=True,
                    env=env,
                    cwd=str(ctx.cfg.root),
                    timeout=timeout_s,
                    check=False,
                )
            except Exception as e:
                checks.append(fail_check(did, str(e), expected="eval finished"))
                continue
            score = _parse_report(
                work_dir,
                ds.get("evalscope") or did,
                previous=previous_reports,
            )
            metrics[did] = {"score": score, "returncode": proc.returncode, "work_dir": str(work_dir or "")}
            if proc.returncode != 0:
                checks.append(
                    warn_check(
                        did,
                        {"score": score, "returncode": proc.returncode},
                        expected={"returncode": 0},
                        detail=f"eval command failed; work_dir={work_dir}",
                    )
                )
                continue
            official = ds.get("official")
            if score is None:
                checks.append(
                    warn_check(
                        did,
                        proc.returncode,
                        detail=f"no score parsed; returncode={proc.returncode} work_dir={work_dir}",
                    )
                )
                continue
            if official is None:
                checks.append(ok_check(did, score, expected="record only, official TBD"))
                continue
            compared_score, compared_official = _normalize_score_scale(float(score), float(official))
            abs_diff = abs(compared_score - compared_official)
            allowed_diff = tol * 100 if compared_official > 1 else tol
            ok = abs_diff <= allowed_diff
            checks.append(
                (ok_check if ok else fail_check)(
                    did,
                    {
                        "score": score,
                        "official": official,
                        "compared_score": compared_score,
                        "compared_official": compared_official,
                        "abs_diff": abs_diff,
                        "tol": tol,
                    },
                    expected=f"official ±{tol*100:.0f}%",
                )
            )
        return self.result(checks, summary="accuracy suite", metrics=metrics)


def _finalize_cmd(cmd: str | None, spec: dict, ds: dict, quick: bool) -> str | None:
    if not cmd:
        return None
    limit = ds.get("limit", spec.get("limit"))
    if quick and limit is None:
        limit = 5
    if limit is not None and "--limit" not in cmd:
        cmd = f"{cmd} --limit {limit}"
    return cmd


def _generation_config(spec: dict, ds: dict, env: dict[str, str]) -> dict | None:
    max_tokens = ds.get("max_output_tokens")
    if max_tokens is None:
        return None
    max_tokens = int(max_tokens)
    if max_tokens <= 0:
        raise ValueError("max_output_tokens must be positive")

    batch_default = ds.get("batch_size", spec.get("batch_size", 1))
    config = {
        "max_tokens": max_tokens,
        "temperature": float(ds.get("temperature", spec.get("temperature", 0.9))),
        "timeout": float(ds.get("generation_timeout_s", spec.get("generation_timeout_s", 900))),
        "batch_size": int(env.get("EVALSCOPE_BATCH", batch_default)),
    }
    top_p = ds.get("top_p", spec.get("top_p"))
    if top_p is not None:
        config["top_p"] = float(top_p)
    override = env.get("EVALSCOPE_GEN_CFG")
    if override:
        parsed = json.loads(override)
        if not isinstance(parsed, dict):
            raise ValueError("EVALSCOPE_GEN_CFG must be a JSON object")
        config.update(parsed)
    return config


def _work_dir_from_cmd(cmd: str, root: Path) -> Path | None:
    m = re.search(r"--work-dir\s+(\S+)", cmd)
    if not m:
        return None
    p = Path(m.group(1))
    return p if p.is_absolute() else root / p


def _score_from_payload(data: dict) -> float | None:
    if isinstance(data.get("score"), (int, float)):
        return float(data["score"])
    for metric in data.get("metrics") or []:
        if isinstance(metric, dict) and isinstance(metric.get("score"), (int, float)):
            return float(metric["score"])
        for subset in (metric.get("categories") or []) if isinstance(metric, dict) else []:
            if isinstance(subset, dict) and isinstance(subset.get("score"), (int, float)):
                return float(subset["score"])
    return None


def _report_snapshot(work_dir: Path | None) -> dict[Path, tuple[int, int]]:
    if work_dir is None or not work_dir.exists():
        return {}
    snapshot: dict[Path, tuple[int, int]] = {}
    for path in work_dir.rglob("*.json"):
        if "reports" not in path.parts:
            continue
        try:
            stat = path.stat()
        except OSError:
            continue
        snapshot[path] = (stat.st_mtime_ns, stat.st_size)
    return snapshot


def _parse_report(
    work_dir: Path | None,
    dataset: str | None = None,
    *,
    previous: dict[Path, tuple[int, int]] | None = None,
) -> float | None:
    if work_dir is None or not work_dir.exists():
        return None
    files = sorted(work_dir.rglob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in files:
        if "reports" not in path.parts:
            continue
        if previous is not None:
            try:
                stat = path.stat()
            except OSError:
                continue
            if previous.get(path) == (stat.st_mtime_ns, stat.st_size):
                continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        if dataset:
            name = str(data.get("dataset_name") or path.stem)
            if dataset not in {name, path.stem} and dataset not in path.name:
                continue
        score = _score_from_payload(data)
        if score is not None:
            return score
    return None


def _normalize_score_scale(score: float, official: float) -> tuple[float, float]:
    """Compare ratio and percentage scores on the official score's scale."""
    if official > 1 and 0 <= score <= 1:
        score *= 100
    elif 0 <= official <= 1 and score > 1:
        score /= 100
    return score, official


def _parse_score(blob: str, regex: str | None):
    if regex:
        m = re.search(regex, blob)
        if m:
            try:
                return float(m.group(1))
            except Exception:
                return None
    for line in reversed(blob.splitlines()):
        if "score" in line.lower() or "acc" in line.lower():
            m = re.search(r"(\d+\.\d+|\d+)", line)
            if m:
                try:
                    return float(m.group(1))
                except Exception:
                    pass
    return None
