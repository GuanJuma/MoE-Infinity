from __future__ import annotations

import json
import statistics
from pathlib import Path
from typing import Any

from tokenhub_bench.clients.http import cached_tokens
from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check

DEFAULT_SCENARIOS = ("hot", "cold", "mix50")
DEFAULT_BUCKETS = ("1k",)
WARMUP_SCENARIOS = frozenset({"hot", "mix50"})


def thinking_off_extra(ctx) -> dict[str, Any] | None:
    golden = ctx.golden("thinking", default={}) or {}
    bodies = list(golden.get("disable_bodies") or [])
    if bodies and isinstance(bodies[0], dict):
        return dict(bodies[0])
    control = str(golden.get("control") or "thinking_param")
    if control == "reasoning_effort":
        return {"chat_template_kwargs": {"reasoning_effort": "no_think"}}
    return {"thinking": {"type": "disabled"}}


def cache_spec(ctx) -> dict[str, Any]:
    spec = dict(ctx.cfg.get("cache_hit", default={}) or {})
    golden = ctx.golden("cache_hit", default={}) or {}
    for key, value in golden.items():
        spec.setdefault(key, value)
    return spec


def cache_kit_root(ctx) -> Path:
    spec = cache_spec(ctx)
    explicit = str(spec.get("kit_dir") or "").strip()
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_absolute():
            path = ctx.cfg.root / path
        return path
    return ctx.cfg.root / "datasets" / "cache_variants"


def cache_dataset_path(root: Path, bucket: str, scenario: str) -> Path:
    return root / f"cache_{bucket}_{scenario}.jsonl"


def load_cache_prompts(path: Path, limit: int | None = None) -> list[list[dict[str, Any]]]:
    prompts: list[list[dict[str, Any]]] = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(payload, list):
                messages = payload
            elif isinstance(payload, dict) and isinstance(payload.get("messages"), list):
                messages = payload["messages"]
            else:
                continue
            prompts.append(messages)
            if limit is not None and len(prompts) >= max(1, limit):
                break
    return prompts


def request_limit(ctx, spec: dict[str, Any]) -> int | None:
    """None means send every row in the jsonl. smoke / --quick still cap."""
    if ctx.quick:
        return max(1, int(spec.get("quick_n", 4)))
    if ctx.cfg.profile_is_smoke():
        return max(1, int(spec.get("smoke_n") or spec.get("max_requests") or 5))
    raw = spec.get("max_requests")
    if raw in (None, "", 0, "0", "all"):
        return None
    return max(1, int(raw))


def summarize_hits(samples: list[dict[str, Any]]) -> dict[str, Any]:
    successful = [sample for sample in samples if sample.get("ok")]
    prompt_tokens = sum(int(sample.get("prompt_tokens") or 0) for sample in successful)
    cached = sum(int(sample.get("cached_tokens") or 0) for sample in successful)
    ratios = [
        int(sample.get("cached_tokens") or 0) / int(sample["prompt_tokens"])
        for sample in successful
        if int(sample.get("prompt_tokens") or 0) > 0
    ]
    return {
        "n": len(samples),
        "success": len(successful),
        "prompt_tokens": prompt_tokens,
        "cached_tokens": cached,
        "global_hit_rate": (cached / prompt_tokens) if prompt_tokens else 0.0,
        "avg_hit_ratio": statistics.mean(ratios) if ratios else 0.0,
        "repeat_hits": sum(1 for sample in successful if int(sample.get("cached_tokens") or 0) > 0),
    }


@register("cache_hit.hit_rate")
class CacheHitRateModule(BaseModule):
    title = "缓存命中率验收"
    template_rows = [87, 97]

    def run(self):
        ctx = self.ctx
        spec = cache_spec(ctx)
        baseline = float(spec.get("official_baseline", 0.929))
        hot_min = float(spec.get("min_required", spec.get("hot_min", 0.79)))
        cold_max = float(spec.get("cold_max", 0.20))
        warmup_n = int(spec.get("warmup", 3))
        max_tokens = int(spec.get("max_tokens", 32))
        scenarios = [str(item) for item in (spec.get("scenarios") or DEFAULT_SCENARIOS)]
        buckets = [str(item) for item in (spec.get("buckets") or DEFAULT_BUCKETS)]
        limit = request_limit(ctx, spec)
        if ctx.quick:
            buckets = buckets[:1]
            warmup_n = min(warmup_n, 1)
        cached_paths = ctx.golden("cache", "cached_tokens_paths", default=None)
        extra = thinking_off_extra(ctx)
        root = cache_kit_root(ctx)

        checks: list[Check] = []
        metrics: dict[str, Any] = {
            "baseline": baseline,
            "min_required": hot_min,
            "cold_max": cold_max,
            "scenarios": {},
        }
        hot_rates: list[float] = []

        for scenario in scenarios:
            for bucket in buckets:
                path = cache_dataset_path(root, bucket, scenario)
                key = f"{scenario}_{bucket}"
                if not path.is_file():
                    checks.append(skip_check(f"cache_hit_{key}", f"missing dataset: {path}"))
                    continue
                prompts = load_cache_prompts(path, limit)
                if not prompts:
                    checks.append(skip_check(f"cache_hit_{key}", f"empty dataset: {path}"))
                    continue
                samples = self._run_scenario(
                    prompts,
                    extra=extra,
                    cached_paths=cached_paths if isinstance(cached_paths, list) else None,
                    max_tokens=max_tokens,
                    warmup=warmup_n if scenario in WARMUP_SCENARIOS else 0,
                    label=key,
                )
                summary = summarize_hits(samples)
                summary.update({"kit": bucket, "scenario": scenario, "dataset": str(path)})
                metrics["scenarios"][key] = summary
                rate = float(summary["global_hit_rate"])
                actual = {
                    "global_hit_rate": rate,
                    "avg_hit_ratio": summary["avg_hit_ratio"],
                    "cached": summary["cached_tokens"],
                    "prompt_tokens": summary["prompt_tokens"],
                    "n": summary["n"],
                    "success": summary["success"],
                }
                if scenario == "hot":
                    hot_rates.append(rate)
                    checks.append(
                        (ok_check if rate >= hot_min else fail_check)(
                            f"cache_hit_{key}",
                            actual,
                            expected=f">={hot_min}",
                            detail="shared-prefix hot set: sum(cached_tokens)/sum(prompt_tokens)",
                        )
                    )
                elif scenario == "cold":
                    checks.append(
                        (ok_check if rate <= cold_max else fail_check)(
                            f"cache_hit_{key}",
                            actual,
                            expected=f"<={cold_max}",
                            detail="UUID-broken cold set should miss prefix cache",
                        )
                    )
                else:
                    checks.append(
                        (ok_check if summary["success"] else fail_check)(
                            f"cache_hit_{key}",
                            actual,
                            expected="requests succeed; mix rate is recorded",
                            detail="50/50 shared vs unique prefix; not gated on min_required",
                        )
                    )

        if not checks:
            return self.skip("no cache_hit scenarios ran")

        if hot_rates:
            hot_rate = min(hot_rates)
            if hot_rate < baseline:
                checks.append(
                    warn_check(
                        "below_official_baseline",
                        hot_rate,
                        expected=baseline,
                        detail="still pass if hot global hit rate >= min_required",
                    )
                )

        hot_best = min(hot_rates) if hot_rates else None
        return self.result(
            checks,
            summary=f"hot={hot_best} min={hot_min} baseline={baseline}",
            metrics=metrics,
        )

    def _run_scenario(
        self,
        prompts: list[list[dict[str, Any]]],
        *,
        extra: dict[str, Any] | None,
        cached_paths: list[str] | None,
        max_tokens: int,
        warmup: int,
        label: str,
    ) -> list[dict[str, Any]]:
        ctx = self.ctx
        if warmup > 0:
            for index in range(warmup):
                res = ctx.vendor.chat(prompts[0], extra=extra, max_tokens=max_tokens)
                print(
                    f"[cache_hit.hit_rate] {label} warmup {index + 1}/{warmup} "
                    f"ok={res.ok} cached={cached_tokens(res.usage or {}, paths=cached_paths)}",
                    flush=True,
                )
        samples: list[dict[str, Any]] = []
        n_requests = len(prompts)
        for index, messages in enumerate(prompts):
            res = ctx.vendor.chat(messages, extra=extra, max_tokens=max_tokens)
            usage = res.usage or {}
            sample = {
                "ok": bool(res.ok),
                "prompt_tokens": int(usage.get("prompt_tokens") or 0),
                "cached_tokens": int(cached_tokens(usage, paths=cached_paths) or 0),
            }
            samples.append(sample)
            print(
                f"[cache_hit.hit_rate] {label} {index + 1}/{n_requests} ok={res.ok} "
                f"cached={sample['cached_tokens']}/{sample['prompt_tokens']}",
                flush=True,
            )
        return samples
