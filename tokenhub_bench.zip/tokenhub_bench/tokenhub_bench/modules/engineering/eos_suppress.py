from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed

from tokenhub_bench.modules.base import BaseModule, assistant_fields, fail_check, ok_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check

PROMPT = (
    "A farmer has 17 sheep. All but 9 run away. How many are left? "
    "Think carefully step by step, then give the final number only in content."
)


@register("engineering.eos_suppress")
class EosSuppressModule(BaseModule):
    title = "模型思考过程EOS抑制机制"
    template_rows = [27]

    def run(self):
        ctx = self.ctx
        spec = ctx.cfg.get("eos_suppress", default={}) or {}
        n = int(spec.get("repeats", 1000))
        if ctx.quick or ctx.cfg.profile_is_smoke():
            n = min(n, 8)
        topk = int(spec.get("logprobs", 5))
        warn_ratio = float(spec.get("empty_content_warn_ratio", 0.02))

        def one(_i: int):
            return ctx.vendor.chat(
                [{"role": "user", "content": PROMPT}],
                extra={"logprobs": True, "top_logprobs": topk},
                max_tokens=512,
            )

        stop_n = 0
        empty_n = 0
        fail_n = 0
        samples = []
        workers = 4 if n > 8 else 1
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futs = [pool.submit(one, i) for i in range(n)]
            for fut in as_completed(futs):
                res = fut.result()
                if not res.ok:
                    fail_n += 1
                    continue
                f = assistant_fields(res)
                fr = f.get("finish_reason")
                content = f.get("content")
                empty = content in (None, "")
                if fr == "stop":
                    stop_n += 1
                    if empty:
                        empty_n += 1
                        samples.append(
                            {
                                "finish_reason": fr,
                                "has_reasoning": bool(f.get("reasoning_content")),
                                "usage": f.get("usage"),
                            }
                        )
        ratio = (empty_n / stop_n) if stop_n else 0.0
        checks: list[Check] = []
        checks.append(
            ok_check(
                "eos_empty_content_ratio",
                {
                    "repeats": n,
                    "http_fail": fail_n,
                    "finish_reason_stop": stop_n,
                    "empty_content": empty_n,
                    "ratio": round(ratio, 6),
                },
                expected="record ratio; attach to official-compare notes if enabled",
                detail=(
                    f"in finish_reason=stop 的 {stop_n} 条中, {empty_n} 条 content 为空, 比例 {ratio:.4%}. "
                    "thinking 过程只应允许 think_end special token。"
                ),
            )
        )
        if fail_n > n * 0.1:
            checks.append(fail_check("request_success", fail_n, expected=f"failures << {n}"))
        if stop_n and ratio > warn_ratio:
            checks.append(
                warn_check(
                    "empty_ratio_high",
                    ratio,
                    expected=f"<= {warn_ratio}",
                    detail="high empty-content rate after stop often means missing EOS suppress",
                )
            )
        return self.result(
            checks,
            summary=f"stop={stop_n} empty={empty_n} ratio={ratio:.4%} n={n}",
            metrics={"n": n, "stop": stop_n, "empty": empty_n, "ratio": ratio, "samples": samples[:5]},
            notes="template requires 原厂对比; attach this ratio to the Excel 备注",
        )
