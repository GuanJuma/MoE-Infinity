from __future__ import annotations

from tokenhub_bench.clients.http import finish_reason, message_from
from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.web_search")
class WebSearchModule(BaseModule):
    title = "联网搜索能力支持"
    template_rows = [24]

    def run(self):
        ctx = self.ctx
        spec = ctx.golden("web_search", default={}) or {}
        checks: list[Check] = []
        tool = spec.get("builtin_tool") or {
            "type": "builtin_function",
            "function": {"name": "$web_search"},
        }
        supported = spec.get("supported")
        if supported is not True:
            reason = (
                "model contract does not support web search"
                if supported is False
                else "golden web-search support is unknown"
            )
            return self.result(
                [skip_check("web_search", reason)],
                summary="skipped by golden",
            )

        res = ctx.vendor.chat(
            [{"role": "user", "content": "Search the web: who is the current UN secretary-general?"}],
            extra={"tools": [tool]},
            max_tokens=512,
        )
        if res.status_code in (400, 404) and "$web_search" in (res.text or ""):
            checks.append(
                fail_check(
                    "enable_via_builtin_tool",
                    res.status_code,
                    expected="accept builtin_function $web_search",
                    detail=res.text[:300],
                )
            )
            return self.result(checks, summary="builtin $web_search rejected")

        if not res.ok:
            checks.append(
                warn_check(
                    "enable_via_builtin_tool",
                    {"status": res.status_code, "body": (res.text or "")[:300]},
                    expected="2xx or tool_calls",
                    detail="cluster may not expose the contract builtin search tool — confirm enable_via",
                )
            )
            return self.result(checks, summary="web search not available on vendor")

        msg = message_from(res.json)
        tool_calls = (msg or {}).get("tool_calls") or []
        names = []
        for tc in tool_calls:
            fn = (tc or {}).get("function") or {}
            names.append(fn.get("name"))
        used_builtin = "$web_search" in names or any(n and "search" in str(n) for n in names)
        fr = finish_reason(res.json)
        if used_builtin or fr == "tool_calls":
            checks.append(
                ok_check(
                    "web_search_triggered",
                    {"finish_reason": fr, "tools": names},
                    expected="tool_calls $web_search",
                    detail="enable method: tools=[{type:builtin_function,function:{name:$web_search}}]",
                )
            )
        else:
            checks.append(
                warn_check(
                    "web_search_triggered",
                    {"finish_reason": fr, "tools": names, "content_head": str((msg or {}).get("content"))[:160]},
                    expected="builtin search tool_calls",
                    detail="request accepted but model did not call $web_search",
                )
            )
        return self.result(checks, summary=f"finish_reason={fr} tools={names}")
