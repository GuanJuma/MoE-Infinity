from __future__ import annotations

import json
import re

from tokenhub_bench.modules.base import BaseModule, assistant_fields, fail_check, ok_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check

GARBLED_RE = re.compile(r"[\ufffd]|<\|(?:im_start|im_end|endoftext)\|")


@register("engineering.response_correctness")
class ResponseCorrectnessModule(BaseModule):
    title = "返回内容的正确性"
    template_rows = [31, 32, 33]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []
        res = ctx.vendor.chat(
            [{"role": "user", "content": "Reply with the single word pong."}],
            max_tokens=32,
        )
        if not res.ok or not res.json:
            return self.result(
                [fail_check("response_json", {"status": res.status_code, "text": res.text[:200]}, expected="JSON object")],
                summary="no json",
            )

        payload = res.json
        # Duplicate keys cannot be observed after json.loads; inspect raw text.
        raw = res.text or ""
        dup = _duplicate_keys(raw)
        checks.append(
            (fail_check if dup else ok_check)(
                "no_duplicate_fields",
                dup,
                expected=[],
                detail="raw JSON must not repeat content/usage keys at the same object level",
            )
        )

        f = assistant_fields(res)
        content = f.get("content")
        usage = f.get("usage") or {}
        missing = []
        if content in (None, ""):
            missing.append("content")
        for k in ("prompt_tokens", "completion_tokens", "total_tokens"):
            if usage.get(k) is None:
                missing.append(f"usage.{k}")
        checks.append(
            (fail_check if missing else ok_check)(
                "required_fields_present",
                {"missing": missing, "usage": usage, "content_head": str(content)[:80]},
                expected="content + usage tokens",
            )
        )

        blob = json.dumps(payload, ensure_ascii=False)
        garbled = bool(GARBLED_RE.search(blob)) or "training loss" in blob.lower()
        checks.append(
            (fail_check if garbled else ok_check)(
                "no_garbled_or_train_leak",
                garbled,
                expected=False,
            )
        )
        return self.result(checks, summary=f"重复字段={dup or '无'}，缺失字段={missing or '无'}")


def _duplicate_keys(raw: str) -> list[str]:
    # Very small scanner for repeated keys in the top-level object and first choice message.
    hits = []
    for key in ("content", "usage", "choices", "id"):
        if raw.count(f'"{key}"') > 1 and key in ("usage", "id"):
            # usage may appear in last stream chunk only; for non-stream, 1 is expected
            if raw.count(f'"{key}"') > 1:
                hits.append(key)
    # message.content should appear once in non-stream
    if raw.count('"content"') > 3:
        hits.append("content_repeated")
    return hits
