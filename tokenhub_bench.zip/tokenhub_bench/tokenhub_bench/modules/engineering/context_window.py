from __future__ import annotations

from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, pad_prompt, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.context_window")
class ContextWindowModule(BaseModule):
    title = "最大上下文窗口"
    template_rows = [16, 17]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []
        window = int(ctx.golden("context_window", default=262144))
        smoke = ctx.quick or ctx.cfg.profile_is_smoke()

        # Prove a mid-size in-window request works, then probe overflow.
        in_tokens = 2048 if smoke else min(8000, window // 8)
        inside = ctx.vendor.chat(
            [{"role": "user", "content": pad_prompt(in_tokens) + "\n\nReply with the single word ok."}],
            max_tokens=8,
        )
        checks.append(
            (ok_check if inside.ok else fail_check)(
                "in_window_request",
                {"status": inside.status_code, "prompt_tokens": (inside.usage or {}).get("prompt_tokens")},
                expected="2xx within context window",
                detail=inside.error or "",
            )
        )

        overflow_tokens = window + 2048
        smoke_cap = 200_000
        if smoke and overflow_tokens > smoke_cap:
            checks.append(
                warn_check(
                    "overflow_behavior",
                    {"configured_window": window, "smoke_cap": smoke_cap, "probed": False},
                    expected="an actual request above the configured context window",
                    detail=(
                        f"smoke caps the prompt estimate at {smoke_cap} tokens, below the "
                        f"configured window={window}; run the admission profile to probe overflow"
                    ),
                )
            )
            summary = f"window={window} in_window={inside.ok} overflow=not-probed"
            return self.result(checks, summary=summary, metrics={"context_window": window})

        overflow = ctx.vendor.chat(
            [
                {
                    "role": "user",
                    "content": pad_prompt(overflow_tokens) + "\n\nReply with ok.",
                }
            ],
            max_tokens=8,
        )
        rejected = (not overflow.ok) or overflow.status_code >= 400
        policy = str(ctx.golden("overflow_behavior", default="reject") or "reject")
        body = (overflow.text or "").lower()
        mentions_context = any(
            k in body for k in ("context", "too long", "maximum", "max_model_len", "invalid_request")
        )
        inconclusive = overflow.status_code == 0 or overflow.status_code >= 500
        if policy == "truncate":
            overflow_ok = overflow.ok or rejected
            expected = "2xx (truncate) or 4xx when input exceeds window"
        else:
            overflow_ok = rejected
            expected = "4xx when input exceeds window"
        checks.append(
            (warn_check if inconclusive else ok_check if overflow_ok else warn_check)(
                "overflow_behavior",
                {
                    "status": overflow.status_code,
                    "policy": policy,
                    "mentions_context": mentions_context,
                    "body": (overflow.text or "")[:240],
                },
                expected=expected,
                detail=f"configured window={window} overflow_behavior={policy}",
            )
        )
        summary = f"window={window} in_window={inside.ok} overflow_status={overflow.status_code}"
        return self.result(checks, summary=summary, metrics={"context_window": window})
