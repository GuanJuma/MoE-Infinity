from __future__ import annotations

from tokenhub_bench.clients.http import finish_reason
from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.output_length")
class OutputLengthModule(BaseModule):
    title = "控制输出长度支持情况"
    template_rows = [13, 14, 15]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []
        golden = ctx.golden("output_length", default={}) or {}
        prompt = [{"role": "user", "content": "Write a long essay about number theory. Keep going."}]

        checks.append(self._field_test("max_tokens", {"max_tokens": 8}, prompt, golden.get("max_tokens", True)))
        checks.append(
            self._field_test(
                "max_completion_tokens",
                {"max_completion_tokens": 8},
                prompt,
                golden.get("max_completion_tokens", True),
            )
        )

        # max_output_tokens is not a Chat Completions field on this contract; also try Responses API.
        chat_out = ctx.vendor.chat(prompt, extra={"max_output_tokens": 8})
        resp_out = ctx.vendor.responses({"input": prompt[0]["content"], "max_output_tokens": 8})
        flag = golden.get("max_output_tokens")
        if resp_out.ok:
            fr = finish_reason(resp_out.json)
            usage = resp_out.usage or {}
            ct = usage.get("completion_tokens") or usage.get("output_tokens")
            incomplete = (resp_out.json or {}).get("incomplete_details") or {}
            incomplete_reason = incomplete.get("reason") if isinstance(incomplete, dict) else None
            limited = (
                (ct is not None and int(ct) <= 8)
                or fr in ("incomplete", "length")
                or incomplete_reason == "max_output_tokens"
            )
            checks.append(
                (ok_check if limited else warn_check)(
                    "max_output_tokens",
                    {
                        "via": "responses",
                        "finish_reason": fr,
                        "completion_tokens": ct,
                        "incomplete_reason": incomplete_reason,
                    },
                    expected="Responses API limits output to max_output_tokens=8",
                    detail="" if limited else "request succeeded but the response does not prove the output limit was honored",
                )
            )
        elif chat_out.ok:
            usage = chat_out.usage or {}
            ct = usage.get("completion_tokens")
            checks.append(
                (ok_check if ct is not None and int(ct) <= 8 else warn_check)(
                    "max_output_tokens",
                    {"via": "chat", "completion_tokens": ct, "finish_reason": finish_reason(chat_out.json)},
                    expected="length limited",
                    detail="vendor accepted max_output_tokens on Chat Completions; contract uses max_completion_tokens",
                )
            )
        else:
            if flag is True:
                checks.append(
                    fail_check(
                        "max_output_tokens",
                        {"chat": chat_out.status_code, "responses": resp_out.status_code},
                        expected="supported",
                    )
                )
            else:
                checks.append(
                    skip_check(
                        "max_output_tokens",
                        f"chat={chat_out.status_code} responses={resp_out.status_code}; model flag={flag}",
                    )
                )

        return self.result(checks, summary=", ".join(f"{c.name}={c.status.value}" for c in checks))

    def _field_test(self, name: str, extra: dict, prompt, golden_flag) -> Check:
        res = self.ctx.vendor.chat(prompt, extra=extra)
        if not res.ok:
            if golden_flag:
                return fail_check(name, res.status_code, expected="2xx + truncated", detail=res.text[:200])
            return skip_check(name, f"HTTP {res.status_code}")
        usage = res.usage or {}
        ct = usage.get("completion_tokens")
        fr = finish_reason(res.json)
        limited = ct is not None and int(ct) <= 8
        if limited or fr == "length":
            return ok_check(name, {"completion_tokens": ct, "finish_reason": fr}, expected="truncated")
        return warn_check(
            name,
            {"completion_tokens": ct, "finish_reason": fr},
            expected="finish_reason=length or small completion_tokens",
        )
