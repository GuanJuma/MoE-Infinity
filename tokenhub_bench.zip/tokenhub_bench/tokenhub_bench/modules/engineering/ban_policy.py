from __future__ import annotations

from tokenhub_bench.modules.base import BaseModule, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.ban_policy")
class BanPolicyModule(BaseModule):
    title = "封禁策略"
    template_rows = [43]

    def run(self):
        note = (
            "模板要求供应商特殊说明客户封禁策略（账号/IP/Key 封禁条件与解除方式）。"
            "请填写 vendor.ban_policy。"
        )
        policy = self.ctx.cfg.get("vendor", "ban_policy", default=None)
        checks: list[Check] = []
        if policy:
            checks.append(warn_check("declared_policy", policy, expected="human confirmation", detail=str(policy)))
        else:
            checks.append(skip_check("declared_policy", note))
        return self.result(checks, summary=str(policy or "need vendor statement"), notes=note)
