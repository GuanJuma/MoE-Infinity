from __future__ import annotations

from tokenhub_bench.i18n import zh_check_name, zh_status
from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check, HttpResult


def _supported(res: HttpResult) -> bool:
    if res.status_code == 0 or res.status_code >= 500:
        return False
    if res.status_code in (404, 405):
        return False
    if res.status_code == 400 and res.text and "unknown" in res.text.lower():
        return False
    return res.ok or res.status_code not in (404, 405)


@register("engineering.protocols")
class ProtocolsModule(BaseModule):
    title = "协议支持情况"
    template_rows = [10, 11, 12]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []
        golden = ctx.golden("protocols", default={}) or {}

        chat = ctx.vendor.chat(
            [{"role": "user", "content": "Reply with the single word pong."}],
            max_tokens=16,
        )
        checks.append(
            (ok_check if chat.ok else fail_check)(
                "openai_chat_completions",
                {"status": chat.status_code, "object": (chat.json or {}).get("object")},
                expected="POST /v1/chat/completions 2xx",
                detail=chat.error or "",
            )
        )

        resp = ctx.vendor.responses(
            {
                "input": "Reply with the single word pong.",
                "max_output_tokens": 16,
            }
        )
        checks.extend(self._judge("openai_responses", resp, golden.get("responses")))

        anth = ctx.vendor.messages_anthropic(
            {
                "max_tokens": 16,
                "messages": [{"role": "user", "content": "Reply with the single word pong."}],
            }
        )
        checks.extend(self._judge("anthropic_messages", anth, golden.get("anthropic_messages")))

        summary = "，".join(f"{zh_check_name(c.name)}={zh_status(c.status)}" for c in checks)
        return self.result(checks, summary=summary)

    def _judge(self, name: str, res: HttpResult, golden_flag) -> list[Check]:
        supported = _supported(res)
        if res.status_code == 0 or res.status_code >= 500:
            return [
                warn_check(
                    name,
                    {"status": res.status_code, "supported": None},
                    expected="a conclusive 2xx or 4xx protocol response",
                    detail=(res.text or res.error or "")[:300],
                )
            ]
        if golden_flag is True:
            return [
                (ok_check if res.ok else fail_check)(
                    name,
                    {"status": res.status_code, "ok": res.ok},
                    expected="2xx, model contract supports this protocol",
                    detail=(res.text or res.error or "")[:300],
                )
            ]
        if golden_flag is False:
            return [
                (ok_check if not supported else fail_check)(
                    name,
                    {"status": res.status_code, "supported": supported},
                    expected="unsupported like model contract",
                    detail=(res.text or "")[:200],
                )
            ]
        # unknown in model contract: record vendor capability, do not fail solely on 404
        if res.ok:
            return [ok_check(name, {"status": res.status_code}, detail="protocol reachable")]
        if res.status_code in (404, 405):
            return [
                skip_check(
                    name,
                    f"vendor returned {res.status_code}; model contract marks this protocol unknown",
                    status=res.status_code,
                    body=(res.text or "")[:200],
                )
            ]
        return [
            warn_check(
                name,
                {"status": res.status_code},
                detail=(res.text or res.error or "")[:300],
            )
        ]
