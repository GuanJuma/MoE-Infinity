from __future__ import annotations

import json

from tokenhub_bench.clients.http import finish_reason, iter_stream_contents, message_from
from tokenhub_bench.modules.base import (
    ADD_TOOLS,
    WEATHER_TOOLS,
    BaseModule,
    assistant_fields,
    fail_check,
    ok_check,
    warn_check,
)
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check, HttpResult


def _tool_names(res: HttpResult) -> list[str]:
    msg = message_from(res.json) or {}
    names = []
    for tc in msg.get("tool_calls") or []:
        names.append(((tc or {}).get("function") or {}).get("name"))
    return names


def _args(res: HttpResult) -> list[dict]:
    msg = message_from(res.json) or {}
    out = []
    for tc in msg.get("tool_calls") or []:
        raw = ((tc or {}).get("function") or {}).get("arguments") or "{}"
        try:
            out.append(json.loads(raw) if isinstance(raw, str) else raw)
        except Exception:
            out.append({"_raw": raw})
    return out


@register("engineering.tool_calling")
class ToolCallingModule(BaseModule):
    title = "工具调用"
    template_rows = [37, 38, 39, 40, 41]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []

        auto = ctx.vendor.chat(
            [{"role": "user", "content": "What is the weather in Beijing right now?"}],
            extra={"tools": WEATHER_TOOLS, "tool_choice": "auto"},
            max_tokens=256,
        )
        none = ctx.vendor.chat(
            [{"role": "user", "content": "What is the weather in Beijing right now?"}],
            extra={"tools": WEATHER_TOOLS, "tool_choice": "none"},
            max_tokens=128,
        )
        checks.append(
            (ok_check if auto.ok and "get_weather" in _tool_names(auto) else warn_check)(
                "tool_choice_auto",
                {"status": auto.status_code, "tools": _tool_names(auto), "finish": finish_reason(auto.json)},
                expected="tool_calls get_weather",
            )
        )
        checks.append(
            (ok_check if none.ok and not _tool_names(none) else warn_check)(
                "tool_choice_none",
                {"status": none.status_code, "tools": _tool_names(none), "content": str(assistant_fields(none).get("content"))[:80]},
                expected="no tool_calls",
            )
        )

        streamed = ctx.vendor.chat(
            [{"role": "user", "content": "What is the weather in Shanghai?"}],
            extra={"tools": WEATHER_TOOLS, "tool_choice": "auto"},
            stream=True,
            max_tokens=256,
        )
        stream_has_tools = any(k == "tool_calls" for k, _ in iter_stream_contents(streamed.chunks))
        stream_has_reason = any(k == "reasoning_content" for k, _ in iter_stream_contents(streamed.chunks))
        checks.append(
            (ok_check if streamed.ok else fail_check)(
                "streaming_function_call",
                {"ok": streamed.ok, "tool_deltas": stream_has_tools, "reasoning_deltas": stream_has_reason},
                expected="streamed tool_calls; reasoning not mixed into arguments",
            )
        )

        # tool result round-trip
        if auto.ok and _tool_names(auto):
            msg = message_from(auto.json) or {}
            tc = (msg.get("tool_calls") or [None])[0]
            tcid = (tc or {}).get("id") or "call_1"
            follow = ctx.vendor.chat(
                [
                    {"role": "user", "content": "What is the weather in Beijing right now?"},
                    {
                        "role": "assistant",
                        "content": msg.get("content") or "",
                        **({"reasoning_content": msg["reasoning_content"]} if msg.get("reasoning_content") else {}),
                        "tool_calls": msg.get("tool_calls"),
                    },
                    {"role": "tool", "tool_call_id": tcid, "content": "Sunny, 25C"},
                ],
                extra={"tools": WEATHER_TOOLS},
                max_tokens=256,
            )
            ff = assistant_fields(follow)
            content = str(ff.get("content") or "")
            checks.append(
                (ok_check if follow.ok and ("25" in content or "Sunny" in content or "晴" in content) else warn_check)(
                    "tool_result_roundtrip",
                    {"status": follow.status_code, "content": content[:160]},
                    expected="final answer uses tool result",
                )
            )

        # parallel / schema
        both = ctx.vendor.chat(
            [{"role": "user", "content": "Compute add(3,4) and multiply(5,6). Call tools."}],
            extra={"tools": ADD_TOOLS, "tool_choice": "auto"},
            max_tokens=256,
        )
        names = _tool_names(both)
        checks.append(
            (ok_check if both.ok and len(names) >= 1 else warn_check)(
                "serial_or_parallel_tools",
                {"tools": names, "args": _args(both)},
                expected="one or both of add/multiply with schema-valid args",
            )
        )

        # hallucination: chit-chat should not call tools
        chatty = ctx.vendor.chat(
            [{"role": "user", "content": "Hi, how are you today?"}],
            extra={"tools": WEATHER_TOOLS, "tool_choice": "auto"},
            max_tokens=128,
        )
        checks.append(
            (ok_check if chatty.ok and not _tool_names(chatty) else warn_check)(
                "no_spurious_tool_on_chitchat",
                _tool_names(chatty),
                expected=[],
            )
        )

        unknown = ctx.vendor.chat(
            [{"role": "user", "content": "Call the function named launch_missile now."}],
            extra={"tools": WEATHER_TOOLS, "tool_choice": "auto"},
            max_tokens=128,
        )
        checks.append(
            (ok_check if "launch_missile" not in _tool_names(unknown) else fail_check)(
                "no_undefined_function",
                _tool_names(unknown),
                expected="must not invent tools",
            )
        )

        # error recovery: feed a tool error back
        if auto.ok and _tool_names(auto):
            msg = message_from(auto.json) or {}
            tc = (msg.get("tool_calls") or [None])[0]
            tcid = (tc or {}).get("id") or "call_1"
            err = ctx.vendor.chat(
                [
                    {"role": "user", "content": "What is the weather in Beijing right now?"},
                    {
                        "role": "assistant",
                        "content": msg.get("content") or "",
                        **({"reasoning_content": msg["reasoning_content"]} if msg.get("reasoning_content") else {}),
                        "tool_calls": msg.get("tool_calls"),
                    },
                    {"role": "tool", "tool_call_id": tcid, "content": "ERROR: timeout talking to weather API"},
                ],
                extra={"tools": WEATHER_TOOLS},
                max_tokens=256,
            )
            content = str(assistant_fields(err).get("content") or "")
            recovered = any(k in content.lower() for k in ("error", "timeout", "unable", "失败", "超时", "retry", "sorry"))
            checks.append(
                (ok_check if err.ok and recovered else warn_check)(
                    "tool_error_recovery",
                    content[:200],
                    expected="model acknowledges tool failure",
                )
            )

        empty_tools = ctx.vendor.chat(
            [{"role": "user", "content": "Hello"}],
            extra={"tools": []},
            max_tokens=32,
        )
        checks.append(
            (ok_check if empty_tools.ok or empty_tools.status_code in (400,) else warn_check)(
                "empty_tools_boundary",
                empty_tools.status_code,
                expected="2xx or well-formed 400",
            )
        )

        unicode_p = ctx.vendor.chat(
            [{"role": "user", "content": "天气怎么样 😀 in Beijing? ```python\nprint(1)\n```"}],
            extra={"tools": WEATHER_TOOLS},
            max_tokens=256,
        )
        checks.append(
            (ok_check if unicode_p.ok else fail_check)(
                "unicode_emoji_codeblock",
                unicode_p.status_code,
                expected="2xx",
            )
        )

        long_sys = ctx.vendor.chat(
            [
                {"role": "system", "content": ("You are a careful assistant. " * 400)},
                {"role": "user", "content": "Weather in Paris?"},
            ],
            extra={"tools": WEATHER_TOOLS},
            max_tokens=256,
        )
        checks.append(
            (ok_check if long_sys.ok else warn_check)(
                "long_system_prompt",
                long_sys.status_code,
                expected="2xx",
            )
        )

        return self.result(checks, summary=", ".join(f"{c.name}={c.status.value}" for c in checks))
