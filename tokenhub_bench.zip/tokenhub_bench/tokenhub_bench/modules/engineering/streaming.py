from __future__ import annotations

from tokenhub_bench.clients.http import extract_usage, iter_stream_contents
from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.streaming")
class StreamingModule(BaseModule):
    title = "流式输出"
    template_rows = [7, 8, 9]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []
        golden = ctx.golden("streaming", default={}) or {}
        default_stream = bool(golden.get("default_enabled", False))

        nonstream = ctx.vendor.chat(
            [{"role": "user", "content": "Reply with the single word pong."}],
            max_tokens=32,
        )
        looks_stream = bool(nonstream.chunks) or (nonstream.headers.get("content-type") or "").startswith(
            "text/event-stream"
        )
        if default_stream:
            checks.append(
                (ok_check if looks_stream else fail_check)(
                    "default_streaming",
                    looks_stream,
                    expected=True,
                    detail="golden says streaming is on by default",
                )
            )
        else:
            checks.append(
                (ok_check if nonstream.ok and not looks_stream else warn_check)(
                    "default_streaming",
                    {"ok": nonstream.ok, "sse": looks_stream},
                    expected="non-stream JSON",
                    detail="model contract default stream=false",
                )
            )

        streamed = ctx.vendor.chat(
            [{"role": "user", "content": "Count from 1 to 5, comma separated."}],
            stream=True,
            extra={"stream_options": {"include_usage": True}},
            max_tokens=128,
        )
        if not streamed.ok:
            checks.append(
                fail_check(
                    "enable_stream",
                    {"status": streamed.status_code, "error": streamed.error or streamed.text[:200]},
                    expected="SSE 2xx",
                    detail="stream=true failed",
                )
            )
            return self.result(checks, summary="streaming failed")

        n_chunks = len(streamed.chunks)
        checks.append(
            (ok_check if n_chunks >= 1 else fail_check)(
                "enable_stream",
                n_chunks,
                expected=">=1 SSE chunks",
                detail=f"received {n_chunks} chunks, ttft={streamed.ttft_s}",
            )
        )

        closed = ctx.vendor.chat(
            [{"role": "user", "content": "Reply with the single word pong."}],
            stream=False,
            max_tokens=16,
        )
        checks.append(
            (ok_check if closed.ok and not closed.chunks else fail_check)(
                "disable_stream",
                {"ok": closed.ok, "chunks": len(closed.chunks)},
                expected="non-stream JSON",
            )
        )

        usage_every = 0
        usage_last = False
        for i, ch in enumerate(streamed.chunks):
            u = extract_usage(ch)
            if u:
                usage_every += 1
                if i == len(streamed.chunks) - 1:
                    usage_last = True
        # last chunk may be a usage-only extra chunk
        if streamed.chunks:
            last_u = extract_usage(streamed.chunks[-1])
            usage_last = bool(last_u) or bool(streamed.usage)

        expect_every = bool(golden.get("usage_in_every_chunk", False))
        expect_last = bool(golden.get("usage_in_last_chunk", True))
        if expect_every:
            checks.append(
                (ok_check if usage_every == n_chunks else fail_check)(
                    "usage_every_chunk",
                    usage_every,
                    expected=n_chunks,
                )
            )
        else:
            checks.append(
                (ok_check if usage_every <= 2 else warn_check)(
                    "usage_not_every_chunk",
                    usage_every,
                    expected="usage only at end",
                    detail=f"usage appeared in {usage_every}/{n_chunks} chunks",
                )
            )
        checks.append(
            (ok_check if usage_last and streamed.usage else fail_check)(
                "usage_last_chunk",
                streamed.usage,
                expected="prompt/completion/total/cached tokens",
                detail=f"last_chunk_usage={bool(usage_last)} usage={streamed.usage}",
            )
        )

        fields = list(iter_stream_contents(streamed.chunks))
        has_reason = any(k == "reasoning_content" for k, _ in fields)
        has_content = any(k == "content" for k, _ in fields)
        checks.append(
            (ok_check if has_reason or has_content else warn_check)(
                "stream_delta_fields",
                {"reasoning": has_reason, "content": has_content},
                expected="delta.reasoning_content then delta.content",
            )
        )

        summary = f"chunk数={n_chunks}，末尾含usage={bool(streamed.usage)}，首包时延={streamed.ttft_s}"
        return self.result(checks, summary=summary, metrics={"chunks": n_chunks, "ttft_s": streamed.ttft_s})
