from __future__ import annotations

from tokenhub_bench.clients.http import cached_tokens
from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, pad_prompt, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.cache")
class CacheModule(BaseModule):
    title = "Cache能力支持"
    template_rows = [21, 22, 23]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []
        spec = ctx.golden("cache", default={}) or {}
        mode = spec.get("mode", "automatic")
        min_prefix = int(spec.get("min_prefix_tokens", 256))
        require_field = spec.get("require_cached_tokens_field", True)
        unknown_param = spec.get("unknown_cache_param", "warn_if_accepted")
        explicit_supported = bool(spec.get("explicit_cache_supported", False))
        cached_paths = spec.get("cached_tokens_paths") or None

        prefix = pad_prompt(max(min_prefix + 64, 512), seed="cache-prefix")
        messages = [
            {"role": "system", "content": prefix},
            {"role": "user", "content": "Reply with the single word one."},
        ]
        first = ctx.vendor.chat(messages, max_tokens=16)
        second = ctx.vendor.chat(
            [
                {"role": "system", "content": prefix},
                {"role": "user", "content": "Reply with the single word two."},
            ],
            max_tokens=16,
        )
        if not first.ok or not second.ok:
            checks.append(
                fail_check(
                    "cache_probe_calls",
                    {"first": first.status_code, "second": second.status_code},
                    expected="2xx",
                    detail=(first.error or second.error or "")[:200],
                )
            )
            return self.result(checks, summary="cache probe failed")

        c1 = cached_tokens(first.usage or {}, paths=cached_paths)
        c2 = cached_tokens(second.usage or {}, paths=cached_paths)
        has_field = c1 is not None or c2 is not None
        if require_field:
            checks.append(
                (ok_check if has_field else fail_check)(
                    "cached_tokens_field",
                    {"first": first.usage, "second": second.usage},
                    expected=cached_paths
                    or "usage.cached_tokens or usage.prompt_tokens_details.cached_tokens",
                    detail="model contract requires cached token accounting",
                )
            )
        elif not has_field:
            checks.append(
                skip_check(
                    "cached_tokens_field",
                    "model contract does not require cached_tokens in usage",
                )
            )

        if mode == "automatic":
            checks.append(
                ok_check(
                    "cache_mode",
                    "automatic",
                    expected="automatic (no cache id / TTL param)",
                    detail="model cache contract is automatic prefix cache",
                )
            )
            if explicit_supported:
                checks.append(
                    skip_check(
                        "explicit_cache_param",
                        "model contract supports an explicit cache API; not probed here",
                    )
                )
            else:
                checks.append(self._judge_unknown_cache_param(ctx, messages, unknown_param))
        else:
            checks.append(
                skip_check("cache_mode", f"golden cache mode={mode}, implement vendor-specific setter")
            )

        ttl = spec.get("ttl", "automatic")
        checks.append(
            ok_check("cache_ttl", ttl, expected="automatic / no user TTL", detail="model contract has no user TTL")
        )

        if has_field and c2 is not None and int(c2) > 0:
            checks.append(ok_check("cache_hit_on_repeat", c2, expected=">0 cached_tokens on 2nd call"))
        elif has_field:
            checks.append(
                warn_check(
                    "cache_hit_on_repeat",
                    c2,
                    expected=">0",
                    detail="field exists but second call did not hit cache (engine prefix cache may need identical prefix + warmup)",
                )
            )

        return self.result(
            checks,
            summary=f"mode={mode} cached_tokens first={c1} second={c2}",
            metrics={"cached_tokens_first": c1, "cached_tokens_second": c2},
        )

    def _judge_unknown_cache_param(self, ctx, messages, policy: str) -> Check:
        explicit = ctx.vendor.chat(
            messages,
            extra={"cache_control": {"type": "ephemeral"}},
            max_tokens=8,
        )
        if explicit.status_code == 0 or explicit.status_code >= 500:
            return warn_check(
                "explicit_cache_param",
                {"status": explicit.status_code, "error": explicit.error or (explicit.text or "")[:200]},
                expected="a conclusive 2xx or 4xx response",
                detail="unknown cache parameter probe was inconclusive",
            )
        if policy == "ignore":
            return ok_check(
                "explicit_cache_param",
                explicit.status_code,
                expected="not part of model contract",
                detail="unknown cache_control is outside this model's API; accept or reject both pass",
            )
        if policy == "reject":
            rejected = 400 <= explicit.status_code < 500
            return (ok_check if rejected else fail_check)(
                "explicit_cache_param",
                explicit.status_code,
                expected="4xx, explicit cache_control is not in the contract",
                detail="model contract rejects unknown cache params",
            )
        if explicit.ok:
            return warn_check(
                "explicit_cache_param",
                explicit.status_code,
                expected="not required / may 400",
                detail="vendor accepted extra cache_control; model contract is automatic-only",
            )
        return ok_check(
            "explicit_cache_param",
            explicit.status_code,
            expected="ignored or rejected",
            detail="explicit cache param not required by model contract",
        )
