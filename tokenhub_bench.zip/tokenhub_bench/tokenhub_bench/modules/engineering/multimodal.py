from __future__ import annotations

from tokenhub_bench.modules.base import (
    TINY_PNG_B64,
    BaseModule,
    assistant_fields,
    fail_check,
    ok_check,
    skip_check,
    warn_check,
)
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check, HttpResult


def _mm_message(kind: str) -> list[dict]:
    if kind == "image":
        url = f"data:image/png;base64,{TINY_PNG_B64}"
        content = [
            {"type": "text", "text": "Describe this image in one sentence."},
            {"type": "image_url", "image_url": {"url": url}},
        ]
    elif kind == "audio":
        content = [
            {"type": "text", "text": "Transcribe this audio."},
            {
                "type": "input_audio",
                "input_audio": {"data": "AAAA", "format": "wav"},
            },
        ]
    else:
        content = [
            {"type": "text", "text": "Describe this video in one sentence."},
            {
                "type": "video_url",
                "video_url": {"url": f"data:image/png;base64,{TINY_PNG_B64}"},
            },
        ]
    return [{"role": "user", "content": content}]


def _classify(res: HttpResult, expect_support: bool, unsupported_policy: str) -> Check:
    name_map_ok = res.ok and bool((assistant_fields(res).get("content") or assistant_fields(res).get("reasoning_content")))
    if expect_support:
        if name_map_ok:
            return ok_check("supported", True, detail=f"HTTP {res.status_code}")
        return fail_check(
            "supported",
            {"status": res.status_code, "body": (res.text or "")[:200]},
            expected="2xx with understanding",
        )
    if res.status_code == 0 or res.status_code >= 500:
        return warn_check(
            "unsupported_inconclusive",
            {"status": res.status_code, "error": res.error or (res.text or "")[:200]},
            expected="a conclusive 2xx or unsupported-media 4xx response",
        )
    if res.status_code in (400, 415, 422):
        return ok_check("unsupported_like_official", res.status_code, expected="reject")
    if not res.ok:
        return warn_check(
            "unsupported_inconclusive",
            res.status_code,
            expected="400/415/422 for unsupported media",
            detail=(res.text or res.error or "")[:200],
        )
    if unsupported_policy == "ignore":
        return ok_check(
            "unsupported_like_official",
            res.status_code,
            expected="ignore extra modality",
            detail="model contract does not require rejecting unsupported media",
        )
    return warn_check(
        "unexpected_accept",
        res.status_code,
        expected="reject (model contract does not support this modality)",
    )


@register("engineering.multimodal")
class MultimodalModule(BaseModule):
    title = "多模态能力支持"
    template_rows = [18, 19, 20]

    def run(self):
        ctx = self.ctx
        mm = ctx.golden("multimodal", default={}) or {}
        unsupported_policy = str(mm.get("unsupported", "reject"))
        checks: list[Check] = []
        mapping = [("image", 18), ("audio", 19), ("video", 20)]
        for kind, _row in mapping:
            expect = bool(mm.get(kind, False))
            res = ctx.vendor.chat(_mm_message(kind), max_tokens=64)
            c = _classify(res, expect, unsupported_policy)
            c.name = f"{kind}_input"
            if res.status_code in (404, 405) and not expect:
                c = skip_check(f"{kind}_input", "endpoint rejected multimodal part")
            checks.append(c)
            fields = assistant_fields(res)
            if kind == "image" and expect and res.ok:
                content = str(fields.get("content") or "")
                if not content and not fields.get("reasoning_content"):
                    checks.append(fail_check("image_understood", content, expected="non-empty description"))
        return self.result(checks, summary=", ".join(f"{c.name}={c.status.value}" for c in checks))
