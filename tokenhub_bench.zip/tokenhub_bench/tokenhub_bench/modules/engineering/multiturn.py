from __future__ import annotations

from tokenhub_bench.modules.base import (
    BaseModule,
    assistant_fields,
    contains_think_tag,
    fail_check,
    ok_check,
    warn_check,
)
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.multiturn")
class MultiturnModule(BaseModule):
    title = "多轮对话支持"
    template_rows = [26]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []
        messages = [{"role": "user", "content": "My name is TokenHubProbe. Just acknowledge."}]
        first = ctx.vendor.chat(messages, max_tokens=128)
        f = assistant_fields(first)
        if not first.ok:
            return self.result(
                [fail_check("turn1", first.status_code, detail=first.text[:200])],
                summary="turn1 failed",
            )
        content = f.get("content")
        if content in (None, ""):
            checks.append(fail_check("turn1_content", content, expected="non-empty content"))
        else:
            checks.append(ok_check("turn1_content", str(content)[:80]))

        asst = {
            "role": "assistant",
            "content": content or "",
        }
        if f.get("reasoning_content"):
            asst["reasoning_content"] = f["reasoning_content"]
        messages = list(messages) + [asst, {"role": "user", "content": "What is my name? Reply with only the name."}]
        second = ctx.vendor.chat(messages, max_tokens=128)
        s = assistant_fields(second)
        if not second.ok:
            checks.append(fail_check("turn2", second.status_code, detail=second.text[:200]))
            return self.result(checks, summary="turn2 failed")

        reply = str(s.get("content") or "")
        remembered = "tokenhubprobe" in reply.lower().replace(" ", "")
        garbled = contains_think_tag(reply) or "\ufffd" in reply
        fr = s.get("finish_reason")
        checks.append(
            (ok_check if remembered else warn_check)(
                "context_carried",
                reply[:200],
                expected="TokenHubProbe",
                detail="model should reuse the name from turn 1",
            )
        )
        checks.append(
            (fail_check if garbled or not reply else ok_check)(
                "no_garbled_or_empty",
                {"garbled": garbled, "finish_reason": fr, "empty": not reply},
                expected="clean non-empty content, finish_reason stop/length/tool_calls",
            )
        )
        if fr not in (None, "stop", "length", "tool_calls"):
            checks.append(warn_check("finish_reason", fr, expected="stop/length/tool_calls"))
        return self.result(checks, summary=f"remembered={remembered} finish_reason={fr}")
