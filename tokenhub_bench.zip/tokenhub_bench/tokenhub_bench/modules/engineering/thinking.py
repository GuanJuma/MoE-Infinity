from __future__ import annotations

from tokenhub_bench.modules.base import (
    BaseModule,
    assistant_fields,
    contains_think_tag,
    fail_check,
    ok_check,
    skip_check,
    warn_check,
)
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.thinking")
class ThinkingModule(BaseModule):
    title = "思考模式"
    template_rows = [5, 6]

    # Hybrid thinking（Hy3 等）：开关走 reasoning_effort，而非 Kimi 式 thinking.type。
    # 按顺序尝试，兼容 sglang 顶层参数与 chat_template_kwargs 两种传法。
    DEFAULT_ENABLE_BODIES = [
        {"reasoning_effort": "high"},
        {"chat_template_kwargs": {"reasoning_effort": "high"}},
    ]
    DEFAULT_DISABLE_BODIES = [
        {"chat_template_kwargs": {"reasoning_effort": "no_think"}},
        {"reasoning_effort": "none"},
        {"reasoning_effort": "no_think"},
    ]

    def run(self):
        ctx = self.ctx
        checks: list[Check] = []
        golden = ctx.golden("thinking", default={}) or {}
        # thinking_param: thinking.type 开关；reasoning_effort: hybrid thinking
        control = golden.get("control", "thinking_param")
        expect_on = bool(golden.get("default_enabled", True))
        can_disable = bool(golden.get("can_disable", False))
        location = golden.get("reasoning_location", "reasoning_content")

        default = ctx.vendor.chat(
            [{"role": "user", "content": "What is 17*19? Show the arithmetic."}],
            max_tokens=1024,
        )
        fields = assistant_fields(default)
        if not default.ok:
            checks.append(
                fail_check(
                    "default_call",
                    fields,
                    expected="2xx chat completion",
                    detail=f"HTTP {default.status_code} {default.error or default.text[:300]}",
                )
            )
            return self.result(checks, summary="default thinking call failed")

        rc = fields.get("reasoning_content")
        content = fields.get("content") or ""
        think_in_content = contains_think_tag(content if isinstance(content, str) else str(content))

        if expect_on:
            if rc:
                checks.append(
                    ok_check(
                        "default_thinking_on",
                        {"reasoning_len": len(str(rc)), "in_content_think_tag": think_in_content},
                        expected="reasoning_content present",
                        detail="default request returned reasoning_content",
                    )
                )
            elif think_in_content:
                checks.append(
                    fail_check(
                        "default_thinking_on",
                        "think-tag-in-content",
                        expected=location,
                        detail=f"thinking leaked into content via <think>; model contract uses {location}",
                    )
                )
            else:
                checks.append(
                    fail_check(
                        "default_thinking_on",
                        {
                            "finish_reason": fields.get("finish_reason"),
                            "reasoning_tokens": fields.get("reasoning_tokens"),
                            "content_head": str(content)[:240],
                            "usage": fields.get("usage"),
                        },
                        expected="reasoning_content (or <think> in content)",
                        detail=(
                            "default request did not return thinking content. "
                            "vLLM/SGLang 需要开启 reasoning parser，否则只有普通 content，"
                            "usage.reasoning_tokens 也会是 0。"
                        ),
                    )
                )
        else:
            if rc or think_in_content:
                checks.append(
                    fail_check(
                        "default_thinking_off",
                        bool(rc) or think_in_content,
                        expected=False,
                        detail="thinking appeared although golden says default off",
                    )
                )
            else:
                checks.append(ok_check("default_thinking_off", False, expected=False))

        loc_ok = bool(rc) and not think_in_content
        if rc and think_in_content:
            checks.append(
                warn_check(
                    "thinking_location",
                    "both",
                    expected=location,
                    detail="both reasoning_content and <think> in content",
                )
            )
        elif loc_ok:
            checks.append(
                ok_check(
                    "thinking_location",
                    "reasoning_content",
                    expected=location,
                    detail="thinking is in reasoning_content, not <think> tags",
                )
            )

        if control == "reasoning_effort":
            checks.extend(self._reasoning_effort_checks(golden))
            summary = (
                f"控制方式=reasoning_effort，默认开启={expect_on}，"
                f"默认请求含思考={bool(rc)}，存放位置={location}"
            )
            return self.result(checks, summary=summary)

        # ---- thinking.type 契约（control=thinking_param）----
        disable_body = {"thinking": {"type": "disabled"}}
        disabled = ctx.vendor.chat(
            [{"role": "user", "content": "Say hi in one word."}],
            extra=disable_body,
            max_tokens=128,
        )
        if can_disable:
            df = assistant_fields(disabled)
            still_thinks = bool(df.get("reasoning_content")) or contains_think_tag(df.get("content") or "")
            checks.append(
                (fail_check if still_thinks or not disabled.ok else ok_check)(
                    "disable_thinking",
                    {"ok": disabled.ok, "still_thinks": still_thinks, "status": disabled.status_code},
                    expected="thinking off",
                    detail="disable switch should stop reasoning_content",
                )
            )
        else:
            disable_returns_error = bool(golden.get("disable_returns_error", True))
            if disabled.status_code >= 400:
                checks.append(
                    ok_check(
                        "disable_thinking_rejected",
                        disabled.status_code,
                        expected="error (model contract cannot disable thinking)",
                        detail=f"disable thinking returned HTTP {disabled.status_code}",
                    )
                )
            else:
                df = assistant_fields(disabled)
                still = bool(df.get("reasoning_content"))
                checks.append(
                    warn_check(
                        "disable_thinking_rejected",
                        {"status": disabled.status_code, "still_thinks": still},
                        expected="4xx" if disable_returns_error else "thinking off",
                        detail="model contract rejects thinking.disabled; vendor accepted it",
                    )
                )

        accepted = golden.get("accepted_thinking_body") or {"type": "enabled", "keep": "all"}
        enable_ok = ctx.vendor.chat(
            [{"role": "user", "content": "Name one prime larger than 20."}],
            extra={"thinking": accepted},
            max_tokens=256,
        )
        ef = assistant_fields(enable_ok)
        checks.append(
            (ok_check if enable_ok.ok and ef.get("reasoning_content") else warn_check)(
                "enable_keep_all",
                {"ok": enable_ok.ok, "has_reasoning": bool(ef.get("reasoning_content"))},
                expected="accepted + reasoning_content",
                detail=f"accepted thinking body is {accepted}",
            )
        )

        summary = (
            f"默认开启={expect_on}，存放位置={location}，"
            f"含思考内容={bool(rc)}，关闭思考HTTP={disabled.status_code}"
        )
        return self.result(checks, summary=summary)

    def _reasoning_effort_checks(self, golden: dict) -> list[Check]:
        """Hybrid thinking：用 reasoning_effort 开/关思考，逐一尝试可用传法。"""
        ctx = self.ctx
        checks: list[Check] = []

        enable_bodies = golden.get("enable_bodies") or self.DEFAULT_ENABLE_BODIES
        hit = None
        misses: list[dict] = []
        for body in enable_bodies:
            r = ctx.vendor.chat(
                [{"role": "user", "content": "Name one prime larger than 20. Think it through."}],
                extra=body,
                max_tokens=512,
            )
            f = assistant_fields(r)
            if r.ok and f.get("reasoning_content"):
                hit = (body, f)
                break
            misses.append(
                {
                    "body": body,
                    "status": r.status_code,
                    "has_reasoning": bool(f.get("reasoning_content")),
                    "err": (r.error or (r.text or "")[:160]),
                }
            )
        if hit:
            body, f = hit
            checks.append(
                ok_check(
                    "enable_reasoning_effort",
                    {"body": body, "reasoning_len": len(str(f.get("reasoning_content")))},
                    expected="reasoning_content present",
                    detail=f"thinking enabled via {body}",
                )
            )
        else:
            checks.append(
                fail_check(
                    "enable_reasoning_effort",
                    misses,
                    expected="reasoning_content present with any enable body",
                    detail=(
                        "reasoning_effort 应能开启思考；"
                        "引擎侧需开启对应 reasoning parser 才会输出 reasoning_content"
                    ),
                )
            )

        disable_bodies = golden.get("disable_bodies") or self.DEFAULT_DISABLE_BODIES
        hit_off = None
        misses_off: list[dict] = []
        for body in disable_bodies:
            r = ctx.vendor.chat(
                [{"role": "user", "content": "Say hi in one word."}],
                extra=body,
                max_tokens=128,
            )
            f = assistant_fields(r)
            still = bool(f.get("reasoning_content")) or contains_think_tag(f.get("content") or "")
            if r.ok and not still:
                hit_off = (body, r)
                break
            misses_off.append(
                {"body": body, "status": r.status_code, "has_reasoning": still}
            )
        if hit_off:
            checks.append(
                ok_check(
                    "disable_reasoning_effort",
                    {"body": hit_off[0]},
                    expected="no reasoning_content",
                    detail=f"thinking disabled via {hit_off[0]}",
                )
            )
        else:
            checks.append(
                fail_check(
                    "disable_reasoning_effort",
                    misses_off,
                    expected="no reasoning_content with any disable body",
                    detail="显式关闭思考的请求应被接受且不返回 reasoning_content",
                )
            )

        return checks
