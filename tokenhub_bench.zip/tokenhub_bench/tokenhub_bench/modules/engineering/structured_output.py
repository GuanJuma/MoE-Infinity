from __future__ import annotations

import json

from tokenhub_bench.modules.base import BaseModule, assistant_fields, fail_check, ok_check, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check

PERSON_SCHEMA = {
    "type": "json_schema",
    "json_schema": {
        "name": "person",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name", "age"],
            "additionalProperties": False,
        },
    },
}


@register("engineering.structured_output")
class StructuredOutputModule(BaseModule):
    title = "结构化输出能力支持"
    template_rows = [34, 35, 36]

    def run(self):
        ctx = self.ctx
        spec = ctx.golden("structured_output", default={}) or {}
        checks: list[Check] = []

        text = ctx.vendor.chat(
            [{"role": "user", "content": "Say hello in one short sentence."}],
            extra={"response_format": {"type": "text"}},
            max_tokens=64,
        )
        tf = assistant_fields(text)
        if spec.get("text", True):
            checks.append(
                (ok_check if text.ok and tf.get("content") else fail_check)(
                    "response_format_text",
                    {"status": text.status_code, "content": str(tf.get("content"))[:80]},
                    expected='type="text"',
                )
            )
        else:
            checks.append(skip_check("response_format_text", "golden disabled"))

        js = ctx.vendor.chat(
            [
                {
                    "role": "system",
                    "content": 'Return a JSON object {"city": string, "temp": number}.',
                },
                {"role": "user", "content": "Beijing weather as JSON."},
            ],
            extra={"response_format": {"type": "json_object"}},
            max_tokens=128,
        )
        jf = assistant_fields(js)
        parsed = None
        if js.ok and jf.get("content"):
            try:
                parsed = json.loads(jf["content"])
            except Exception:
                parsed = None
        if spec.get("json_object", True):
            checks.append(
                (ok_check if isinstance(parsed, dict) else fail_check)(
                    "response_format_json_object",
                    {"status": js.status_code, "parsed": parsed, "raw": str(jf.get("content"))[:160]},
                    expected="valid JSON object",
                    detail="OpenAI protocol only",
                )
            )
        else:
            checks.append(skip_check("response_format_json_object", "golden disabled"))

        schema_flag = spec.get("json_schema")
        if schema_flag is True:
            sch = ctx.vendor.chat(
                [{"role": "user", "content": "Lin is 28 years old. Extract name and age."}],
                extra={"response_format": PERSON_SCHEMA},
                max_tokens=128,
            )
            sf = assistant_fields(sch)
            obj = None
            if sch.ok and sf.get("content"):
                try:
                    obj = json.loads(sf["content"])
                except Exception:
                    obj = None
            schema_ok = isinstance(obj, dict) and "name" in obj and "age" in obj
            if sch.status_code >= 400:
                checks.append(
                    fail_check(
                        "response_format_json_schema",
                        {"status": sch.status_code, "body": sch.text[:200]},
                        expected="schema-constrained JSON",
                    )
                )
            else:
                checks.append(
                    (ok_check if schema_ok else warn_check)(
                        "response_format_json_schema",
                        obj,
                        expected={"name": str, "age": int},
                    )
                )
        else:
            reason = "golden disabled" if schema_flag is False else "golden support is unknown"
            checks.append(skip_check("response_format_json_schema", reason))
        return self.result(checks, summary=", ".join(f"{c.name}={c.status.value}" for c in checks))
