from __future__ import annotations

from tokenhub_bench.i18n import zh_check_name
from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.auth")
class AuthModule(BaseModule):
    title = "鉴权与安全"
    template_rows = [30]

    def run(self):
        ctx = self.ctx
        expect_invalid = int(ctx.golden("auth", "invalid_key_status", default=401))
        expect_missing = int(ctx.golden("auth", "missing_auth_status", default=401))
        body = {"model": ctx.vendor.model, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 8}
        checks: list[Check] = []

        missing = ctx.vendor.request("POST", "/chat/completions", json_body=body, auth=False)
        checks.append(
            (ok_check if missing.status_code == expect_missing else fail_check)(
                "missing_authorization",
                missing.status_code,
                expected=expect_missing,
                detail=(missing.text or "")[:200],
            )
        )

        bad = ctx.vendor.request(
            "POST",
            "/chat/completions",
            json_body=body,
            headers={"Authorization": "Bearer sk-invalid-tokenhub-probe"},
        )
        checks.append(
            (ok_check if bad.status_code == expect_invalid else fail_check)(
                "invalid_api_key",
                bad.status_code,
                expected=expect_invalid,
                detail=(bad.text or "")[:200],
            )
        )

        # Expired/revoked token: if vendor did not provide one, skip with instruction.
        revoked = self.params.get("revoked_api_key") or ctx.cfg.get("vendor", "revoked_api_key", default="")
        if revoked:
            rev = ctx.vendor.request(
                "POST",
                "/chat/completions",
                json_body=body,
                headers={"Authorization": f"Bearer {revoked}"},
            )
            checks.append(
                (ok_check if rev.status_code == expect_invalid else fail_check)(
                    "revoked_or_expired_token",
                    rev.status_code,
                    expected=expect_invalid,
                    detail=(rev.text or "")[:200],
                )
            )
        else:
            checks.append(
                warn_check(
                    "revoked_or_expired_token",
                    None,
                    expected=401,
                    detail="set vendor.revoked_api_key in config to test revoked tokens",
                )
            )

        good = ctx.vendor.chat([{"role": "user", "content": "hi"}], max_tokens=8)
        if ctx.vendor.api_key in ("", "EMPTY"):
            checks.append(
                warn_check(
                    "valid_key_control",
                    good.status_code,
                    expected="2xx if the cluster requires a key, or open if it does not",
                    detail="TOKENHUB_API_KEY is empty — cluster may be open; confirm this is intended",
                )
            )
        else:
            checks.append(
                (ok_check if good.ok else fail_check)(
                    "valid_key_control",
                    good.status_code,
                    expected=200,
                )
            )
        return self.result(checks, summary="，".join(
            f"{zh_check_name(c.name)}={c.actual}" for c in checks
        ))
