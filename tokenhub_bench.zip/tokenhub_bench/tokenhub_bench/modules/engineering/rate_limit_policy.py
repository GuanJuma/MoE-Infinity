from __future__ import annotations

from tokenhub_bench.modules.base import BaseModule, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.rate_limit_policy")
class RateLimitPolicyModule(BaseModule):
    title = "增速限流策略"
    template_rows = [42]

    def run(self):
        note = (
            "模板要求供应商特殊说明：是否对客户有增速限流（ramp / warmup QPS）。"
            "本模块不臆造策略。请在硬件 YAML 填写 rate_limit_policy，"
            "或把说明放到 vendor.rate_limit_policy。"
        )
        policy = self.ctx.cfg.get("vendor", "rate_limit_policy", default=None)
        checks: list[Check] = []
        if policy:
            checks.append(
                warn_check(
                    "declared_policy",
                    policy,
                    expected="human confirmation",
                    detail=str(policy),
                )
            )
        else:
            checks.append(skip_check("declared_policy", note))
        return self.result(checks, summary=str(policy or "need vendor statement"), notes=note)
