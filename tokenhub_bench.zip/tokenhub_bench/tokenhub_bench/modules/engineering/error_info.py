from __future__ import annotations

from tokenhub_bench.modules.base import BaseModule, fail_check, leak_hits, ok_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("engineering.error_info")
class ErrorInfoModule(BaseModule):
    title = "错误信息返回说明"
    template_rows = [29]

    def run(self):
        ctx = self.ctx
        needles = ctx.leak_needles()
        checks: list[Check] = []
        scenarios = {
            "bad_model": ctx.vendor.request(
                "POST",
                "/chat/completions",
                json_body={"model": "definitely-not-a-real-model-xxx", "messages": [{"role": "user", "content": "hi"}]},
            ),
            "malformed_json_field": ctx.vendor.chat(
                [{"role": "user", "content": "hi"}],
                extra={"max_tokens": "not-a-number"},
            ),
            "empty_messages": ctx.vendor.request(
                "POST",
                "/chat/completions",
                json_body={"model": ctx.vendor.model, "messages": []},
            ),
        }
        unknown_model = str((ctx.golden("error_info", default={}) or {}).get("unknown_model", "reject"))
        leaked_all = []
        for name, res in scenarios.items():
            text = res.text or ""
            hits = leak_hits(text, needles)
            leaked_all.extend(hits)
            accepted = res.status_code < 400 and res.ok
            if name == "bad_model" and unknown_model == "ignore":
                if hits:
                    check_fn = fail_check
                elif res.status_code == 0 or res.status_code >= 500:
                    check_fn = warn_check
                else:
                    check_fn = ok_check
                checks.append(
                    check_fn(
                        f"{name}_no_vendor_leak",
                        {"status": res.status_code, "hits": hits, "body": text[:240]},
                        expected="2xx/4xx without vendor leak",
                        detail=f"HTTP {res.status_code}; model contract ignores unknown model id",
                    )
                )
                continue
            if accepted:
                checks.append(
                    warn_check(name, res.status_code, expected="4xx/5xx error scene", detail=text[:160])
                )
                continue
            checks.append(
                (fail_check if hits else ok_check)(
                    f"{name}_no_vendor_leak",
                    {"status": res.status_code, "hits": hits, "body": text[:240]},
                    expected="error JSON without supplier name/url",
                    detail=f"HTTP {res.status_code}",
                )
            )
        summary = f"leak_hits={sorted(set(leaked_all)) or 'none'}"
        return self.result(checks, summary=summary)
