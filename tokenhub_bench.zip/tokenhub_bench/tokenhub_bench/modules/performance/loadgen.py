from __future__ import annotations

import math
import statistics
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from tokenhub_bench.clients.http import EndpointClient
from tokenhub_bench.modules.performance.kit import pad_factory
from tokenhub_bench.types import HttpResult


@dataclass
class Sample:
    ok: bool
    status: int
    elapsed_s: float
    ttft_s: Optional[float]
    prompt_tokens: int
    completion_tokens: int
    output_tps: Optional[float]
    error: str = ""
    tpot_s: Optional[float] = None
    itl_s: Optional[float] = None


@dataclass
class LoadStats:
    samples: list[Sample] = field(default_factory=list)
    started: float = 0.0
    ended: float = 0.0

    @property
    def duration_s(self) -> float:
        return max(self.ended - self.started, 1e-6)

    def success_rate(self) -> float:
        if not self.samples:
            return 0.0
        return sum(1 for s in self.samples if s.ok) / len(self.samples)

    def percentile(self, attr: str, p: float) -> Optional[float]:
        vals = [getattr(s, attr) for s in self.samples if s.ok and getattr(s, attr) is not None]
        if not vals:
            return None
        vals = sorted(vals)
        k = max(0.0, min(float(len(vals) - 1), (p / 100.0) * (len(vals) - 1)))
        lower, upper = math.floor(k), math.ceil(k)
        if lower == upper:
            return float(vals[lower])
        return float(vals[lower] + (vals[upper] - vals[lower]) * (k - lower))

    def avg(self, attr: str) -> Optional[float]:
        vals = [getattr(s, attr) for s in self.samples if s.ok and getattr(s, attr) is not None]
        if not vals:
            return None
        return float(statistics.mean(vals))

    def _token_sum(self, attr: str) -> int:
        return sum(int(getattr(s, attr) or 0) for s in self.samples if s.ok)

    def tpm(self) -> float:
        tokens = self._token_sum("prompt_tokens") + self._token_sum("completion_tokens")
        return tokens / self.duration_s * 60.0

    def input_tpm(self) -> float:
        return self._token_sum("prompt_tokens") / self.duration_s * 60.0

    def output_tpm(self) -> float:
        return self._token_sum("completion_tokens") / self.duration_s * 60.0

    def rpm(self) -> float:
        n = sum(1 for s in self.samples if s.ok)
        return n / self.duration_s * 60.0

    def to_dict(self) -> dict[str, Any]:
        failures = [
            {"status": s.status, "error": (s.error or "")[:500]}
            for s in self.samples
            if not s.ok
        ][:20]
        return {
            "n": len(self.samples),
            "success_rate": self.success_rate(),
            "ttft_p50": self.percentile("ttft_s", 50),
            "ttft_p90": self.percentile("ttft_s", 90),
            "ttft_p95": self.percentile("ttft_s", 95),
            "ttft_p99": self.percentile("ttft_s", 99),
            "ttft_avg": self.avg("ttft_s"),
            "ttft_min": self.percentile("ttft_s", 0),
            "ttft_max": self.percentile("ttft_s", 100),
            "ttlt_avg": self.avg("elapsed_s"),
            "ttlt_p50": self.percentile("elapsed_s", 50),
            "ttlt_p90": self.percentile("elapsed_s", 90),
            "tpot_avg": self.avg("tpot_s"),
            "tpot_p50": self.percentile("tpot_s", 50),
            "tpot_p90": self.percentile("tpot_s", 90),
            # EndpointClient currently records TTFT and total latency, not each
            # chunk timestamp, so true inter-token latency is unavailable.
            "itl_avg": self.avg("itl_s"),
            "itl_p50": self.percentile("itl_s", 50),
            "itl_p90": self.percentile("itl_s", 90),
            "itl_available": False,
            "otps_avg": self.avg("output_tps"),
            "otps_p50": self.percentile("output_tps", 50),
            "tpm": self.tpm(),
            "input_tpm": self.input_tpm(),
            "output_tpm": self.output_tpm(),
            "output_tps": self._token_sum("completion_tokens") / self.duration_s,
            "rpm": self.rpm(),
            "duration_s": self.duration_s,
            "failures": failures,
        }


def _to_sample(res: HttpResult) -> Sample:
    usage = res.usage or {}
    pt = int(usage.get("prompt_tokens") or 0)
    ct = int(usage.get("completion_tokens") or 0)
    otps = None
    tpot = None
    gen_s = res.elapsed_s - (res.ttft_s or 0)
    if res.ok and ct > 1 and gen_s > 0:
        tpot = gen_s / (ct - 1)
        otps = 1.0 / tpot
    ok = res.ok and res.status_code < 400
    return Sample(
        ok=ok,
        status=res.status_code,
        elapsed_s=res.elapsed_s,
        ttft_s=res.ttft_s,
        prompt_tokens=pt,
        completion_tokens=ct,
        output_tps=otps,
        error="" if ok else (res.error or res.text or "")[:500],
        tpot_s=tpot,
    )


def with_stream_usage(extra: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Ask OpenAI-compatible engines for a final SSE usage chunk (completion_tokens)."""
    body = dict(extra or {})
    opts = dict(body.get("stream_options") or {})
    opts["include_usage"] = True
    body["stream_options"] = opts
    return body


def run_load(
    client: EndpointClient,
    *,
    concurrency: int,
    max_tokens: int = 64,
    stream: bool = True,
    duration_s: Optional[float] = None,
    number: Optional[int] = None,
    input_tokens: int = 256,
    prompt_factory: Optional[Callable[[], list[dict[str, Any]]]] = None,
    stop: Optional[threading.Event] = None,
    extra: Optional[dict[str, Any]] = None,
    include_stream_usage: bool = True,
    on_sample: Optional[Callable[[int, Optional[int], Sample], None]] = None,
) -> LoadStats:
    """Duration hold or fixed request count, matching perf-kit `--number` / `--parallel`."""
    if number is None and duration_s is None:
        raise ValueError("run_load requires number or duration_s")
    factory = prompt_factory or pad_factory(input_tokens)
    stats = LoadStats(started=time.perf_counter())
    deadline = stats.started + float(duration_s) if duration_s is not None else None
    lock = threading.Lock()
    remaining = {"n": int(number)} if number is not None else None
    completed = {"n": 0}
    total = int(number) if number is not None else None
    stream_extra = with_stream_usage(extra) if stream and include_stream_usage else extra

    def _take() -> bool:
        if stop and stop.is_set():
            return False
        if deadline is not None and time.perf_counter() >= deadline:
            return False
        if remaining is None:
            return True
        with lock:
            if remaining["n"] <= 0:
                return False
            remaining["n"] -= 1
            return True

    def worker():
        while _take():
            messages = factory()
            res = client.chat(messages, stream=stream, max_tokens=max_tokens, extra=stream_extra)
            sample = _to_sample(res)
            with lock:
                stats.samples.append(sample)
                completed["n"] += 1
                done = completed["n"]
            if on_sample:
                on_sample(done, total, sample)

    n = max(1, int(concurrency))
    with ThreadPoolExecutor(max_workers=n) as pool:
        futs = [pool.submit(worker) for _ in range(n)]
        for f in as_completed(futs):
            f.result()
    stats.ended = time.perf_counter()
    return stats


def run_for_duration(
    client: EndpointClient,
    *,
    duration_s: float,
    concurrency: int,
    input_tokens: int,
    max_tokens: int = 64,
    stream: bool = True,
    stop: Optional[threading.Event] = None,
    prompt_factory: Optional[Callable[[], list[dict[str, Any]]]] = None,
    include_stream_usage: bool = True,
) -> LoadStats:
    return run_load(
        client,
        duration_s=duration_s,
        concurrency=concurrency,
        input_tokens=input_tokens,
        max_tokens=max_tokens,
        stream=stream,
        stop=stop,
        prompt_factory=prompt_factory,
        include_stream_usage=include_stream_usage,
    )
