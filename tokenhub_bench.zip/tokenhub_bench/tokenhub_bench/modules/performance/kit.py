from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any, Callable, Optional

from tokenhub_bench.modules.base import pad_prompt

# Tokenhub perf-kit 档位：真实中文长文 jsonl，区间与 run.sh bucket_range 一致。
KIT_BUCKETS: dict[str, dict[str, int | str]] = {
    "1k": {"file": "perf_zh_1k.jsonl", "min_tokens": 870, "max_tokens": 1228},
    "9k": {"file": "perf_zh_9k.jsonl", "min_tokens": 8000, "max_tokens": 11000},
    "16k": {"file": "perf_zh_16k.jsonl", "min_tokens": 14000, "max_tokens": 18000},
    "32k": {"file": "perf_zh_32k.jsonl", "min_tokens": 28000, "max_tokens": 36000},
    "64k": {"file": "perf_zh_64k.jsonl", "min_tokens": 56000, "max_tokens": 72000},
    "128k": {"file": "perf_zh_128k.jsonl", "min_tokens": 112000, "max_tokens": 144000},
    "200k": {"file": "perf_zh_200k.jsonl", "min_tokens": 180000, "max_tokens": 220000},
}

NAME_TO_KIT = {
    "lt_6k": "1k",
    "6k_16k": "9k",
    "16k_32k": "16k",
    "32k_64k": "32k",
    "64k_128k": "64k",
    "128k_256k": "128k",
    "200k": "200k",
}

DEFAULT_REQUEST_COUNTS = {1: 20, 8: 100, 32: 250, 64: 400, 128: 500}
DEFAULT_CONCURRENCIES = [1, 8, 32, 64, 128]
SMOKE_KITS = ("1k",)
KIT_ORDER = ("1k", "9k", "16k", "32k", "64k", "128k", "200k")


def perf_spec(ctx) -> dict[str, Any]:
    return dict(ctx.cfg.get("performance", default={}) or {})


def kit_id_for_bucket(bucket: dict[str, Any]) -> Optional[str]:
    kid = bucket.get("kit") or bucket.get("kit_bucket")
    if kid:
        return str(kid)
    return NAME_TO_KIT.get(str(bucket.get("name") or ""))


def request_count(ctx, concurrency: int) -> int:
    spec = perf_spec(ctx)
    raw = spec.get("request_counts") or {}
    mapping: dict[int, int] = {}
    if isinstance(raw, dict):
        mapping = {int(k): int(v) for k, v in raw.items()}
    n = int(mapping.get(int(concurrency), DEFAULT_REQUEST_COUNTS.get(int(concurrency), 20)))
    if ctx.quick:
        return max(int(concurrency), min(n, int(spec.get("quick_n", 2))))
    if ctx.cfg.profile_is_smoke():
        return max(int(concurrency), min(n, int(spec.get("smoke_n", 5))))
    return n


def max_tokens_for(ctx, role: str) -> int:
    spec = perf_spec(ctx)
    defaults = {
        "warmup": 32,
        "ttft": 32,
        "otps": 4096,
        "gradient": 4096,
        "soak": 64,
    }
    keys = {
        "warmup": "warmup_max_tokens",
        "ttft": "ttft_max_tokens",
        "otps": "max_output_tokens",
        "gradient": "max_output_tokens",
        "soak": "soak_max_tokens",
    }
    val = int(spec.get(keys[role], defaults[role]))
    if ctx.quick:
        return min(val, 16)
    if ctx.cfg.profile_is_smoke() and role in ("otps", "gradient"):
        return min(val, 128)
    return val


def capacity_kits(ctx) -> list[str]:
    spec = perf_spec(ctx)
    configured = spec.get("capacity_kits")
    if configured:
        kits = [str(x) for x in configured]
    elif ctx.quick or ctx.cfg.profile_is_smoke():
        kits = [str(x) for x in (spec.get("smoke_kits") or SMOKE_KITS)]
    else:
        kits = list(KIT_ORDER)
    if ctx.quick:
        kits = kits[:1]
    return kits


def chat_extra(ctx) -> Optional[dict[str, Any]]:
    """Body extras for perf/capacity requests. Default: force thinking off."""
    spec = perf_spec(ctx)
    raw = spec.get("thinking", "off")
    if raw is False:
        mode = "off"
    elif raw is True:
        mode = "on"
    else:
        mode = str(raw if raw is not None else "off").lower()
    if mode in ("default", "none", ""):
        return None
    golden = ctx.golden("thinking", default={}) or {}
    control = str(golden.get("control") or "thinking_param")
    if mode in ("off", "disable", "disabled"):
        bodies = list(golden.get("disable_bodies") or [])
        if bodies and isinstance(bodies[0], dict):
            return dict(bodies[0])
        if control == "reasoning_effort":
            return {"chat_template_kwargs": {"reasoning_effort": "no_think"}}
        return {"thinking": {"type": "disabled"}}
    if mode in ("on", "enable", "enabled"):
        bodies = list(golden.get("enable_bodies") or [])
        if bodies and isinstance(bodies[0], dict):
            return dict(bodies[0])
        if control == "reasoning_effort":
            return {"reasoning_effort": "high"}
        return {"thinking": {"type": "enabled"}}
    raise ValueError(f"unsupported performance.thinking mode: {raw!r}")


def include_stream_usage(ctx) -> bool:
    return bool(
        ctx.golden(
            "streaming",
            "include_usage_via_stream_options",
            default=True,
        )
    )


def kit_root(ctx) -> Path:
    spec = perf_spec(ctx)
    explicit = str(spec.get("kit_dir") or os.environ.get("TOKENHUB_PERF_KIT") or "").strip()
    if explicit:
        p = Path(explicit).expanduser()
        if not p.is_absolute():
            p = ctx.cfg.root / p
        return p
    return ctx.cfg.root / "datasets" / "perf_zh"


def dataset_path(ctx, kit: str) -> Optional[Path]:
    meta = KIT_BUCKETS.get(kit)
    if not meta:
        return None
    filename = str(meta["file"])
    root = kit_root(ctx)
    for dest in (root / filename, root / "datasets" / filename):
        if dest.is_file() and dest.stat().st_size > 0:
            return dest
    return None


def load_messages(path: Path, limit: int) -> list[list[dict[str, Any]]]:
    out: list[list[dict[str, Any]]] = []
    with path.open(encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(obj, list):
                out.append(obj)
            elif isinstance(obj, dict) and isinstance(obj.get("messages"), list):
                out.append(obj["messages"])
            if len(out) >= max(1, limit):
                break
    return out


class PromptPool:
    def __init__(self, items: list[list[dict[str, Any]]]):
        if not items:
            raise ValueError("empty prompt pool")
        self.items = items
        self.i = 0
        self.lock = threading.Lock()

    def next(self) -> list[dict[str, Any]]:
        with self.lock:
            item = self.items[self.i % len(self.items)]
            self.i += 1
            return item


def pad_factory(input_tokens: int) -> Callable[[], list[dict[str, Any]]]:
    def _factory() -> list[dict[str, Any]]:
        return [
            {
                "role": "user",
                "content": pad_prompt(input_tokens) + "\n\nReply with the single word ok.",
            }
        ]

    return _factory


def prompt_factory_for(
    ctx,
    *,
    kit: Optional[str],
    fallback_tokens: int,
    needed: int,
) -> tuple[Callable[[], list[dict[str, Any]]], dict[str, Any]]:
    meta: dict[str, Any] = {"source": "pad", "kit": kit, "path": None, "n_prompts": 0}
    if kit:
        path = dataset_path(ctx, kit)
        if path is None:
            raise FileNotFoundError(f"missing perf-kit dataset: {kit}")
        msgs = load_messages(path, limit=max(int(needed), 1))
        if not msgs:
            raise ValueError(f"perf-kit dataset has no valid messages: {path}")
        pool = PromptPool(msgs)
        bucket = KIT_BUCKETS.get(kit) or {}
        meta.update(
            source="perf-kit",
            path=str(path),
            n_prompts=len(msgs),
            file=bucket.get("file"),
            min_tokens=bucket.get("min_tokens"),
            max_tokens=bucket.get("max_tokens"),
        )
        return pool.next, meta
    return pad_factory(fallback_tokens), meta
