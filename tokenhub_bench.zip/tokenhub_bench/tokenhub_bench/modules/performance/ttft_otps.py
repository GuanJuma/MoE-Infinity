from __future__ import annotations

import time
from typing import Optional

from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, skip_check
from tokenhub_bench.modules.performance.kit import (
    SMOKE_KITS,
    chat_extra,
    dataset_path,
    include_stream_usage,
    kit_id_for_bucket,
    max_tokens_for,
    perf_spec,
    prompt_factory_for,
    request_count,
)
from tokenhub_bench.modules.performance.loadgen import Sample, run_load
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


def _dur(ctx, key: str, smoke_default: int, admission_default: int) -> int:
    spec = perf_spec(ctx)
    if ctx.quick:
        return min(int(spec.get(key, smoke_default)), 15)
    if ctx.cfg.profile_is_smoke():
        return int(spec.get(key, smoke_default))
    return int(spec.get(key, admission_default))


def _attach(d: dict, meta: dict, **extra) -> dict:
    out = dict(d)
    out.update(meta)
    out.update(extra)
    return out


def _log(msg: str) -> None:
    print(f"[performance.ttft] {msg}", flush=True)


def _sleep_with_progress(seconds: int, label: str) -> None:
    remaining = int(seconds)
    while remaining > 0:
        step = min(15, remaining)
        _log(f"{label} 冷却还剩 {remaining}s")
        time.sleep(step)
        remaining -= step


def _sample_line(done: int, total: Optional[int], sample: Sample) -> str:
    denom = str(total) if total is not None else "?"
    ttft = f"{sample.ttft_s:.3f}s" if sample.ttft_s is not None else "n/a"
    status = "ok" if sample.ok else f"fail status={sample.status}"
    err = ""
    if not sample.ok and sample.error:
        err = " " + sample.error.replace("\n", " ")[:120]
    return f"  {done}/{denom} {status} ttft={ttft} elapsed={sample.elapsed_s:.2f}s{err}"


@register("performance.warmup")
class WarmupModule(BaseModule):
    title = "低并发预热"
    template_rows = [56, 70, 74]

    def run(self):
        ctx = self.ctx
        if dataset_path(ctx, "1k") is None:
            return self.skip("缺少 datasets/perf_zh 数据集 1k")
        n = request_count(ctx, 1)
        factory, meta = prompt_factory_for(ctx, kit="1k", fallback_tokens=256, needed=n)
        stats = run_load(
            ctx.vendor,
            number=n,
            concurrency=1,
            max_tokens=max_tokens_for(ctx, "warmup"),
            stream=True,
            prompt_factory=factory,
            extra=chat_extra(ctx),
            include_stream_usage=include_stream_usage(ctx),
        )
        sr = stats.success_rate()
        d = _attach(stats.to_dict(), meta, concurrency=1, number=n)
        checks: list[Check] = [
            (ok_check if sr >= 0.99 else fail_check)(
                "warmup_success_rate",
                d,
                expected=">=99%",
                detail=f"n={n} source={meta.get('source')}",
            )
        ]
        ctx.extras["warmup_stats"] = d
        return self.result(checks, summary=f"sr={sr:.4f} n={len(stats.samples)}", metrics=d)


@register("performance.ttft")
class TTFTModule(BaseModule):
    title = "TTFT/请求成功率"
    template_rows = [57, 58, 59, 60, 61, 62, 63, 64]

    def run(self):
        ctx = self.ctx
        spec = perf_spec(ctx)
        buckets = list(spec.get("ttft_buckets") or [])
        conc = int(spec.get("ttft_concurrency") or 1)
        smoke_kits = tuple(spec.get("smoke_kits") or SMOKE_KITS)
        cooldown = 0
        if not ctx.quick and not ctx.cfg.profile_is_smoke():
            cooldown = int(spec.get("bucket_cooldown_s", 0) or 0)
        if ctx.quick:
            buckets = buckets[:1]
        if not buckets:
            return self.skip("performance.ttft_buckets is empty")
        checks: list[Check] = []
        metrics = {}
        planned: list[dict] = []
        _log(
            f"开始 conc={conc} buckets={len(buckets)} "
            f"cooldown={cooldown}s quick={ctx.quick} smoke={ctx.cfg.profile_is_smoke()}"
        )
        for b in buckets:
            name = str(b["name"])
            kit = kit_id_for_bucket(b)
            has_dataset = bool(kit and dataset_path(ctx, kit))
            action, reason = _bucket_action(ctx, kit, has_dataset, smoke_kits)
            if action == "skip":
                _log(f"跳过 {name} kit={kit}: {reason}")
                checks.append(skip_check(f"ttft_{name}", reason or "skipped"))
                metrics[name] = {"skipped": True, "detail": reason, "kit": kit}
                continue
            planned.append(b)
        _log(f"将跑 {len(planned)}/{len(buckets)} 个 bucket: {[str(b['name']) for b in planned]}")
        ran = 0
        for idx, b in enumerate(planned):
            name = str(b["name"])
            kit = kit_id_for_bucket(b)
            n = request_count(ctx, conc)
            max_tokens = max_tokens_for(ctx, "ttft")
            factory, meta = prompt_factory_for(
                ctx,
                kit=kit,
                fallback_tokens=_fallback_tokens(ctx, b),
                needed=n,
            )
            _log(
                f"bucket {idx + 1}/{len(planned)} {name} kit={kit or 'pad'} "
                f"n={n} conc={conc} max_tokens={max_tokens} source={meta.get('source')}"
            )
            stats = run_load(
                ctx.vendor,
                number=n,
                concurrency=conc,
                max_tokens=max_tokens,
                stream=True,
                prompt_factory=factory,
                extra=chat_extra(ctx),
                include_stream_usage=include_stream_usage(ctx),
                on_sample=lambda done, total, sample: _log(_sample_line(done, total, sample)),
            )
            d = _attach(stats.to_dict(), meta, concurrency=conc, number=n)
            metrics[name] = d
            ran += 1
            p90, p50, avg = d.get("ttft_p90"), d.get("ttft_p50"), d.get("ttft_avg")
            ok = True
            detail = []
            for key, got, lim in (("p90", p90, b["p90"]), ("p50", p50, b["p50"]), ("avg", avg, b["avg"])):
                if got is None:
                    ok = False
                    detail.append(f"{key}=n/a")
                elif got > float(lim):
                    ok = False
                    detail.append(f"{key}={got:.3f}>{lim}")
                else:
                    detail.append(f"{key}={got:.3f}<={lim}")
            sr_ok = d.get("success_rate", 0) >= float(ctx.cfg.get("capacity", "success_rate_sla", default=0.999))
            verdict = "PASS" if ok and sr_ok else "FAIL"
            _log(
                f"bucket {name} {verdict} sr={d.get('success_rate')} "
                + "; ".join(detail)
                + f" duration={d.get('duration_s')}s"
            )
            checks.append(
                (ok_check if ok and sr_ok else fail_check)(
                    f"ttft_{name}",
                    d,
                    expected=f"P90<{b['p90']} P50<{b['p50']} avg<{b['avg']} sr>=SLA",
                    detail="; ".join(detail)
                    + f" sr={d.get('success_rate')} kit={kit or 'pad'} source={meta.get('source')}",
                )
            )
            if cooldown and idx < len(planned) - 1:
                nxt = str(planned[idx + 1]["name"])
                _sleep_with_progress(cooldown, f"{name} 结束，下一档 {nxt}")
        _log(f"完成 ran={ran}/{len(buckets)}")
        ctx.extras["ttft"] = metrics
        return self.result(checks, summary=f"ttft buckets ran={ran}/{len(buckets)}", metrics=metrics)


@register("performance.otps")
class OTPSModule(BaseModule):
    title = "OTPS"
    template_rows = [65, 66, 67, 68, 69]

    def run(self):
        ctx = self.ctx
        spec = perf_spec(ctx)
        tier = spec.get("otps_tier") or ctx.golden("otps_tier", default="L1")
        if dataset_path(ctx, "1k") is None:
            return self.skip("缺少 datasets/perf_zh 数据集 1k")
        n = request_count(ctx, 1)
        factory, meta = prompt_factory_for(ctx, kit="1k", fallback_tokens=256, needed=n)
        stats = run_load(
            ctx.vendor,
            number=n,
            concurrency=1,
            max_tokens=max_tokens_for(ctx, "otps"),
            stream=True,
            prompt_factory=factory,
            extra=chat_extra(ctx),
            include_stream_usage=include_stream_usage(ctx),
        )
        d = _attach(stats.to_dict(), meta, concurrency=1, number=n)
        measured_otps = d.get("otps_avg")
        otps = float(measured_otps or 0.0)
        if tier == "L1":
            need = 30.0
            row = 67
        elif tier == "L2":
            need = 10.0
            row = 68
        else:
            need = 100.0
            row = 69
        self.template_rows = [65, 66, row]
        if measured_otps is None:
            checks = [
                fail_check(
                    f"otps_{tier}",
                    d,
                    expected="stream completion_tokens usage and measurable TPOT",
                    detail="请求成功但没有可用 completion_tokens/TPOT，无法计算 OTPS",
                )
            ]
            return self.result(checks, summary="otps unavailable", metrics=d)
        checks: list[Check] = [
            (ok_check if otps >= need else fail_check)(
                f"otps_{tier}",
                d,
                expected=f">={need} tokens/s",
                detail=f"avg OTPS={otps:.2f} n={n} source={meta.get('source')}",
            )
        ]
        return self.result(checks, summary=f"otps={otps:.2f} need={need}", metrics=d)


def _fallback_tokens(ctx, bucket: dict) -> int:
    mid = int((int(bucket.get("min_tokens") or 1) + min(int(bucket.get("max_tokens") or 1), int(bucket.get("min_tokens") or 1) + 512)) / 2)
    if ctx.quick or ctx.cfg.profile_is_smoke():
        return min(mid, 1024)
    return mid


def _bucket_action(ctx, kit, has_dataset: bool, smoke_kits: tuple[str, ...]) -> tuple[str, str]:
    if kit and not has_dataset:
        return "skip", f"缺少 datasets/perf_zh 数据集 {kit}"
    if ctx.quick or ctx.cfg.profile_is_smoke():
        if kit and kit not in smoke_kits:
            return "skip", f"smoke/quick 只跑 perf-kit {list(smoke_kits)}"
        return "run", ""
    return "run", ""
