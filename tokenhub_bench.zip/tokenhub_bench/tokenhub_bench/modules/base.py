from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Optional

from tokenhub_bench.clients.http import EndpointClient, cached_tokens, finish_reason, message_from
from tokenhub_bench.config import Config
from tokenhub_bench.types import Check, HttpResult, Status


VENDOR_LEAK_DEFAULT = [
    "moonshot",
    "kimi.ai",
    "platform.kimi",
    "hygon",
    "海光",
    "vendor",
    "tokenhub",
]


@dataclass
class RunContext:
    cfg: Config
    vendor: EndpointClient
    official: Optional[EndpointClient] = None
    quick: bool = False
    extras: dict[str, Any] = field(default_factory=dict)

    def golden(self, *keys: str, default: Any = None) -> Any:
        return self.cfg.golden_get(*keys, default=default)

    def leak_needles(self) -> list[str]:
        return list(self.golden("error_body_must_not_contain", default=VENDOR_LEAK_DEFAULT))


class BaseModule:
    module_id: str = ""
    title: str = ""
    template_rows: list[int] = []

    def __init__(self, ctx: RunContext, params: Optional[dict[str, Any]] = None):
        self.ctx = ctx
        self.params = params or {}

    def run(self):
        raise NotImplementedError

    def skip(self, reason: str, *checks: Check):
        from tokenhub_bench.types import ModuleResult

        r = ModuleResult(
            module_id=self.module_id,
            title=self.title,
            template_rows=self.template_rows,
            status=Status.SKIP,
            checks=list(checks)
            or [Check(name="skipped", status=Status.SKIP, detail=reason)],
            notes=reason,
            vendor_summary=reason,
        )
        r.rollup()
        return r

    def result(self, checks: list[Check], summary: str = "", notes: str = "", metrics: Optional[dict] = None):
        from tokenhub_bench.types import ModuleResult

        r = ModuleResult(
            module_id=self.module_id,
            title=self.title,
            template_rows=self.template_rows,
            status=Status.PASS,
            checks=checks,
            vendor_summary=summary,
            notes=notes,
            metrics=metrics or {},
        )
        r.rollup()
        return r


def ok_check(name: str, actual: Any, expected: Any = None, detail: str = "", **evidence: Any) -> Check:
    return Check(name=name, status=Status.PASS, expected=expected, actual=actual, detail=detail, evidence=evidence)


def fail_check(name: str, actual: Any, expected: Any = None, detail: str = "", **evidence: Any) -> Check:
    return Check(name=name, status=Status.FAIL, expected=expected, actual=actual, detail=detail, evidence=evidence)


def warn_check(name: str, actual: Any, expected: Any = None, detail: str = "", **evidence: Any) -> Check:
    return Check(name=name, status=Status.WARN, expected=expected, actual=actual, detail=detail, evidence=evidence)


def skip_check(name: str, detail: str, **evidence: Any) -> Check:
    return Check(name=name, status=Status.SKIP, detail=detail, evidence=evidence)


def error_check(name: str, detail: str, **evidence: Any) -> Check:
    return Check(name=name, status=Status.ERROR, detail=detail, evidence=evidence)


def contains_think_tag(text: Optional[str]) -> bool:
    if not text:
        return False
    return bool(re.search(r"<think>.*?</think>", text, flags=re.S | re.I)) or "<think>" in text.lower()


def dump_brief(obj: Any, limit: int = 800) -> str:
    try:
        s = json.dumps(obj, ensure_ascii=False, default=str)
    except Exception:
        s = str(obj)
    return s[:limit]


def http_ok(res: HttpResult) -> bool:
    return res.ok and res.status_code < 400


def assistant_fields(res: HttpResult) -> dict[str, Any]:
    msg = message_from(res.json) or {}
    rc = msg.get("reasoning_content") or msg.get("reasoning")
    usage = res.usage or {}
    return {
        "content": msg.get("content"),
        "reasoning_content": rc,
        "tool_calls": msg.get("tool_calls"),
        "role": msg.get("role"),
        "finish_reason": finish_reason(res.json),
        "usage": usage,
        "reasoning_tokens": usage.get("reasoning_tokens")
        or (usage.get("completion_tokens_details") or {}).get("reasoning_tokens"),
        "cached_tokens": cached_tokens(usage),
        "status_code": res.status_code,
        "error": res.error,
        "text_head": (res.text or "")[:400],
    }


def leak_hits(text: str, needles: list[str]) -> list[str]:
    low = (text or "").lower()
    hits = []
    for n in needles:
        if n and n.lower() in low:
            hits.append(n)
    return hits


TINY_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
)


def pad_prompt(token_target: int, seed: str = "admission-padding") -> str:
    """Rough English padding. ~1 token ≈ 4 chars for ASCII."""
    unit = f"{seed} {token_target} context-fill. "
    need_chars = max(token_target, 1) * 4
    reps = max(1, need_chars // max(len(unit), 1))
    return (unit * reps)[:need_chars]


WEATHER_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get current weather for a city.",
            "parameters": {
                "type": "object",
                "required": ["city"],
                "properties": {
                    "city": {"type": "string", "description": "City name, e.g. Beijing"},
                    "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
                },
            },
        },
    }
]

ADD_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "add",
            "description": "Add two integers.",
            "parameters": {
                "type": "object",
                "required": ["a", "b"],
                "properties": {
                    "a": {"type": "integer"},
                    "b": {"type": "integer"},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "multiply",
            "description": "Multiply two integers.",
            "parameters": {
                "type": "object",
                "required": ["a", "b"],
                "properties": {
                    "a": {"type": "integer"},
                    "b": {"type": "integer"},
                },
            },
        },
    },
]
