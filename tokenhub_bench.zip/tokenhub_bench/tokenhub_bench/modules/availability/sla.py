from __future__ import annotations

from tokenhub_bench.modules.base import BaseModule, ok_check, skip_check, warn_check
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


@register("availability.sla")
class SLAModule(BaseModule):
    title = "可用性验收 SLA / RTO"
    template_rows = [79, 80, 81, 82, 83, 84, 85, 86]

    def run(self):
        ctx = self.ctx
        soak = ctx.extras.get("soak") or {}
        checks: list[Check] = []
        note = (
            "SLA=（总服务时间-不可用时间）/总服务时间。不可用：连续10分钟失败率>=0.1%，"
            "或 TTFT/OTPS/精度不达标。RTO 高峰<=10min / 低峰<=60min 需故障演练，本模块只记录口径。"
        )
        if soak:
            sr = float(soak.get("success_rate") or 0)
            window_fail = sr < 0.999
            checks.append(
                (warn_check if window_fail else ok_check)(
                    "soak_as_sla_proxy",
                    soak,
                    expected="no 10-min window with fail_rate>=0.1%",
                    detail="full monthly SLA needs production metrics; soak is a proxy",
                )
            )
        else:
            checks.append(
                skip_check(
                    "soak_as_sla_proxy",
                    "run --suite capacity first (or full) so soak metrics are in ctx.extras",
                )
            )
        rto = ctx.cfg.get("vendor", "rto", default={}) or {}
        checks.append(
            skip_check(
                "rto_peak",
                f"高峰 8:00-24:00 RTO<=10min; declared={rto.get('peak', 'unset')}",
            )
        )
        checks.append(
            skip_check(
                "rto_offpeak",
                f"低峰 0:00-8:00 RTO<=60min; declared={rto.get('offpeak', 'unset')}",
            )
        )
        return self.result(checks, summary="SLA/RTO declaration", notes=note, metrics={"soak": soak, "rto": rto})
