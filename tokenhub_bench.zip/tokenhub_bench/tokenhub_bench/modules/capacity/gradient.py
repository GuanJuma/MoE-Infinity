from __future__ import annotations

import time

from tokenhub_bench.modules.base import BaseModule, fail_check, ok_check, skip_check
from tokenhub_bench.modules.performance.kit import (
    DEFAULT_CONCURRENCIES,
    capacity_kits,
    chat_extra,
    dataset_path,
    include_stream_usage,
    max_tokens_for,
    perf_spec,
    prompt_factory_for,
    request_count,
)
from tokenhub_bench.modules.performance.loadgen import run_load
from tokenhub_bench.modules.performance.ttft_otps import _dur
from tokenhub_bench.registry import register
from tokenhub_bench.types import Check


def _attach(d: dict, meta: dict, **extra) -> dict:
    out = dict(d)
    out.update(meta)
    out.update(extra)
    return out


@register("capacity.gradient")
class GradientCapacityModule(BaseModule):
    title = "容量梯度压测 TPM/RPM"
    template_rows = [70, 71, 72, 73, 74, 75, 76, 77, 78]

    def run(self):
        ctx = self.ctx
        cap = ctx.cfg.get("capacity", default={}) or {}
        perf = perf_spec(ctx)
        concs = list(perf.get("concurrencies") or DEFAULT_CONCURRENCIES)
        if ctx.quick:
            concs = concs[:1]
        stop_sr = float(perf.get("stop_success_rate", 0.99))
        promised_tpm = float(cap.get("promised_tpm", 10_000_000))
        promised_rpm = float(cap.get("promised_rpm", 1000))
        kits = capacity_kits(ctx)
        mode = str(perf.get("load_mode") or "requests")
        hold = _dur(ctx, "gradient_hold_s", 60, 720)
        cooldown = 0
        if not ctx.quick and not ctx.cfg.profile_is_smoke():
            cooldown = int(perf.get("bucket_cooldown_s", 0) or 0)
        extra = chat_extra(ctx)
        checks: list[Check] = []
        ladder = []
        ran_kits = 0
        planned = [kit for kit in kits if dataset_path(ctx, kit)]
        missing = [kit for kit in kits if kit not in planned]
        for kit in missing:
            checks.append(skip_check(f"gradient_{kit}", f"缺少 datasets/perf_zh 数据集 {kit}"))
        if not planned:
            return self.skip("未找到任何容量压测数据集", *checks)
        stop_ladder = False
        for kit_idx, kit in enumerate(planned):
            ran_kits += 1
            for c in concs:
                n = request_count(ctx, int(c))
                factory, meta = prompt_factory_for(ctx, kit=kit, fallback_tokens=512, needed=max(n, 8))
                kwargs = {
                    "concurrency": int(c),
                    "max_tokens": max_tokens_for(ctx, "gradient"),
                    "stream": True,
                    "prompt_factory": factory,
                    "extra": extra,
                    "include_stream_usage": include_stream_usage(ctx),
                }
                if mode == "duration":
                    stats = run_load(ctx.vendor, duration_s=hold, **kwargs)
                else:
                    stats = run_load(ctx.vendor, number=n, **kwargs)
                d = _attach(
                    stats.to_dict(),
                    meta,
                    concurrency=c,
                    number=n if mode != "duration" else None,
                    load_mode=mode,
                    kit=kit,
                )
                ladder.append(d)
                sr = d["success_rate"]
                check_name = f"gradient_{kit}_c{c}"
                if sr < stop_sr:
                    checks.append(
                        fail_check(
                            check_name,
                            d,
                            expected=f"success_rate>={stop_sr}",
                            detail="template: 成功率<99% 停止取数",
                        )
                    )
                    stop_ladder = True
                    break
                checks.append(ok_check(check_name, d, expected=f"sr>={stop_sr}"))
            if stop_ladder:
                break
            if cooldown and kit_idx < len(planned) - 1:
                time.sleep(cooldown)
        peak = max(ladder, key=lambda x: x.get("tpm") or 0) if ladder else {}
        tpm = peak.get("tpm") or 0
        rpm = peak.get("rpm") or 0
        saw_failures = any(s.get("success_rate", 1) < 1 for s in ladder)
        tpm_ok = tpm > 0 if ctx.cfg.profile_is_smoke() else tpm >= promised_tpm
        checks.append(
            (ok_check if tpm_ok else fail_check)(
                "measured_tpm",
                tpm,
                expected=(
                    ">0 (smoke records only)"
                    if ctx.cfg.profile_is_smoke()
                    else f">= promised_tpm {promised_tpm}"
                ),
                detail="formal admission gates peak TPM; smoke only verifies measurement",
            )
        )
        checks.append(
            ok_check(
                "measured_rpm",
                rpm,
                expected=f"record only; declared promised_rpm={promised_rpm}",
                detail=(
                    f"saw_failures={saw_failures}; the concurrency ladder does not target promised_rpm, "
                    "so measured RPM is not a gate"
                ),
            )
        )
        ctx.extras["capacity_ladder"] = ladder
        return self.result(
            checks,
            summary=(
                f"peak_tpm={tpm:.0f} peak_rpm={rpm:.1f} "
                f"peak_kit={peak.get('kit', 'n/a')} kits={ran_kits}"
            ),
            metrics={
                "ladder": ladder,
                "peak_tpm_kit": peak.get("kit"),
                "peak_tpm_concurrency": peak.get("concurrency"),
                "promised_tpm": promised_tpm,
                "promised_rpm": promised_rpm,
            },
        )


@register("capacity.soak")
class SoakModule(BaseModule):
    title = "持续压测稳定性"
    template_rows = [70, 74]

    def run(self):
        ctx = self.ctx
        cap = ctx.cfg.get("capacity", default={}) or {}
        perf = perf_spec(ctx)
        seconds = int(perf.get("soak_s", 120))
        if ctx.quick:
            seconds = min(seconds, 20)
        elif ctx.cfg.profile_is_smoke():
            seconds = min(seconds, 120)
        else:
            seconds = max(seconds, 1800)
        concs = list(perf.get("concurrencies") or DEFAULT_CONCURRENCIES)
        conc = int(concs[0] if ctx.quick else (perf.get("soak_concurrency") or concs[-1]))
        kit = str(perf.get("capacity_kit") or "1k")
        if dataset_path(ctx, kit) is None:
            return self.skip(f"缺少 datasets/perf_zh 数据集 {kit}")
        n_hint = max(8, conc * 2)
        factory, meta = prompt_factory_for(ctx, kit=kit, fallback_tokens=512, needed=n_hint)
        stats = run_load(
            ctx.vendor,
            duration_s=seconds,
            concurrency=conc,
            max_tokens=max_tokens_for(ctx, "soak"),
            stream=True,
            prompt_factory=factory,
            extra=chat_extra(ctx),
            include_stream_usage=include_stream_usage(ctx),
        )
        d = _attach(stats.to_dict(), meta, concurrency=conc, kit=kit)
        sla = float(cap.get("success_rate_sla", 0.999))
        checks: list[Check] = [
            (ok_check if d["success_rate"] >= sla else fail_check)(
                "soak_success_rate",
                d,
                expected=f">={sla} for {seconds}s at concurrency={conc}",
            )
        ]
        ctx.extras["soak"] = d
        return self.result(checks, summary=f"sr={d['success_rate']:.4f} tpm={d['tpm']:.0f}", metrics=d)
