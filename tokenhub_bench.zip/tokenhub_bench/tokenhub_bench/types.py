from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class Status(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"
    WARN = "warn"
    ERROR = "error"


@dataclass
class Check:
    name: str
    status: Status
    expected: Any = None
    actual: Any = None
    detail: str = ""
    evidence: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status.value,
            "expected": self.expected,
            "actual": self.actual,
            "detail": self.detail,
            "evidence": self.evidence,
        }


@dataclass
class ModuleResult:
    module_id: str
    title: str
    template_rows: list[int]
    status: Status
    checks: list[Check] = field(default_factory=list)
    vendor_summary: str = ""
    notes: str = ""
    metrics: dict[str, Any] = field(default_factory=dict)
    duration_s: float = 0.0

    def rollup(self) -> Status:
        if any(c.status == Status.ERROR for c in self.checks):
            self.status = Status.ERROR
        elif any(c.status == Status.FAIL for c in self.checks):
            self.status = Status.FAIL
        elif self.checks and all(c.status == Status.SKIP for c in self.checks):
            self.status = Status.SKIP
        elif any(c.status == Status.WARN for c in self.checks) and not any(
            c.status == Status.FAIL for c in self.checks
        ):
            self.status = Status.WARN
        elif self.checks:
            self.status = Status.PASS
        return self.status

    def to_dict(self) -> dict[str, Any]:
        return {
            "module_id": self.module_id,
            "title": self.title,
            "template_rows": self.template_rows,
            "status": self.status.value,
            "vendor_summary": self.vendor_summary,
            "notes": self.notes,
            "metrics": self.metrics,
            "duration_s": self.duration_s,
            "checks": [c.to_dict() for c in self.checks],
        }


@dataclass
class HttpResult:
    ok: bool
    status_code: int
    elapsed_s: float
    json: Optional[dict[str, Any]] = None
    text: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    error: str = ""
    ttft_s: Optional[float] = None
    chunks: list[dict[str, Any]] = field(default_factory=list)
    usage: dict[str, Any] = field(default_factory=dict)
    raw_sse: list[str] = field(default_factory=list)
