#!/usr/bin/env bash
# Offline install on the remote Linux server (no internet).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
WHEELS="$ROOT/vendor/wheels"
PY="${PYTHON:-python3}"

if [[ ! -d "$WHEELS" ]] || [[ -z "$(ls -A "$WHEELS" 2>/dev/null || true)" ]]; then
  echo "missing vendor/wheels. copy the whole project directory to this machine." >&2
  exit 1
fi

echo "python: $($PY --version 2>&1)"
"$PY" -m venv "$ROOT/.venv"
# shellcheck disable=SC1091
source "$ROOT/.venv/bin/activate"

python -m pip install --no-index --find-links "$WHEELS" --upgrade pip setuptools wheel
python -m pip install --no-index --find-links "$WHEELS" -r "$ROOT/requirements.txt"
python -m pip install --no-index --find-links "$WHEELS" --no-build-isolation -e "$ROOT"

echo
echo "install ok. next:"
echo "  source $ROOT/.venv/bin/activate"
echo "  bash scripts/test_offline.sh"
echo "  bash scripts/run_on_remote.sh smoke --quick"
