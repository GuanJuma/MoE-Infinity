#!/usr/bin/env bash
# Alias: same as run_on_remote.sh (uses .venv if present).
exec "$(cd "$(dirname "$0")" && pwd)/run_on_remote.sh" "$@"
