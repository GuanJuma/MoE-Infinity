#!/usr/bin/env bash
# Offline pipeline tests: no live model / GPU required.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
if [[ -x "$ROOT/.venv/bin/python" ]]; then
  PY="$ROOT/.venv/bin/python"
  export PATH="$ROOT/.venv/bin${PATH:+:$PATH}"
else
  PY="${PYTHON:-python3}"
fi
exec "$PY" -m unittest discover -s tests -v
