#!/usr/bin/env bash
# Run Tokenhub admission pipeline. Endpoint defaults come from the job's hardware YAML.
# Override with TOKENHUB_JOB / TOKENHUB_BASE_URL / TOKENHUB_API_KEY if needed.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ -x "$ROOT/.venv/bin/python" ]]; then
  PY="$ROOT/.venv/bin/python"
  export PATH="$ROOT/.venv/bin${PATH:+:$PATH}"
else
  PY="${PYTHON:-python3}"
fi

export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
JOB="${TOKENHUB_JOB:-$ROOT/configs/jobs/haiguang-hy3.yaml}"
SUITE="smoke"
if [[ $# -gt 0 && "$1" != -* ]]; then
  SUITE="$1"
  shift
fi

echo "python=$PY"
echo "job=$JOB"
echo "suite=$SUITE"

BASE_URL="${TOKENHUB_BASE_URL:-}"
API_KEY="${TOKENHUB_API_KEY:-}"
mapfile -t JOB_ENDPOINT < <(
  "$PY" - "$JOB" <<'PY'
import sys
from tokenhub_bench.config import Config

vendor = Config.load(sys.argv[1]).vendor
print(vendor.get("base_url") or "")
print(vendor.get("api_key") or "")
PY
)
BASE_URL="${BASE_URL:-${JOB_ENDPOINT[0]:-}}"
API_KEY="${API_KEY:-${JOB_ENDPOINT[1]:-}}"
echo "base_url=${BASE_URL:-unknown}"
echo "---- probe /v1/models ----"
if [[ -n "$BASE_URL" ]]; then
  AUTH=()
  if [[ -n "$API_KEY" && "$API_KEY" != "EMPTY" ]]; then
    AUTH=(-H "Authorization: Bearer ${API_KEY}")
  fi
  curl -sS --connect-timeout 3 --max-time 10 "${AUTH[@]}" "$BASE_URL/models" | head -c 400 || true
  echo
fi
echo "---- run pipeline ----"
"$PY" -m tokenhub_bench run -c "$JOB" -s "$SUITE" "$@"
