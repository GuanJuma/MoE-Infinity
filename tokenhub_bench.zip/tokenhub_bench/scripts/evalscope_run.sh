#!/usr/bin/env bash
# Wrap evalscope eval against the vendor OpenAI-compatible endpoint.
# Env (injected by accuracy.evalscope): OPENAI_MODEL, OPENAI_BASE_URL, OPENAI_API_KEY
# Usage: bash scripts/evalscope_run.sh DATASET [extra evalscope args]
set -euo pipefail
if [[ $# -lt 1 ]]; then
  echo "usage: $0 DATASET [extra evalscope args]" >&2
  exit 2
fi
DATASET="$1"
shift
PY="${PYTHON:-python3}"
MODEL="${OPENAI_MODEL:?OPENAI_MODEL is required}"
API_URL="${OPENAI_BASE_URL:?OPENAI_BASE_URL is required}"
API_KEY="${OPENAI_API_KEY:-EMPTY}"
# Do not put JSON `}` inside ${VAR:-default}; bash treats it as the end of expansion.
DEFAULT_BATCH=1
GEN_CFG="{\"max_tokens\":8192,\"temperature\":0.9,\"timeout\":900,\"batch_size\":1}"
if [[ "$DATASET" == "aime26" ]]; then
  DEFAULT_BATCH=8
  GEN_CFG="{\"max_tokens\":8192,\"temperature\":0.9,\"top_p\":1.0,\"timeout\":900,\"batch_size\":8}"
fi
if [[ -n "${EVALSCOPE_GEN_CFG:-}" ]]; then
  GEN_CFG="$EVALSCOPE_GEN_CFG"
fi
EXTRA_ARGS=("$@")
HAS_DATASET_ARGS=false
for arg in "${EXTRA_ARGS[@]}"; do
  if [[ "$arg" == "--dataset-args" ]]; then
    HAS_DATASET_ARGS=true
    break
  fi
done
if [[ "$DATASET" == "tau2_bench" && "$HAS_DATASET_ARGS" == false ]]; then
  : "${TAU2_SUBSET:?TAU2_SUBSET is required for tau2_bench}"
  DATASET_ARGS="$("$PY" - <<'PY'
import json
import os

config = {
    "subset_list": [os.environ["TAU2_SUBSET"]],
    "extra_params": {
        "user_model": os.environ["OPENAI_MODEL"],
        "api_key": os.environ.get("OPENAI_API_KEY") or "EMPTY",
        "api_base": os.environ["OPENAI_BASE_URL"],
    },
}
if os.environ.get("TAU2_LOCAL_PATH"):
    config["local_path"] = os.environ["TAU2_LOCAL_PATH"]
print(json.dumps({"tau2_bench": config}, ensure_ascii=False))
PY
)"
  EXTRA_ARGS+=(--dataset-args "$DATASET_ARGS")
fi
JUDGE="$("$PY" - <<'PY'
import json, os
print(json.dumps({
    "models": [{
        "model_id": os.environ["OPENAI_MODEL"],
        "api_url": os.environ["OPENAI_BASE_URL"],
        "api_key": os.environ.get("OPENAI_API_KEY") or "EMPTY",
        "eval_type": "openai_api",
    }]
}))
PY
)"
exec evalscope eval \
  --model "$MODEL" \
  --api-url "$API_URL" \
  --api-key "$API_KEY" \
  --eval-type openai_api \
  --eval-batch-size "${EVALSCOPE_BATCH:-$DEFAULT_BATCH}" \
  --datasets "$DATASET" \
  --generation-config "$GEN_CFG" \
  --judge "$JUDGE" \
  "${EXTRA_ARGS[@]}"
