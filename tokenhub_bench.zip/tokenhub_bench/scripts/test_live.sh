#!/usr/bin/env bash
# Live pipeline check against the vendor endpoint (default 22.142.37.103:8000).
# Usage:
#   bash scripts/test_live.sh           # L0 probe + L1 smoke --quick
#   bash scripts/test_live.sh l2        # plus engineering --quick
# L3 performance/capacity is documented in docs/测试流水线.md, not run here.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
if [[ -x "$ROOT/.venv/bin/python" ]]; then
  PY="$ROOT/.venv/bin/python"
  export PATH="$ROOT/.venv/bin${PATH:+:$PATH}"
else
  PY="${PYTHON:-python3}"
fi

LEVEL="${1:-l1}"
JOB="${TOKENHUB_JOB:-$ROOT/configs/jobs/haiguang-hy3.yaml}"
mapfile -t JOB_ENDPOINT < <(
  "$PY" - "$JOB" <<'PY'
import sys
from tokenhub_bench.config import Config

vendor = Config.load(sys.argv[1]).vendor
for key in ("base_url", "api_key", "model"):
    print(vendor.get(key) or "")
PY
)
export TOKENHUB_BASE_URL="${TOKENHUB_BASE_URL:-${JOB_ENDPOINT[0]:-}}"
export TOKENHUB_API_KEY="${TOKENHUB_API_KEY:-${JOB_ENDPOINT[1]:-}}"
export TOKENHUB_MODEL="${TOKENHUB_MODEL:-${JOB_ENDPOINT[2]:-}}"
BASE_URL="$TOKENHUB_BASE_URL"
MODEL="$TOKENHUB_MODEL"
if [[ -z "$BASE_URL" || -z "$MODEL" ]]; then
  echo "TOKENHUB_BASE_URL and TOKENHUB_MODEL must be set in the environment or job config" >&2
  exit 2
fi

limit_output() {
  "$PY" -c 'import sys; data = sys.stdin.buffer.read(); sys.stdout.buffer.write(data[:int(sys.argv[1])])' "$1"
}

echo "python=$PY"
echo "base_url=$BASE_URL"
echo "model=$MODEL"
echo "job=$JOB"
echo "level=$LEVEL"

AUTH=()
if [[ -n "${TOKENHUB_API_KEY:-}" && "${TOKENHUB_API_KEY}" != "EMPTY" ]]; then
  AUTH=(-H "Authorization: Bearer ${TOKENHUB_API_KEY}")
fi

echo "---- L0 probe /v1/models ----"
curl -sS --connect-timeout 3 --max-time 15 "${AUTH[@]}" "${BASE_URL}/models" | limit_output 800
echo
echo "---- L0 probe chat ----"
curl -sS --connect-timeout 3 --max-time 60 "${BASE_URL}/chat/completions" \
  -H "Content-Type: application/json" \
  "${AUTH[@]}" \
  -d "{\"model\":\"${MODEL}\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"max_tokens\":16,\"temperature\":0.0}" \
  | limit_output 800
echo

if [[ "$LEVEL" == "l0" ]]; then
  echo "L0 done"
  exit 0
fi

echo "---- L1 smoke --quick ----"
"$PY" -m tokenhub_bench run -c "$JOB" -s smoke --quick

if [[ "$LEVEL" == "l1" ]]; then
  echo "L1 done. For engineering: bash scripts/test_live.sh l2"
  exit 0
fi

echo "---- L2 engineering --quick ----"
"$PY" -m tokenhub_bench run -c "$JOB" -s engineering --quick
echo "L2 done. L3 (admission performance/capacity) is not in this script; see docs/测试流水线.md"
